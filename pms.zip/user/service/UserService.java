package kr.go.mosf.pms.user.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.user.dao.UserDAO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cryptography.EgovPasswordEncoder;

@Service("userService")
public class UserService  extends BaseService{
	@Resource(name="userDAO")
	private UserDAO userDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 UserVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public boolean create(UserVO vo) throws Exception {
    	boolean isSuccss = false;
    	UserVO existUserVO = userDAO.retrieve(vo);
    	if(existUserVO == null){
    		//비밀번호 가공처리
    		EgovPasswordEncoder encoder = new EgovPasswordEncoder();
    		encoder.setAlgorithm(MOSFPMSDefine.ENCRYPT_ALGORITHM);
    		vo.setUserPassword(encoder.encryptPassword(vo.getUserPassword()));
    		
    		userDAO.create(vo);
    		isSuccss = true;
    	}
    	return isSuccss;  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 UserVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(UserVO vo) throws Exception {
    	if(!GenericValidator.isBlankOrNull(vo.getChangePasswordYN())
    			&&vo.getChangePasswordYN().equals("Y")){
    		//비밀번호 가공처리
    		EgovPasswordEncoder encoder = new EgovPasswordEncoder();
    		encoder.setAlgorithm(MOSFPMSDefine.ENCRYPT_ALGORITHM);
    		vo.setUserPassword(encoder.encryptPassword(vo.getUserPassword()));
    	}
        return userDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 UserVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(UserVO vo) throws Exception {
    	return userDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public UserVO retrieve(UserVO vo) throws Exception {
    	return userDAO.retrieve(vo);
    }    
    
    
    /**
	 * 로그인 성공 여부를 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public UserVO retrieveLogin(UserVO vo) throws Exception {
    	
    	UserVO exsitUserVO = userDAO.retrieve(vo);
    	if(exsitUserVO != null){
    		//비밀번호 가공처리
    		EgovPasswordEncoder encoder = new EgovPasswordEncoder();
    		encoder.setAlgorithm(MOSFPMSDefine.ENCRYPT_ALGORITHM);
    		
    		if(!encoder.checkPassword(vo.getUserPassword(), exsitUserVO.getUserPassword())){
    			exsitUserVO = null;    			
    		}
    	}
    	
    	return exsitUserVO;
    }   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<UserVO> retrievePagingList(UserVO vo) throws Exception {
        return userDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(UserVO vo) {
        return userDAO.retrievePagingListCnt(vo);
    }
}
