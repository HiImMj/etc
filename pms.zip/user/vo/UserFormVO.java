package kr.go.mosf.pms.user.vo;

import java.util.ArrayList;
import java.util.List;

import kr.go.mosf.pms.base.vo.BaseVO;

public class UserFormVO extends BaseVO{
	private UserVO searchUserVO;
	private UserVO userVO;
	
	private List<UserVO> list;
	
	public UserFormVO(){
		searchUserVO = new UserVO();
		userVO = new UserVO();
		list = new ArrayList<UserVO>();
	}

	public UserVO getSearchUserVO() {
		return searchUserVO;
	}

	public void setSearchUserVO(UserVO searchUserVO) {
		this.searchUserVO = searchUserVO;
	}

	public UserVO getUserVO() {
		return userVO;
	}

	public void setUserVO(UserVO userVO) {
		this.userVO = userVO;
	}

	public List<UserVO> getList() {
		return list;
	}

	public void setList(List<UserVO> list) {
		this.list = list;
	}
	
	
}
