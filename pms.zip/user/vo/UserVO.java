package kr.go.mosf.pms.user.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class UserVO extends BaseVO{
	public static final String LOGIN_USER_VO = "LOGIN_USER_VO";
	public static final String USER_TY_CODE_BIZ = "A002"; //사업관리자
	public static final String USER_TY_CODE_SRC = "A003"; //용역지원
	
	public static final String USER_STTUS_CODE_ETR = "A001"; //승인요청
	
	private String userId;
    private String userPassword;
    private String userNm;
    private String userTyCode; 
    private String userTyCodeNm;
    private String userSttusCode;
    private String userSttusCodeNm;
    private String psitn;
    private String clsf;
    private String email;
    private String moblphon;
    private String acntReqstResn;
    private String changePasswordYN="N";
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getPsitn() {
		return psitn;
	}
	public void setPsitn(String psitn) {
		this.psitn = psitn;
	}
	public String getClsf() {
		return clsf;
	}
	public void setClsf(String clsf) {
		this.clsf = clsf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMoblphon() {
		return moblphon;
	}
	public void setMoblphon(String moblphon) {
		this.moblphon = moblphon;
	}
	public String getAcntReqstResn() {
		return acntReqstResn;
	}
	public void setAcntReqstResn(String acntReqstResn) {
		this.acntReqstResn = acntReqstResn;
	}
	public String getChangePasswordYN() {
		return changePasswordYN;
	}
	public void setChangePasswordYN(String changePasswordYN) {
		this.changePasswordYN = changePasswordYN;
	}
	public String getUserTyCode() {
		return userTyCode;
	}
	public void setUserTyCode(String userTyCode) {
		this.userTyCode = userTyCode;
	}
	public String getUserTyCodeNm() {
		return userTyCodeNm;
	}
	public void setUserTyCodeNm(String userTyCodeNm) {
		this.userTyCodeNm = userTyCodeNm;
	}
	public String getUserSttusCode() {
		return userSttusCode;
	}
	public void setUserSttusCode(String userSttusCode) {
		this.userSttusCode = userSttusCode;
	}
	public String getUserSttusCodeNm() {
		return userSttusCodeNm;
	}
	public void setUserSttusCodeNm(String userSttusCodeNm) {
		this.userSttusCodeNm = userSttusCodeNm;
	}
	
}
