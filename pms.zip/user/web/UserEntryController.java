package kr.go.mosf.pms.user.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.user.service.UserService;
import kr.go.mosf.pms.user.vo.UserFormVO;
import kr.go.mosf.pms.user.vo.UserVO;

@Controller
public class UserEntryController extends BaseController {
	@Resource(name = "userService")
	private UserService userService;

	/**
	 * 글 등록 화면을 조회한다.
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/userEntry/createView.do")
	public String createView(UserFormVO userFormVO, ModelMap model) throws Exception {
		UserVO userVO = new UserVO();
		userVO.setUserTyCode(UserVO.USER_TY_CODE_SRC);
		userVO.setUserSttusCode(UserVO.USER_STTUS_CODE_ETR);

		userFormVO.setUserVO(new UserVO());

		return "/userentry/edit";
	}

	/**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/user/retrievePagingList.do"
	 * @exception Exception
	 */
	@RequestMapping("/userEntry/create.do")
	public String create(HttpServletRequest request, UserFormVO userFormVO, BindingResult bindingResult, Model model, SessionStatus status) throws Exception {

		// Server-Side Validation
		beanValidator.validate(userFormVO.getUserVO(), bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("userVO", userFormVO.getUserVO());
			return "/userentry/edit";
		}

		//직접신청한 경우.
		userFormVO.getUserVO().setCreatId(userFormVO.getUserVO().getUserId());
		userFormVO.getUserVO().setUserTyCode(UserVO.USER_TY_CODE_SRC);
		userFormVO.getUserVO().setUserSttusCode(UserVO.USER_STTUS_CODE_ETR);

		if (!userService.create(userFormVO.getUserVO())) {
			model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "이미 등록된 사용자ID 입니다.");
			return "forward:/userEntry/retrieveView.do";
		}
		status.setComplete();
		return "forward:/userEntry/retrieveView.do";
	}

	/**
	 * 회원정보 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/userEntry/updateView.do")
	public String updateView(HttpServletRequest request,
			UserFormVO userFormVO, ModelMap model) throws Exception {

		UserVO loginUserVO = (UserVO) request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
		userFormVO.setUserVO(loginUserVO);		
		userFormVO.setUserVO(userService.retrieve(userFormVO.getUserVO()));
		
		return "/userentry/edit";
	}
	
	/**
	 * 회원정보 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/userEntry/update.do")
	public String update(HttpServletRequest request, UserFormVO userFormVO, BindingResult bindingResult, Model model, SessionStatus status) throws Exception {

		UserVO loginUserVO = (UserVO) request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
		
		//로그인 하지 않은 사용자는 view 화면으로 리턴
		if(loginUserVO == null){
			return "forward:/userEntry/retrieveView.do";
		}
		// Server-Side Validation
		beanValidator.validate(userFormVO.getUserVO(), bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("userFormVO", userFormVO);
			return "/userentry/edit";
		}

		userFormVO.getUserVO().setUpdtId(userFormVO.getUserVO().getUserId());
		userFormVO.getUserVO().setUserNm(userFormVO.getUserVO().getUserNm());
		userFormVO.getUserVO().setUserTyCode(loginUserVO.getUserTyCode());
		userFormVO.getUserVO().setUserSttusCode(loginUserVO.getUserSttusCode());
		
		userService.update(userFormVO.getUserVO());
		
		status.setComplete();
		
		model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "성공적으로 수정 되었습니다.");
		
		return "/userentry/edit";
	}

	/**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/userEntry/retrieveView.do")
	public String retrieveView(UserFormVO userFormVO, ModelMap model) throws Exception {
		userFormVO.setUserVO(userService.retrieve(userFormVO.getUserVO()));

		return "/userentry/view";
	}

	/**
	 * AJAX를 통해 사용중인 ID인지 검사 한다.
	 * 
	 * @param commandMap
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/userEntry/retrieveAjax.do")
	public String retrieveAjax(UserVO userVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
		UserVO existUserVO = userService.retrieve(userVO);

		//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
		if (existUserVO == null) {
			model.addAttribute("returnMessage", "success");
		} else {
			model.addAttribute("returnMessage", "fail");
		}

		return "jsonView";
	}
}
