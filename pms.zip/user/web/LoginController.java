package kr.go.mosf.pms.user.web;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.loginhist.service.LoginHistService;
import kr.go.mosf.pms.loginhist.vo.LoginHistVO;
import kr.go.mosf.pms.user.service.UserService;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController extends BaseController{
	@Resource(name = "userService")
	private UserService userService;
	
	@Resource(name = "loginHistService")
	private LoginHistService loginHistService;
	
	/**
	 * 로그인 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/login/loginView.do")
    public String loginView(
            UserVO searchVO, Model model)
            throws Exception {
        model.addAttribute("userVO", new UserVO());
        return "/login/edit";
    }
    
    /**
	 * 로그인한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/login/login.do")
    public String login(            
            UserVO userVO,HttpServletRequest request,Model model)
            throws Exception {
        
    	UserVO exsitUserVO = userService.retrieveLogin(userVO);
        if(exsitUserVO !=null){
        	request.getSession().removeAttribute(UserVO.LOGIN_USER_VO);
        	request.getSession().setAttribute(UserVO.LOGIN_USER_VO, exsitUserVO);
        	logger.debug("exsitUserVO: "+exsitUserVO);
        	
        	//login기록
        	LoginHistVO loginHistVO = new LoginHistVO();
        	loginHistVO.setUserId(exsitUserVO.getUserId());
        	loginHistVO.setLoginDt(new Date());
        	loginHistVO.setLogoutSttusCode(LoginHistVO.LOGOUT_STTUS_CODE_UNKNOWN);
        	loginHistService.create(loginHistVO);
        	
        	request.getSession().removeAttribute(LoginHistVO.LOGIN_HIST_VO);
        	request.getSession().setAttribute(LoginHistVO.LOGIN_HIST_VO, loginHistVO);
        	
        	return "redirect:/cmmnCodeType/retrievePagingList.do";
        }
        
        model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "로그인 정보가 올바르지 않습니다. 확인해 보시고 다시 시도해 주시기 바랍니다.");
        
        return "/login/edit";
    }
    
    /**
	 * 로그인 아웃한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/login/logout.do")
    public String logout(            
            UserVO userVO,HttpServletRequest request,Model model)
            throws Exception {
        
    	HttpSession session =  request.getSession();
    	
    	LoginHistVO loginHistVO = (LoginHistVO)session.getAttribute(LoginHistVO.LOGIN_HIST_VO);
    	loginHistVO.setLogoutDt(new Date());
    	loginHistVO.setLogoutSttusCode(LoginHistVO.LOGOUT_STTUS_CODE_SUCCESS);
    	loginHistService.update(loginHistVO);
    	
		session.invalidate();
		
        model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "성공적으로 로그아웃 되었습니다.");
        
        return "/login/edit";
    }

}
