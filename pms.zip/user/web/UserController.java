package kr.go.mosf.pms.user.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.user.service.UserService;
import kr.go.mosf.pms.user.vo.UserFormVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class UserController extends BaseController{
	@Resource(name = "userService")
	private UserService userService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param userFormVO.getSearchUserVO() - 조회할 정보가 담긴 UserVO
	 * @param model
	 * @return "/user/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/user/retrievePagingList.do")
    public String retrievePagingList(UserFormVO userFormVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	userFormVO.getSearchUserVO().setPageUnit(propertiesService.getInt("pageUnit"));
    	userFormVO.getSearchUserVO().setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userFormVO.getSearchUserVO().getPageIndex());
		paginationInfo.setRecordCountPerPage(userFormVO.getSearchUserVO().getPageUnit());
		paginationInfo.setPageSize(userFormVO.getSearchUserVO().getPageSize());
		
		userFormVO.getSearchUserVO().setFirstIndex(paginationInfo.getFirstRecordIndex());
		userFormVO.getSearchUserVO().setLastIndex(paginationInfo.getLastRecordIndex());
		userFormVO.getSearchUserVO().setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		userFormVO.getSearchUserVO().setDeleteYn("N");
		
		List<UserVO> list = userService.retrievePagingList(userFormVO.getSearchUserVO());
        model.addAttribute("resultList", list);
        
        retrieveCmmnCode(model);
        
        int totCnt = userService.retrievePagingListCnt(userFormVO.getSearchUserVO());
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/user/list";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.USER_TY_CODE);
        model.addAttribute("userTyCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
        
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.USER_STTUS_CODE);
        model.addAttribute("userSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/user/createView.do")
    public String createView(
    		UserFormVO userFormVO, ModelMap model)
            throws Exception {
    	userFormVO.setUserVO(new UserVO()); 
    	retrieveCmmnCode(model);
        return "/user/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/user/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/user/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 UserFormVO userFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(userFormVO.getUserVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("userVO", userFormVO.getUserVO());
			return "/user/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	userFormVO.getUserVO().setCreatId(loginUserVO.getUserId());
    	
    	if(!userService.create(userFormVO.getUserVO())){
    		model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "이미 등록된 코드유형 입니다.");
    		return "/user/edit";
    	}
        status.setComplete();
        return "forward:/user/retrievePagingList.do";
    }
    
    /**
     * AJAX를 통해 사용중인 ID인지 검사 한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/user/retrieveAjax.do")    
    public String retrieveAjax(UserVO userVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	UserVO existUserVO = userService.retrieve(userVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(existUserVO == null){
	    	model.addAttribute("returnMessage", "success");
		}else{
			model.addAttribute("returnMessage", "fail");
		}
    	
    	return "jsonView";
	}
	


    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/user/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/user/updateView.do")
    public String updateView(
    		UserFormVO userFormVO ,ModelMap model)
            throws Exception {
    	userFormVO.setUserVO(userService.retrieve(userFormVO.getUserVO()));
        retrieveCmmnCode(model);
        return "/user/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/user/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/user/update.do")
    public String update(
    		HttpServletRequest request,
    		UserFormVO userFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("userVO: "+userFormVO.getUserVO());
    	
    	beanValidator.validate(userFormVO.getUserVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		userFormVO.setUserVO(userFormVO.getUserVO());
			return "/user/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	userFormVO.getUserVO().setUpdtId(loginUserVO.getUserId());
        userService.update(userFormVO.getUserVO());
        status.setComplete();
        return "forward:/user/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param userFormVO.getSearchUserVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/user/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/user/delete.do")
    public String delete(
    		UserFormVO userFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	userFormVO.getUserVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("userVO: "+userFormVO.getUserVO());
        userService.delete(userFormVO.getUserVO());
        status.setComplete();
        return "forward:/user/retrievePagingList.do";
    }
}