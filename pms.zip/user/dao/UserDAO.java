package kr.go.mosf.pms.user.dao;

import java.util.List;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;


@Repository("userDAO")
public class UserDAO extends EgovAbstractDAO {
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 UserVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String create(UserVO vo) throws Exception {
        return (String)insert("userDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 UserVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(UserVO vo) throws Exception {
        return update("userDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 UserVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(UserVO vo) throws Exception {
        return delete("userDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public UserVO retrieve(UserVO vo) throws Exception {
        return (UserVO) selectByPk("userDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<UserVO> retrievePagingList(UserVO vo) throws Exception {
        return (List<UserVO>)list("userDAO.retrievePagingList", vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(UserVO vo) {
        return (Integer)getSqlMapClientTemplate().queryForObject("userDAO.retrievePagingListCnt", vo);
    }
}
