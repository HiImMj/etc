package kr.go.mosf.pms.recsroom.vo;

import java.util.ArrayList;
import java.util.List;

import kr.go.mosf.pms.base.vo.BaseVO;

import org.springframework.web.multipart.MultipartFile;

public class RecsroomVO extends BaseVO{
	private long recsroomSn;
	private int bsnsSn;
    private String recsroomSj;
    private String recsroomCn;
    private int rdcnt;
    
    private List<RecsroomAtchmnflVO> recsroomAtchmnflVOList = new ArrayList<RecsroomAtchmnflVO>();
    
    private MultipartFile file;
    private List<MultipartFile> files = new ArrayList<MultipartFile>();
    
	public long getRecsroomSn() {
		return recsroomSn;
	}
	public void setRecsroomSn(long recsroomSn) {
		this.recsroomSn = recsroomSn;
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getRecsroomSj() {
		return recsroomSj;
	}
	public void setRecsroomSj(String recsroomSj) {
		this.recsroomSj = recsroomSj;
	}
	public String getRecsroomCn() {
		return recsroomCn;
	}
	public void setRecsroomCn(String recsroomCn) {
		this.recsroomCn = recsroomCn;
	}
	public int getRdcnt() {
		return rdcnt;
	}
	public void setRdcnt(int rdcnt) {
		this.rdcnt = rdcnt;
	}
	public List<RecsroomAtchmnflVO> getRecsroomAtchmnflVOList() {
		return recsroomAtchmnflVOList;
	}
	public void setRecsroomAtchmnflVOList(List<RecsroomAtchmnflVO> recsroomAtchmnflVOList) {
		this.recsroomAtchmnflVOList = recsroomAtchmnflVOList;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public List<MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}    
	
	
}
