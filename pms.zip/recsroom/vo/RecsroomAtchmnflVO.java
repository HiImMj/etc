package kr.go.mosf.pms.recsroom.vo;

import org.springframework.web.multipart.MultipartFile;

import kr.go.mosf.pms.base.vo.BaseVO;

public class RecsroomAtchmnflVO extends BaseVO{
	public static final String FILE_PATH = "recsroom/";
	
	private long recsroomSn;
	private int sn;
	private String recsroomOrginlFileNm;
	private String recsroomStreAllCours;
	
	private MultipartFile file;
	
	public long getRecsroomSn() {
		return recsroomSn;
	}
	public void setRecsroomSn(long recsroomSn) {
		this.recsroomSn = recsroomSn;
	}
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getRecsroomOrginlFileNm() {
		return recsroomOrginlFileNm;
	}
	public void setRecsroomOrginlFileNm(String recsroomOrginlFileNm) {
		this.recsroomOrginlFileNm = recsroomOrginlFileNm;
	}
	public String getRecsroomStreAllCours() {
		return recsroomStreAllCours;
	}
	public void setRecsroomStreAllCours(String recsroomStreAllCours) {
		this.recsroomStreAllCours = recsroomStreAllCours;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	
	
}
