package kr.go.mosf.pms.recsroom.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.recsroom.service.RecsroomService;
import kr.go.mosf.pms.recsroom.vo.RecsroomAtchmnflVO;
import kr.go.mosf.pms.recsroom.vo.RecsroomVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class RecsroomController extends BaseController{
	@Resource(name = "recsroomService")
	private RecsroomService recsroomService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 RecsroomVO
	 * @param model
	 * @return "/recsroom/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/recsroom/retrievePagingList.do")
    public String retrievePagingList(@ModelAttribute("searchVO") RecsroomVO searchVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		searchVO.setDeleteYn("N");
        List<RecsroomVO> sampleList = recsroomService.retrievePagingList(searchVO);
        model.addAttribute("resultList", sampleList);
        
        int totCnt = recsroomService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());        
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        
        return "/recsroom/list";
    } 
    
    
//    /**
//	 * 글을 조회한다.
//	 * @param recsroomVO - 조회할 정보가 담긴 VO
//	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
//	 * @param status
//	 * @return @ModelAttribute("recsroomVO") - 조회한 정보
//	 * @exception Exception
//	 */
//    @RequestMapping("/recsroom/retrieve.do")
//    public @ModelAttribute("recsroomVO")
//    RecsroomVO retrieve(
//            RecsroomVO recsroomVO,
//            @ModelAttribute("searchVO") RecsroomVO searchRecsroomVO) throws Exception {
//        return recsroomService.retrieve(recsroomVO);
//    }
		
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/recsroom/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/recsroom/createView.do")
    public String createView(
            @ModelAttribute("searchVO") RecsroomVO searchVO, Model model)
            throws Exception {
        model.addAttribute("recsroomVO", new RecsroomVO());
        
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());        
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        
        return "/recsroom/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param recsroomVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/recsroom/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/recsroom/create.do")
    public String create(
    		RecsroomVO recsroomVO,
         	  HttpServletRequest request,
    		@ModelAttribute("searchVO") RecsroomVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(recsroomVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("recsroomVO", recsroomVO);
			return "/recsroom/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	recsroomVO.setCreatId(loginUserVO.getUserId());
    	
    	//첨부파일 정보 준비
    	createRecsroomAtchmnfList(recsroomVO);
    	
        recsroomService.create(recsroomVO);
        status.setComplete();
        return "forward:/recsroom/retrievePagingList.do";
    }


	private void createRecsroomAtchmnfList(RecsroomVO recsroomVO) {
		//둘 이상일때
    	List<MultipartFile> files = recsroomVO.getFiles();  
    	for(MultipartFile inFile:files){
	    	if(inFile != null && !GenericValidator.isBlankOrNull(inFile.getOriginalFilename())){
	    		RecsroomAtchmnflVO recsroomAtchmnflVO = new RecsroomAtchmnflVO();
	    		recsroomAtchmnflVO.setRecsroomOrginlFileNm(inFile.getOriginalFilename());
	    		recsroomAtchmnflVO.setRecsroomStreAllCours(RecsroomAtchmnflVO.FILE_PATH);
	    		recsroomAtchmnflVO.setFile(inFile);
	    		recsroomVO.getRecsroomAtchmnflVOList().add(recsroomAtchmnflVO);
	    	}
    	}
	}
    
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/recsroom/fileDown.do")    
    public void fileDown(RecsroomAtchmnflVO recsroomAtchmnflVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	RecsroomAtchmnflVO exsitRecsroomAtchmnflVO = recsroomService.retrieveRecsroomAtchmnflVO(recsroomAtchmnflVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(exsitRecsroomAtchmnflVO != null){
    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitRecsroomAtchmnflVO.getRecsroomStreAllCours());
    		int sourceFileSize = (int)sourceFile.length();
    		
    		File downFile = new File(MOSFPMSDefine.filePath + exsitRecsroomAtchmnflVO.getRecsroomStreAllCours()+"decrypt");
    		if(sourceFileSize>0){
    			cryptoService.decrypt(sourceFile, MOSFPMSDefine.ENCRYPT_PASSWORD, downFile);
    		}
    		
    		String sourceFileName = exsitRecsroomAtchmnflVO.getRecsroomOrginlFileNm();
    		
    		try{
    			downloadFile(request, response, downFile, sourceFileName);
    		}catch(Exception e){
    			logger.error(e.getMessage());
    			throw e;
    		}finally{
    			try{
        			FileUtils.forceDelete(downFile);
        		}catch(Exception e){
        			e.printStackTrace();
        		}
    		}
    		
    		
		}
	}

    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/recsroom/deletefileAjax.do")    
    public String deletefileAjax(RecsroomAtchmnflVO recsroomAtchmnflVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	RecsroomAtchmnflVO exsitRecsroomAtchmnflVO = recsroomService.retrieveRecsroomAtchmnflVO(recsroomAtchmnflVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(exsitRecsroomAtchmnflVO != null){
    		try{
	    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitRecsroomAtchmnflVO.getRecsroomStreAllCours());
	    		FileUtils.forceDelete(sourceFile);
	    		recsroomService.deleteRecsroomAtchmnflVO(exsitRecsroomAtchmnflVO);
	    		model.addAttribute("returnMessage", "success");
    		}catch(Exception e){
    			model.addAttribute("returnMessage", "fail");
    		}
    		
		}
    	
    	return "jsonView";
	}
	


    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/recsroom/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/recsroom/updateView.do")
    public String updateView(
            @ModelAttribute("searchVO") RecsroomVO searchVO,
            @ModelAttribute("recsroomSn") RecsroomVO recsroomVO ,Model model)
            throws Exception {
        model.addAttribute(recsroomService.retrieve(recsroomVO));
        
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());        
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        return "/recsroom/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param recsroomVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/recsroom/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/recsroom/update.do")
    public String update(
    		RecsroomVO recsroomVO, 
            HttpServletRequest request,
            @ModelAttribute("searchVO") RecsroomVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("recsroomVO: "+recsroomVO);
    	
    	beanValidator.validate(recsroomVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("recsroomVO", recsroomVO);
			return "/recsroom/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	recsroomVO.setUpdtId(loginUserVO.getUserId());
    	
    	//첨부파일 정보 준비
    	createRecsroomAtchmnfList(recsroomVO);
    	
        recsroomService.update(recsroomVO);
        status.setComplete();
        return "forward:/recsroom/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param recsroomVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/recsroom/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/recsroom/delete.do")
    public String delete(
            RecsroomVO recsroomVO,
            HttpServletRequest request,
            @ModelAttribute("searchVO") RecsroomVO searchVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	recsroomVO.setCreatId(loginUserVO.getUserId());
    	
    	logger.info("recsroomVO: "+recsroomVO);
        recsroomService.delete(recsroomVO);
        status.setComplete();
        return "forward:/recsroom/retrievePagingList.do";
    }
}
