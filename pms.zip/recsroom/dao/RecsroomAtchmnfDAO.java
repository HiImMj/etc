package kr.go.mosf.pms.recsroom.dao;

import java.util.List;

import kr.go.mosf.pms.recsroom.vo.RecsroomAtchmnflVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("recsroomAtchmnfDAO")
public class RecsroomAtchmnfDAO extends EgovAbstractDAO {
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 RecsroomAtchmnflVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Integer create(RecsroomAtchmnflVO vo) throws Exception {    	
        return (Integer)insert("recsroomAtchmnfDAO.create", vo);
    }    

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 RecsroomAtchmnflVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(RecsroomAtchmnflVO vo) throws Exception {
        return delete("recsroomAtchmnfDAO.delete", vo);
    }
    
    /**
	 * 글 목록을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 RecsroomAtchmnflVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteList(RecsroomAtchmnflVO vo) throws Exception {
        return delete("recsroomAtchmnfDAO.deleteList", vo);
    }
    
    public RecsroomAtchmnflVO retrieve(RecsroomAtchmnflVO vo) throws Exception {
        return (RecsroomAtchmnflVO)selectByPk("recsroomAtchmnfDAO.retrieve", vo);
    }
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 RecsroomAtchmnflVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<RecsroomAtchmnflVO> retrieveList(RecsroomAtchmnflVO vo) throws Exception {
        return (List<RecsroomAtchmnflVO>)list("recsroomAtchmnfDAO.retrieveList", vo);
    }
}
