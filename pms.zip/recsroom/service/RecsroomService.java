package kr.go.mosf.pms.recsroom.service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.recsroom.dao.RecsroomAtchmnfDAO;
import kr.go.mosf.pms.recsroom.dao.RecsroomDAO;
import kr.go.mosf.pms.recsroom.vo.RecsroomAtchmnflVO;
import kr.go.mosf.pms.recsroom.vo.RecsroomVO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


@Service("recsroomService")
public class RecsroomService extends BaseService{
	@Resource(name="recsroomDAO")
	private RecsroomDAO recsroomDAO;
	
	@Resource(name="recsroomAtchmnfDAO")
	private RecsroomAtchmnfDAO recsroomAtchmnfDAO;
	
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 RecsroomVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Long create(RecsroomVO vo) throws Exception {
    	Long recsroomSn = recsroomDAO.create(vo);
    	for(RecsroomAtchmnflVO recsroomAtchmnflVO:vo.getRecsroomAtchmnflVOList()){
    		recsroomAtchmnflVO.setRecsroomSn(recsroomSn);
    		recsroomAtchmnflVO.setRecsroomStreAllCours(RecsroomAtchmnflVO.FILE_PATH+recsroomSn+"/"+System.currentTimeMillis());
    		recsroomAtchmnfDAO.create(recsroomAtchmnflVO);
    		
    		logger.debug("recsroomAtchmnflVO: "+recsroomAtchmnflVO);
    		//첨부파일 처리
    		MultipartFile file = recsroomAtchmnflVO.getFile();
    		
    		File filePath = new File(FilenameUtils.getFullPath(MOSFPMSDefine.filePath + recsroomAtchmnflVO.getRecsroomStreAllCours()));
    		if(!filePath.exists()){
    			filePath.mkdirs();
    		}
    		
    		File tempFile = new File(MOSFPMSDefine.filePath + recsroomAtchmnflVO.getRecsroomStreAllCours()+"temp");
    		File encFile = new File(MOSFPMSDefine.filePath + recsroomAtchmnflVO.getRecsroomStreAllCours());
    		IOUtils.write(file.getBytes(), new FileOutputStream(tempFile));
    		
    		//암호화 처리
    		cryptoService.encrypt(tempFile, MOSFPMSDefine.ENCRYPT_PASSWORD, encFile);
    		try{
    			FileUtils.forceDelete(tempFile);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}    	
        return recsroomSn;
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 RecsroomVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(RecsroomVO vo) throws Exception {
        int cnt = 0;
        cnt = recsroomDAO.update(vo);
        for(RecsroomAtchmnflVO recsroomAtchmnflVO:vo.getRecsroomAtchmnflVOList()){
    		recsroomAtchmnflVO.setRecsroomSn(vo.getRecsroomSn());
    		recsroomAtchmnflVO.setRecsroomStreAllCours(RecsroomAtchmnflVO.FILE_PATH+vo.getRecsroomSn()+"/"+System.currentTimeMillis());
    		recsroomAtchmnfDAO.create(recsroomAtchmnflVO);
    		
    		logger.debug("recsroomAtchmnflVO: "+recsroomAtchmnflVO);
    		//첨부파일 처리
    		MultipartFile file = recsroomAtchmnflVO.getFile();
    		
    		File filePath = new File(FilenameUtils.getFullPath(MOSFPMSDefine.filePath + recsroomAtchmnflVO.getRecsroomStreAllCours()));
    		if(!filePath.exists()){
    			filePath.mkdirs();
    		}
    		
    		File tempFile = new File(MOSFPMSDefine.filePath + recsroomAtchmnflVO.getRecsroomStreAllCours()+"temp");
    		File encFile = new File(MOSFPMSDefine.filePath + recsroomAtchmnflVO.getRecsroomStreAllCours());
    		IOUtils.write(file.getBytes(), new FileOutputStream(tempFile));
    		
    		//암호화 처리
    		cryptoService.encrypt(tempFile, MOSFPMSDefine.ENCRYPT_PASSWORD, encFile);
    		try{
    			FileUtils.forceDelete(tempFile);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}
        return cnt;
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 RecsroomVO
	 * @return void형 
	 * @exception Exception
	 */
    public void delete(RecsroomVO vo) throws Exception {
    	int cnt = 0;
        cnt = recsroomDAO.delete(vo);
        
        //파일 삭제 프로세스 추가 필요.
//        RecsroomAtchmnflVO recsroomAtchmnflVO = new RecsroomAtchmnflVO();
//        recsroomAtchmnflVO.setRecsroomSn(vo.getRecsroomSn());
//        recsroomAtchmnfDAO.deleteList(recsroomAtchmnflVO);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 RecsroomVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public RecsroomVO retrieve(RecsroomVO vo) throws Exception {
    	RecsroomVO recsroomVO = recsroomDAO.retrieve(vo);
    	if(recsroomVO != null){
    		RecsroomAtchmnflVO recsroomAtchmnflVO = new RecsroomAtchmnflVO();
            recsroomAtchmnflVO.setRecsroomSn(recsroomVO.getRecsroomSn());
            recsroomVO.setRecsroomAtchmnflVOList(recsroomAtchmnfDAO.retrieveList(recsroomAtchmnflVO));
    	}
        return recsroomVO;
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 RecsroomVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<RecsroomVO> retrievePagingList(RecsroomVO vo) throws Exception {
        return recsroomDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 RecsroomVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(RecsroomVO vo) {
        return recsroomDAO.retrievePagingListCnt(vo);
    }
    
    public RecsroomAtchmnflVO retrieveRecsroomAtchmnflVO(RecsroomAtchmnflVO vo) throws Exception{
    	return recsroomAtchmnfDAO.retrieve(vo);
    }
    
    public int deleteRecsroomAtchmnflVO(RecsroomAtchmnflVO vo) throws Exception{
    	return recsroomAtchmnfDAO.delete(vo);
    }
	
}
