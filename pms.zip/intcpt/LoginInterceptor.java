package kr.go.mosf.pms.intcpt;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginInterceptor extends HandlerInterceptorAdapter {
	protected Logger logger = Logger.getLogger(this.getClass().getName());
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		//원래는 로그인 정보 및 접근 제한 체크
		HttpSession session = request.getSession();
		UserVO loginUserVO = (UserVO)session.getAttribute(UserVO.LOGIN_USER_VO);
		
		
//		if(loginUserVO == null){
//		//임시 개발을 위해 추가
//			loginUserVO = new UserVO();
//			loginUserVO.setUserId("igmanager");
//			session.setAttribute(UserVO.LOGIN_USER_VO, loginUserVO);
//		}
		
		String uri		= request.getRequestURI();
		logger.debug("uri: "+uri);
		if(uri.startsWith(request.getContextPath()+"/login/") 
				||uri.startsWith(request.getContextPath()+"/userEntry/")){// 예외 페이지 uri  
			//로그인
			//사용자등록
		}else{			
			if(loginUserVO == null){
				//튕겨버리기 불법 접근
				response.sendRedirect(request.getContextPath()+ "/login/loginView.do");
				return false;
			}
		}

		
		return super.preHandle(request, response, handler);
	}
}