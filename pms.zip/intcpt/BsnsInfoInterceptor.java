package kr.go.mosf.pms.intcpt;

import java.util.Enumeration;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.go.mosf.pms.bsnsaccesauthor.service.BsnsAccesAuthorService;
import kr.go.mosf.pms.bsnsaccesauthor.vo.BsnsAccesAuthorVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class BsnsInfoInterceptor extends HandlerInterceptorAdapter {
	protected Logger logger = Logger.getLogger(this.getClass().getName());
	
	@Resource(name = "bsnsAccesAuthorService")
	private BsnsAccesAuthorService bsnsAccesAuthorService;
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		//원래는 로그인 정보 및 접근 제한 체크
		HttpSession session = request.getSession();
		UserVO loginUserVO = (UserVO)session.getAttribute(UserVO.LOGIN_USER_VO);
		
		//로그인 전이면 해당 사항 없음.
		if(loginUserVO == null){
			return super.preHandle(request, response, handler);
		}
		
		String uri		= request.getRequestURI();
		logger.debug("uri: "+uri);
		
		
		if(uri.startsWith(request.getContextPath()+"/bsnsinfo/")
				||uri.startsWith(request.getContextPath()+"/dailscrtychck/")
				||uri.startsWith(request.getContextPath()+"/bsnsexcinstt/")
				||uri.startsWith(request.getContextPath()+"/inpthnf/")
				||uri.startsWith(request.getContextPath()+"/inpthnfchrgjob/")
				||uri.startsWith(request.getContextPath()+"/inpteqpmn/")
				||uri.startsWith(request.getContextPath()+"/scrtyedcdta/")
				){// 사업접근권한 체크 대상
			
			Enumeration<String> names = request.getParameterNames();
			while(names.hasMoreElements()){
				String key = names.nextElement();
				
				if(key.toUpperCase().indexOf("BSNSSN")>-1){
					logger.debug("key: "+key);
					String value = request.getParameter(key);
					
					if(Integer.parseInt(value) != 0){
						BsnsAccesAuthorVO bsnsAccesAuthorVO = new BsnsAccesAuthorVO();
						bsnsAccesAuthorVO.setBsnsSn(Integer.parseInt(value));
						
						BsnsAccesAuthorVO exsitBsnsAccesAuthorVO = bsnsAccesAuthorService.retrieve(bsnsAccesAuthorVO);
						if(exsitBsnsAccesAuthorVO == null
								|| exsitBsnsAccesAuthorVO.getBsnsAccesAuthorSttusCode().equals(BsnsAccesAuthorVO.BSNS_ACCES_AUTHOR_STTUS_CODE_STOP)){
							//비인가 사업 접근 시도
							response.sendRedirect(request.getContextPath()+ "/cmmn/notAllow.do");
							return false;
						}
					}
				}
				
			}
		}

		
		return super.preHandle(request, response, handler);
	}
}