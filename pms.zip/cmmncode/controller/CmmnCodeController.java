package kr.go.mosf.pms.cmmncode.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeTypeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeFormVO;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeTypeVO;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


@Controller
public class CmmnCodeController extends BaseController{
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;

	@Resource(name = "cmmnCodeTypeService")
	private CmmnCodeTypeService cmmnCodeTypeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 CmmnCodeVO
	 * @param model
	 * @return "/cmmnCode/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/cmmnCode/retrievePagingList.do")
    public String retrievePagingList(CmmnCodeFormVO cmmnCodeFormVO, 
    		ModelMap model)
            throws Exception {
    	CmmnCodeVO searchVO = cmmnCodeFormVO.getSearchCmmnCodeVO();
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		searchVO.setDeleteYn("N");
        List<CmmnCodeVO> sampleList = cmmnCodeService.retrievePagingList(searchVO);
        model.addAttribute("resultList", sampleList);
        
        int totCnt = cmmnCodeService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        retrieveCmmnCodeTypeList(model);
    	
        return "/cmmncode/list";
    }
    
    //유형 전체 목록 리스트
	private void retrieveCmmnCodeTypeList(ModelMap model) throws Exception {
		List<CmmnCodeTypeVO> cmmnCodeTypeVOList = cmmnCodeTypeService.retrieveList(new CmmnCodeTypeVO());
    	model.addAttribute("cmmnCodeTypeVOList", cmmnCodeTypeVOList);
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/cmmnCode/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCode/createView.do")
    public String createView(
    		CmmnCodeFormVO cmmnCodeFormVO, ModelMap model)
            throws Exception {        
        cmmnCodeFormVO.setCmmnCodeVO(new CmmnCodeVO());
        retrieveCmmnCodeTypeList(model);
        return "/cmmncode/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param cmmnCodeVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/cmmnCode/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCode/create.do")
    public String create(
         	  HttpServletRequest request,
         	 CmmnCodeFormVO cmmnCodeFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(cmmnCodeFormVO.getCmmnCodeVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("cmmnCodeVO", cmmnCodeFormVO.getCmmnCodeVO());
			return "/cmmncode/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	cmmnCodeFormVO.getCmmnCodeVO().setCreatId(loginUserVO.getUserId());
    	
    	if(!cmmnCodeService.create(cmmnCodeFormVO.getCmmnCodeVO())){
    		model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "이미 등록된 코드유형 입니다.");
    		return "/cmmncode/edit";
    	}
        status.setComplete();
        return "forward:/cmmnCode/retrievePagingList.do";
    }
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/cmmnCode/retrieveAjax.do")    
    public String retrieveAjax(CmmnCodeVO cmmnCodeVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	CmmnCodeVO existCmmnCodeVO = cmmnCodeService.retrieve(cmmnCodeVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(existCmmnCodeVO == null){
	    	model.addAttribute("returnMessage", "success");
		}else{
			model.addAttribute("returnMessage", "fail");
		}
    	
    	return "jsonView";
	}
	


    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/cmmnCode/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCode/updateView.do")
    public String updateView(
    		CmmnCodeFormVO cmmnCodeFormVO,
            ModelMap model)
            throws Exception {        
        cmmnCodeFormVO.setCmmnCodeVO(cmmnCodeService.retrieve(cmmnCodeFormVO.getCmmnCodeVO()));
        retrieveCmmnCodeTypeList(model);
        return "/cmmncode/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param cmmnCodeVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/cmmnCode/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCode/update.do")
    public String update(
            HttpServletRequest request,
            CmmnCodeFormVO cmmnCodeFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("cmmnCodeVO: "+cmmnCodeFormVO.getCmmnCodeVO());
    	
    	beanValidator.validate(cmmnCodeFormVO.getCmmnCodeVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("cmmnCodeVO", cmmnCodeFormVO.getCmmnCodeVO());
			return "/cmmncode/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	cmmnCodeFormVO.getCmmnCodeVO().setUpdtId(loginUserVO.getUserId());
        cmmnCodeService.update(cmmnCodeFormVO.getCmmnCodeVO());
        status.setComplete();
        return "forward:/cmmnCode/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param cmmnCodeVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/cmmnCode/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCode/delete.do")
    public String delete(
            HttpServletRequest request,
            CmmnCodeFormVO cmmnCodeFormVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	cmmnCodeFormVO.getCmmnCodeVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("cmmnCodeVO: "+cmmnCodeFormVO.getCmmnCodeVO());
        cmmnCodeService.delete(cmmnCodeFormVO.getCmmnCodeVO());
        status.setComplete();
        return "forward:/cmmnCode/retrievePagingList.do";
    }
}
