package kr.go.mosf.pms.cmmncode.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeTypeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeTypeVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class CmmnCodeTypeController extends BaseController{
	@Resource(name = "cmmnCodeTypeService")
	private CmmnCodeTypeService cmmnCodeTypeService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 CmmnCodeTypeVO
	 * @param model
	 * @return "/cmmnCodeType/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/cmmnCodeType/retrievePagingList.do")
    public String retrievePagingList(@ModelAttribute("searchVO") CmmnCodeTypeVO searchVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		searchVO.setDeleteYn("N");
        List<CmmnCodeTypeVO> sampleList = cmmnCodeTypeService.retrievePagingList(searchVO);
        model.addAttribute("resultList", sampleList);
        
        int totCnt = cmmnCodeTypeService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/cmmncodetype/list";
    } 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/cmmnCodeType/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCodeType/createView.do")
    public String createView(
            @ModelAttribute("searchVO") CmmnCodeTypeVO searchVO, Model model)
            throws Exception {
        model.addAttribute("cmmnCodeTypeVO", new CmmnCodeTypeVO());
        return "/cmmncodetype/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param cmmnCodeTypeVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/cmmnCodeType/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCodeType/create.do")
    public String create(
    		CmmnCodeTypeVO cmmnCodeTypeVO,
         	  HttpServletRequest request,
    		@ModelAttribute("searchVO") CmmnCodeTypeVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(cmmnCodeTypeVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("cmmnCodeTypeVO", cmmnCodeTypeVO);
			return "/cmmncodetype/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	cmmnCodeTypeVO.setCreatId(loginUserVO.getUserId());
    	
    	if(!cmmnCodeTypeService.create(cmmnCodeTypeVO)){
    		model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "이미 등록된 코드유형 입니다.");
    		return "/cmmncodetype/edit";
    	}
        status.setComplete();
        return "forward:/cmmnCodeType/retrievePagingList.do";
    }
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/cmmnCodeType/retrieveAjax.do")    
    public String retrieveAjax(CmmnCodeTypeVO cmmnCodeTypeVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	CmmnCodeTypeVO existCmmnCodeTypeVO = cmmnCodeTypeService.retrieve(cmmnCodeTypeVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(existCmmnCodeTypeVO == null){
	    	model.addAttribute("returnMessage", "success");
		}else{
			model.addAttribute("returnMessage", "fail");
		}
    	
    	return "jsonView";
	}
	


    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/cmmnCodeType/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCodeType/updateView.do")
    public String updateView(
            @ModelAttribute("searchVO") CmmnCodeTypeVO searchVO,
            @ModelAttribute("cmmnCodeTy") CmmnCodeTypeVO cmmnCodeTypeVO ,Model model)
            throws Exception {
        model.addAttribute(cmmnCodeTypeService.retrieve(cmmnCodeTypeVO));
        return "/cmmncodetype/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param cmmnCodeTypeVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/cmmnCodeType/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCodeType/update.do")
    public String update(
    		CmmnCodeTypeVO cmmnCodeTypeVO, 
            HttpServletRequest request,
            @ModelAttribute("searchVO") CmmnCodeTypeVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("cmmnCodeTypeVO: "+cmmnCodeTypeVO);
    	
    	beanValidator.validate(cmmnCodeTypeVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("cmmnCodeTypeVO", cmmnCodeTypeVO);
			return "/cmmncodetype/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	cmmnCodeTypeVO.setUpdtId(loginUserVO.getUserId());
        cmmnCodeTypeService.update(cmmnCodeTypeVO);
        status.setComplete();
        return "forward:/cmmnCodeType/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param cmmnCodeTypeVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/cmmnCodeType/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/cmmnCodeType/delete.do")
    public String delete(
            CmmnCodeTypeVO cmmnCodeTypeVO,
            HttpServletRequest request,
            @ModelAttribute("searchVO") CmmnCodeTypeVO searchVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	cmmnCodeTypeVO.setCreatId(loginUserVO.getUserId());
    	
    	logger.info("cmmnCodeTypeVO: "+cmmnCodeTypeVO);
        cmmnCodeTypeService.delete(cmmnCodeTypeVO);
        status.setComplete();
        return "forward:/cmmnCodeType/retrievePagingList.do";
    }
}
