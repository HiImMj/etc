package kr.go.mosf.pms.cmmncode.dao;

import java.util.List;

import kr.go.mosf.pms.cmmncode.vo.CmmnCodeTypeVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("cmmnCodeTypeDAO")
public class CmmnCodeTypeDAO extends EgovAbstractDAO {
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 CmmnCodeTypeVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public void create(CmmnCodeTypeVO vo) throws Exception {
        insert("cmmnCodeTypeDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 CmmnCodeTypeVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(CmmnCodeTypeVO vo) throws Exception {
        return update("cmmnCodeTypeDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 CmmnCodeTypeVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(CmmnCodeTypeVO vo) throws Exception {
        return delete("cmmnCodeTypeDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 CmmnCodeTypeVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public CmmnCodeTypeVO retrieve(CmmnCodeTypeVO vo) throws Exception {
        return (CmmnCodeTypeVO) selectByPk("cmmnCodeTypeDAO.retrieve", vo);
    }
    
    /**
   	 * 글 페이징 목록을 조회한다.
   	 * @param vo - 조회할 정보가 담긴 CmmnCodeTypeVO
   	 * @return 글 목록
   	 * @exception Exception
   	 */
       @SuppressWarnings("unchecked")
   	public List<CmmnCodeTypeVO> retrieveList(CmmnCodeTypeVO vo) throws Exception {
           return (List<CmmnCodeTypeVO>)list("cmmnCodeTypeDAO.retrieveList", vo);
       }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 CmmnCodeTypeVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CmmnCodeTypeVO> retrievePagingList(CmmnCodeTypeVO vo) throws Exception {
        return (List<CmmnCodeTypeVO>)list("cmmnCodeTypeDAO.retrievePagingList", vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 CmmnCodeTypeVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(CmmnCodeTypeVO vo) {
        return (Integer)getSqlMapClientTemplate().queryForObject("cmmnCodeTypeDAO.retrievePagingListCnt", vo);
    }
}
