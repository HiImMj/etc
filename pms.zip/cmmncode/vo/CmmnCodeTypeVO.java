package kr.go.mosf.pms.cmmncode.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class CmmnCodeTypeVO extends BaseVO {
	private String cmmnCodeTy;
	private String cmmnCodeTyNm;
	private String cmmnCodeTyDc;

	public String getCmmnCodeTy() {
		return cmmnCodeTy;
	}

	public void setCmmnCodeTy(String cmmnCodeTy) {
		this.cmmnCodeTy = cmmnCodeTy;
	}

	public String getCmmnCodeTyNm() {
		return cmmnCodeTyNm;
	}

	public void setCmmnCodeTyNm(String cmmnCodeTyNm) {
		this.cmmnCodeTyNm = cmmnCodeTyNm;
	}

	public String getCmmnCodeTyDc() {
		return cmmnCodeTyDc;
	}

	public void setCmmnCodeTyDc(String cmmnCodeTyDc) {
		this.cmmnCodeTyDc = cmmnCodeTyDc;
	}

}
