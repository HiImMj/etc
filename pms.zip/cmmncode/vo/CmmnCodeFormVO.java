package kr.go.mosf.pms.cmmncode.vo;

import java.util.ArrayList;
import java.util.List;

public class CmmnCodeFormVO {
	private CmmnCodeVO searchCmmnCodeVO;
	private CmmnCodeVO cmmnCodeVO;
	private List<CmmnCodeVO> list;
	
	public CmmnCodeFormVO(){
		searchCmmnCodeVO = new CmmnCodeVO();
		cmmnCodeVO = new CmmnCodeVO();
		list = new ArrayList<CmmnCodeVO>();
	}
	
	public CmmnCodeVO getSearchCmmnCodeVO() {
		return searchCmmnCodeVO;
	}
	public void setSearchCmmnCodeVO(CmmnCodeVO searchCmmnCodeVO) {
		this.searchCmmnCodeVO = searchCmmnCodeVO;
	}
	public CmmnCodeVO getCmmnCodeVO() {
		return cmmnCodeVO;
	}
	public void setCmmnCodeVO(CmmnCodeVO cmmnCodeVO) {
		this.cmmnCodeVO = cmmnCodeVO;
	}
	public List<CmmnCodeVO> getList() {
		return list;
	}
	public void setList(List<CmmnCodeVO> list) {
		this.list = list;
	}
	
	
}
