package kr.go.mosf.pms.cmmncode.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class CmmnCodeVO extends BaseVO{
	public static final String BSNS_PROGR_SSTTUS_CODE = "A001"; //사업진행_상태코드
	public static final String USER_TY_CODE = "A002";   //계정유형
	public static final String USER_STTUS_CODE = "A003"; //계정상태
	public static final String PARTCPTN_STTUS_CODE = "A004"; //투입인력참여상태코드
	public static final String INPT_EQPMN_TY_CODE = "A005"; //투입인력참여상태코드
	public static final String INPT_EQPMN_PROGRS_STTUS_CODE = "A006"; //투입인력참여상태코드
	public static final String BSNS_PARTCPTN_SE_CODE = "A007"; //사업참여구분코드
	
	public static final String BSNS_ACCES_AUTHOR_STTUS_CODE = "A008"; //사업접근권한상태코드
	
	public static final String PROCESS_PROGRS_STTUS_CODE = "A009"; //업무처리진행상태코드
	
	public static final String SCRTY_CHCK_IEM_CODE = "S001"; //일일보안점검항목코드
	
	public static final String LOGOUT_STTUS_CODE = "B001"; //로그아웃상태코드
			
	private String cmmnCodeTy;
	private String cmmnCodeTyNm;
    private String  cmmnCode;
    private String  cmmnCodeNm;
    private String  cmmnCodeDc;
    
	public String getCmmnCodeTy() {
		return cmmnCodeTy;
	}
	public void setCmmnCodeTy(String cmmnCodeTy) {
		this.cmmnCodeTy = cmmnCodeTy;
	}
	public String getCmmnCode() {
		return cmmnCode;
	}
	public void setCmmnCode(String cmmnCode) {
		this.cmmnCode = cmmnCode;
	}
	public String getCmmnCodeNm() {
		return cmmnCodeNm;
	}
	public void setCmmnCodeNm(String cmmnCodeNm) {
		this.cmmnCodeNm = cmmnCodeNm;
	}
	public String getCmmnCodeDc() {
		return cmmnCodeDc;
	}
	public void setCmmnCodeDc(String cmmnCodeDc) {
		this.cmmnCodeDc = cmmnCodeDc;
	}
	public String getCmmnCodeTyNm() {
		return cmmnCodeTyNm;
	}
	public void setCmmnCodeTyNm(String cmmnCodeTyNm) {
		this.cmmnCodeTyNm = cmmnCodeTyNm;
	}
    
    
}
