package kr.go.mosf.pms.bsnsexcinstt.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import kr.go.mosf.pms.bsnsexcinstt.vo.BsnsExcInsttVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("bsnsExcInsttDAO")
public class BsnsExcInsttDAO extends EgovAbstractDAO  {	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BsnsExcInsttVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(BsnsExcInsttVO vo) throws Exception {
        return (Integer)insert("bsnsExcInsttDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BsnsExcInsttVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(BsnsExcInsttVO vo) throws Exception {
        return update("bsnsExcInsttDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BsnsExcInsttVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(BsnsExcInsttVO vo) throws Exception {
        return delete("bsnsExcInsttDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsExcInsttVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public BsnsExcInsttVO retrieve(BsnsExcInsttVO vo) throws Exception {
        return (BsnsExcInsttVO) selectByPk("bsnsExcInsttDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsExcInsttVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<BsnsExcInsttVO> retrieveList(BsnsExcInsttVO vo) throws Exception {
        return (List<BsnsExcInsttVO>)list("bsnsExcInsttDAO.retrieveList", vo);
    }    
	
}

