package kr.go.mosf.pms.bsnsexcinstt.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsexcinstt.service.BsnsExcInsttService;
import kr.go.mosf.pms.bsnsexcinstt.vo.BsnsExcInsttFormVO;
import kr.go.mosf.pms.bsnsexcinstt.vo.BsnsExcInsttVO;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class BsnsExcInsttController extends BaseController{
	@Resource(name = "bsnsExcInsttService")
	private BsnsExcInsttService bsnsExcInsttService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param bsnsExcInsttFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/bsnsexcinstt/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/bsnsexcinstt/retrieveList.do")
    public String retrieveList(BsnsExcInsttFormVO bsnsExcInsttFormVO, 
    		ModelMap model)
            throws Exception {
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO().getBsnsSn());
        bsnsExcInsttFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //사업수행기관정보
        List<BsnsExcInsttVO> list = bsnsExcInsttService.retrieveList(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO());
        model.addAttribute("resultList", list);
        
        bsnsExcInsttFormVO.setBsnsExcInsttVO(null);
        
        retrieveCmmnCode(model);
        return "/bsnsexcinstt/edit";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.BSNS_PARTCPTN_SE_CODE);
        model.addAttribute("bsnsPartcptnSeCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param bsnsExcInsttFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsexcinstt/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsexcinstt/createView.do")
    public String createView(
    		BsnsExcInsttFormVO bsnsExcInsttFormVO, ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO().getBsnsSn());
        bsnsExcInsttFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //사업수행기관정보
        List<BsnsExcInsttVO> list = bsnsExcInsttService.retrieveList(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO());
        model.addAttribute("resultList", list);
        
        BsnsExcInsttVO bsnsExcInsttVO = new BsnsExcInsttVO();
        bsnsExcInsttVO.setBsnsSn(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO().getBsnsSn());
        bsnsExcInsttFormVO.setBsnsExcInsttVO(bsnsExcInsttVO);
        
        retrieveCmmnCode(model);
        return "/bsnsexcinstt/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param bsnsExcInsttFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsexcinstt/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsexcinstt/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 BsnsExcInsttFormVO bsnsExcInsttFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(bsnsExcInsttFormVO.getBsnsExcInsttVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/bsnsexcinstt/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	bsnsExcInsttFormVO.getBsnsExcInsttVO().setCreatId(loginUserVO.getUserId());
    	
    	bsnsExcInsttService.create(bsnsExcInsttFormVO.getBsnsExcInsttVO());
    	
        status.setComplete();
        return "forward:/bsnsexcinstt/createView.do";
    }
   
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param bsnsExcInsttFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsexcinstt/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsexcinstt/updateView.do")
    public String updateView(
    		BsnsExcInsttFormVO bsnsExcInsttFormVO ,ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO().getBsnsSn());
        bsnsExcInsttFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //사업수행기관정보
        List<BsnsExcInsttVO> list = bsnsExcInsttService.retrieveList(bsnsExcInsttFormVO.getSearchBsnsExcInsttVO());
        model.addAttribute("resultList", list);
        retrieveCmmnCode(model);
        
        bsnsExcInsttFormVO.setBsnsExcInsttVO(bsnsExcInsttService.retrieve(bsnsExcInsttFormVO.getBsnsExcInsttVO()));
        
        return "/bsnsexcinstt/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param bsnsExcInsttFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsexcinstt/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsexcinstt/update.do")
    public String update(
    		HttpServletRequest request,
    		BsnsExcInsttFormVO bsnsExcInsttFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("bsnsExcInsttVO: "+bsnsExcInsttFormVO.getBsnsExcInsttVO());
    	
    	beanValidator.validate(bsnsExcInsttFormVO.getBsnsExcInsttVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/bsnsexcinstt/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	bsnsExcInsttFormVO.getBsnsExcInsttVO().setUpdtId(loginUserVO.getUserId());
    	bsnsExcInsttService.update(bsnsExcInsttFormVO.getBsnsExcInsttVO());
        status.setComplete();
        return "forward:/bsnsexcinstt/createView.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param bsnsExcInsttFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsexcinstt/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsexcinstt/delete.do")
    public String delete(
    		BsnsExcInsttFormVO bsnsExcInsttFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	bsnsExcInsttFormVO.getBsnsExcInsttVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("bsnsExcInsttVO: "+bsnsExcInsttFormVO.getBsnsExcInsttVO());
    	bsnsExcInsttService.delete(bsnsExcInsttFormVO.getBsnsExcInsttVO());
        status.setComplete();
        return "forward:/bsnsexcinstt/createView.do";
    }

}