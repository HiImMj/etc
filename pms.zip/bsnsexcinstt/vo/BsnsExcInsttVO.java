package kr.go.mosf.pms.bsnsexcinstt.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class BsnsExcInsttVO extends BaseVO{
	private int bsnsSn;					/* 사업_순번 */
	private int sn;						/* 순번 */
	private String bsnsPartcptnSeCode;	/* 사업_참여_구분_코드 */
	private String bsnsPartcptnSeCodeNm;	/* 사업_참여_구분_코드 */
	private String bsnmNm;				/* 사업자_명 */	
	private String bizrno;				/* 사업자등록번호 */
	private String jurirno;				/* 법인등록번호 */
	private int bsnsAmount;				/* 사업_금액 */
	private String chargerNm;			/* 담당자_이름 */
	private String chargerTlphon;		/* 담당자_전화 */
	private String chargerMoblphon;		/* 담당자_휴대전화 */
	private String chargerEmail;		/* 담당자_이메일 */
	
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getBsnsPartcptnSeCode() {
		return bsnsPartcptnSeCode;
	}
	public void setBsnsPartcptnSeCode(String bsnsPartcptnSeCode) {
		this.bsnsPartcptnSeCode = bsnsPartcptnSeCode;
	}
	
	public String getBsnsPartcptnSeCodeNm() {
		return bsnsPartcptnSeCodeNm;
	}
	public void setBsnsPartcptnSeCodeNm(String bsnsPartcptnSeCodeNm) {
		this.bsnsPartcptnSeCodeNm = bsnsPartcptnSeCodeNm;
	}
	public String getBsnmNm() {
		return bsnmNm;
	}
	public void setBsnmNm(String bsnmNm) {
		this.bsnmNm = bsnmNm;
	}
	public String getBizrno() {
		return bizrno;
	}
	public void setBizrno(String bizrno) {
		this.bizrno = bizrno;
	}
	public String getJurirno() {
		return jurirno;
	}
	public void setJurirno(String jurirno) {
		this.jurirno = jurirno;
	}
	public int getBsnsAmount() {
		return bsnsAmount;
	}
	public void setBsnsAmount(int bsnsAmount) {
		this.bsnsAmount = bsnsAmount;
	}
	public String getChargerNm() {
		return chargerNm;
	}
	public void setChargerNm(String chargerNm) {
		this.chargerNm = chargerNm;
	}
	public String getChargerTlphon() {
		return chargerTlphon;
	}
	public void setChargerTlphon(String chargerTlphon) {
		this.chargerTlphon = chargerTlphon;
	}
	public String getChargerMoblphon() {
		return chargerMoblphon;
	}
	public void setChargerMoblphon(String chargerMoblphon) {
		this.chargerMoblphon = chargerMoblphon;
	}
	public String getChargerEmail() {
		return chargerEmail;
	}
	public void setChargerEmail(String chargerEmail) {
		this.chargerEmail = chargerEmail;
	}
	
		
}
