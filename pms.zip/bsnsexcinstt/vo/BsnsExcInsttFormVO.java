package kr.go.mosf.pms.bsnsexcinstt.vo;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.inpteqpmn.vo.InptEqpmnVO;

public class BsnsExcInsttFormVO extends BaseVO{
	private BsnsExcInsttVO searchBsnsExcInsttVO;
	private BsnsExcInsttVO bsnsExcInsttVO;
	private BsnsInfoVO bsnsInfoVO;
	
	public BsnsExcInsttFormVO(){
		searchBsnsExcInsttVO = new BsnsExcInsttVO();
		bsnsExcInsttVO = new BsnsExcInsttVO();
		bsnsInfoVO = new BsnsInfoVO();
	}

	public BsnsExcInsttVO getSearchBsnsExcInsttVO() {
		return searchBsnsExcInsttVO;
	}

	public void setSearchBsnsExcInsttVO(BsnsExcInsttVO searchBsnsExcInsttVO) {
		this.searchBsnsExcInsttVO = searchBsnsExcInsttVO;
	}

	public BsnsExcInsttVO getBsnsExcInsttVO() {
		return bsnsExcInsttVO;
	}

	public void setBsnsExcInsttVO(BsnsExcInsttVO bsnsExcInsttVO) {
		this.bsnsExcInsttVO = bsnsExcInsttVO;
	}

	public BsnsInfoVO getBsnsInfoVO() {
		return bsnsInfoVO;
	}

	public void setBsnsInfoVO(BsnsInfoVO bsnsInfoVO) {
		this.bsnsInfoVO = bsnsInfoVO;
	}
	
	
}
