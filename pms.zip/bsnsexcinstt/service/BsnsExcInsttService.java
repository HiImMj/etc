package kr.go.mosf.pms.bsnsexcinstt.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.bsnsexcinstt.dao.BsnsExcInsttDAO;
import kr.go.mosf.pms.bsnsexcinstt.vo.BsnsExcInsttVO;

import org.springframework.stereotype.Service;

@Service("bsnsExcInsttService")
public class BsnsExcInsttService extends BaseService{
	@Resource(name="bsnsExcInsttDAO")
	private BsnsExcInsttDAO bsnsExcInsttDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BsnsExcInsttVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(BsnsExcInsttVO vo) throws Exception {
    	return bsnsExcInsttDAO.create(vo);  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BsnsExcInsttVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(BsnsExcInsttVO vo) throws Exception {    	
        return bsnsExcInsttDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BsnsExcInsttVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(BsnsExcInsttVO vo) throws Exception {
    	return bsnsExcInsttDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsExcInsttVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public BsnsExcInsttVO retrieve(BsnsExcInsttVO vo) throws Exception {
    	return bsnsExcInsttDAO.retrieve(vo);
    }    
   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsExcInsttVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<BsnsExcInsttVO> retrieveList(BsnsExcInsttVO vo) throws Exception {
        return bsnsExcInsttDAO.retrieveList(vo);
    }

}