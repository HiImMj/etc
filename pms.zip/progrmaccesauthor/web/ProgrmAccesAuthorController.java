package kr.go.mosf.pms.progrmaccesauthor.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.progrmaccesauthor.service.ProgrmAccesAuthorService;
import kr.go.mosf.pms.progrmaccesauthor.vo.ProgrmAccesAuthorVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class ProgrmAccesAuthorController extends BaseController{
	@Resource(name = "progrmAccesAuthorService")
	private ProgrmAccesAuthorService progrmAccesAuthorService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	
	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.USER_TY_CODE);
        model.addAttribute("progrmAccesAuthorCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 ProgrmAccesAuthorVO
	 * @param model
	 * @return "/progrmaccesauthor/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/progrmaccesauthor/retrieveList.do")
    public String retrieveList(ProgrmAccesAuthorVO vo, 
    		ModelMap model)
            throws Exception {
    	retrieveCmmnCode(model);
    	
    	if(GenericValidator.isBlankOrNull(vo.getProgrmAccesAuthorCode())){
    		List<CmmnCodeVO> progrmAccesAuthorCodeVOList = (List<CmmnCodeVO>)model.get(CmmnCodeVO.USER_TY_CODE);
    		if(progrmAccesAuthorCodeVOList != null && progrmAccesAuthorCodeVOList.size()>0){
    			vo.setProgrmAccesAuthorCode(progrmAccesAuthorCodeVOList.get(0).getCmmnCode());
    		}
    	}
    	logger.debug("ProgrmAccesAuthorCode: "+vo.getProgrmAccesAuthorCode());
    	
    	vo.setDeleteYn("N");
        List<ProgrmAccesAuthorVO> resultList = progrmAccesAuthorService.retrieveList(vo);
        model.addAttribute("resultList", resultList);
        
        return "/progrmaccesauthor/list";
    }
  	
    /**
	 * 글을 등록한다.
	 * @param progrmVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/progrmaccesauthor/retrieveList.do"
	 * @exception Exception
	 */
    @RequestMapping("/progrmaccesauthor/createList.do")
    public String createList(
         	  HttpServletRequest request,
         	 ProgrmAccesAuthorVO progrmAccesAuthorVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	// Server-Side Validation
    	beanValidator.validate(progrmAccesAuthorVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("progrmAccesAuthorVO", progrmAccesAuthorVO);
			return "forward:/progrmaccesauthor/retrieveList.do";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	progrmAccesAuthorVO.setCreatId(loginUserVO.getUserId());
    	
        progrmAccesAuthorService.createList(progrmAccesAuthorVO);
        
        status.setComplete();
        return "forward:/progrmaccesauthor/retrieveList.do";
    }
}