package kr.go.mosf.pms.progrmaccesauthor.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.progrmaccesauthor.dao.ProgrmAccesAuthorDAO;
import kr.go.mosf.pms.progrmaccesauthor.vo.ProgrmAccesAuthorVO;

import org.springframework.stereotype.Service;

@Service("progrmAccesAuthorService")
public class ProgrmAccesAuthorService  extends BaseService{
	@Resource(name="progrmAccesAuthorDAO")
	private ProgrmAccesAuthorDAO progrmAccesAuthorDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ProgrmAccesAuthorVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public void createList(ProgrmAccesAuthorVO vo) throws Exception {
    	progrmAccesAuthorDAO.deleteList(vo);
    	for(int progrmSn:vo.getProgrmSns()){
    		vo.setProgrmSn(progrmSn);
    		progrmAccesAuthorDAO.create(vo);
    	}
    }
   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ProgrmAccesAuthorVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<ProgrmAccesAuthorVO> retrieveList(ProgrmAccesAuthorVO vo) throws Exception {
        return progrmAccesAuthorDAO.retrieveList(vo);
    }
}