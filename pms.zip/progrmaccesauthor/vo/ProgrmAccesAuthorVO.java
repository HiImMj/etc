package kr.go.mosf.pms.progrmaccesauthor.vo;

import kr.go.mosf.pms.progrm.vo.ProgrmVO;

public class ProgrmAccesAuthorVO extends ProgrmVO{
	private long progrmSn;					/* 프로그램_순번 */
	private String progrmAccesAuthorCode;		/* 프로그램_접근_권한_코드 */
	
	private Integer[] progrmSns;		/* 프로그램_접근_권한_코드 */
	
	public long getProgrmSn() {
		return progrmSn;
	}
	public void setProgrmSn(long progrmSn) {
		this.progrmSn = progrmSn;
	}
	public String getProgrmAccesAuthorCode() {
		return progrmAccesAuthorCode;
	}
	public void setProgrmAccesAuthorCode(String progrmAccesAuthorCode) {
		this.progrmAccesAuthorCode = progrmAccesAuthorCode;
	}
	public Integer[] getProgrmSns() {
		return progrmSns;
	}
	public void setProgrmSns(Integer[] progrmSns) {
		this.progrmSns = progrmSns;
	}
	
	
}
