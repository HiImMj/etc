package kr.go.mosf.pms.progrmaccesauthor.dao;

import java.util.List;

import kr.go.mosf.pms.progrmaccesauthor.vo.ProgrmAccesAuthorVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("progrmAccesAuthorDAO")
public class ProgrmAccesAuthorDAO extends EgovAbstractDAO{
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ProgrmAccesAuthorVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Long create(ProgrmAccesAuthorVO vo) throws Exception {
        return (Long)insert("progrmAccesAuthorDAO.create", vo);
    }
    
    /**
	 * 글 목록을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ProgrmAccesAuthorVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteList(ProgrmAccesAuthorVO vo) throws Exception {
        return delete("progrmAccesAuthorDAO.deleteList", vo);
    }
    
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ProgrmAccesAuthorVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<ProgrmAccesAuthorVO> retrieveList(ProgrmAccesAuthorVO vo) throws Exception {
        return (List<ProgrmAccesAuthorVO>)list("progrmAccesAuthorDAO.retrieveList", vo);
    }
}
