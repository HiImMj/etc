package kr.go.mosf.pms.progrm.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.progrm.service.ProgrmService;
import kr.go.mosf.pms.progrm.vo.ProgrmFormVO;
import kr.go.mosf.pms.progrm.vo.ProgrmVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class ProgrmController extends BaseController{
	@Resource(name = "progrmService")
	private ProgrmService progrmService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 ProgrmVO
	 * @param model
	 * @return "/progrm/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/progrm/retrieveList.do")
    public String retrieveList(ProgrmFormVO progrmFormVO, 
    		ModelMap model)
            throws Exception {
    	
    	progrmFormVO.getSearchProgrmVO().setDeleteYn("N");
        List<ProgrmVO> resultList = progrmService.retrieveList(progrmFormVO.getSearchProgrmVO());
        model.addAttribute("resultList", resultList);
        
        return "/progrm/treeList";
    }
  	
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/progrm/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/progrm/createView.do")
    public String createView(ProgrmFormVO progrmFormVO, Model model)
            throws Exception {
    	progrmFormVO.setProgrmVO(new ProgrmVO());
        return "/progrm/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param progrmVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/progrm/retrieveList.do"
	 * @exception Exception
	 */
    @RequestMapping("/progrm/create.do")
    public String create(
         	  HttpServletRequest request,
         	 ProgrmFormVO progrmFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(progrmFormVO.getProgrmVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("progrmVO", progrmFormVO.getProgrmVO());
			return "/progrm/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	progrmFormVO.getProgrmVO().setCreatId(loginUserVO.getUserId());
    	
        progrmService.create(progrmFormVO.getProgrmVO());
        
        status.setComplete();
        return "forward:/progrm/retrieveList.do";
    }
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/progrm/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/progrm/updateView.do")
    public String updateView(
    		ProgrmFormVO progrmFormVO,Model model)
            throws Exception {
    	progrmFormVO.setProgrmVO((progrmService.retrieve(progrmFormVO.getProgrmVO())));
        return "/progrm/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param progrmVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/progrm/retrieveList.do"
	 * @exception Exception
	 */
    @RequestMapping("/progrm/update.do")
    public String update(
            HttpServletRequest request,
            ProgrmFormVO progrmFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("progrmVO: "+progrmFormVO.getProgrmVO());
    	
    	beanValidator.validate(progrmFormVO.getProgrmVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("progrmVO", progrmFormVO.getProgrmVO());
			return "/progrm/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	progrmFormVO.getProgrmVO().setUpdtId(loginUserVO.getUserId());
        progrmService.update(progrmFormVO.getProgrmVO());
        status.setComplete();
        return "forward:/progrm/retrieveList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param progrmVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/progrm/retrieveList.do"
	 * @exception Exception
	 */
    @RequestMapping("/progrm/delete.do")
    public String delete(
            HttpServletRequest request,
            ProgrmFormVO progrmFormVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	progrmFormVO.getProgrmVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("progrmVO: "+progrmFormVO.getProgrmVO());
        progrmService.delete(progrmFormVO.getProgrmVO());
        status.setComplete();
        return "forward:/progrm/retrieveList.do";
    }
}

