package kr.go.mosf.pms.progrm.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class ProgrmFormVO extends BaseVO{
	private ProgrmVO searchProgrmVO;
	private ProgrmVO progrmVO;
	
	public ProgrmFormVO(){
		searchProgrmVO = new ProgrmVO();
		progrmVO = new ProgrmVO();
	}

	public ProgrmVO getSearchProgrmVO() {
		return searchProgrmVO;
	}

	public void setSearchProgrmVO(ProgrmVO searchProgrmVO) {
		this.searchProgrmVO = searchProgrmVO;
	}

	public ProgrmVO getProgrmVO() {
		return progrmVO;
	}

	public void setProgrmVO(ProgrmVO progrmVO) {
		this.progrmVO = progrmVO;
	}
	
	
}
