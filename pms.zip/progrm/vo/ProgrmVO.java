package kr.go.mosf.pms.progrm.vo;

import java.util.ArrayList;
import java.util.List;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.progrmaccesauthor.vo.ProgrmAccesAuthorVO;
import kr.go.mosf.pms.recsroom.vo.RecsroomAtchmnflVO;

public class ProgrmVO extends BaseVO{
	private int progrmSn;		/* 프로그램_순번 */
	private String progrmNm;	/* 프로그램_명 */
	private String progrmUri;	/* 프로그램_URI */
	
	private int upperProgrmSn;
	private int sortNo;
	
	private List<ProgrmAccesAuthorVO> progrmAccesAuthorVOList = new ArrayList<ProgrmAccesAuthorVO>();

	public int getProgrmSn() {
		return progrmSn;
	}

	public void setProgrmSn(int progrmSn) {
		this.progrmSn = progrmSn;
	}

	public String getProgrmNm() {
		return progrmNm;
	}

	public void setProgrmNm(String progrmNm) {
		this.progrmNm = progrmNm;
	}

	public String getProgrmUri() {
		return progrmUri;
	}

	public void setProgrmUri(String progrmUri) {
		this.progrmUri = progrmUri;
	}

	public List<ProgrmAccesAuthorVO> getProgrmAccesAuthorVOList() {
		return progrmAccesAuthorVOList;
	}

	public void setProgrmAccesAuthorVOList(List<ProgrmAccesAuthorVO> progrmAccesAuthorVOList) {
		this.progrmAccesAuthorVOList = progrmAccesAuthorVOList;
	}

	public int getUpperProgrmSn() {
		return upperProgrmSn;
	}

	public void setUpperProgrmSn(int upperProgrmSn) {
		this.upperProgrmSn = upperProgrmSn;
	}

	public int getSortNo() {
		return sortNo;
	}

	public void setSortNo(int sortNo) {
		this.sortNo = sortNo;
	}
	
	
}
