package kr.go.mosf.pms.progrm.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.progrm.dao.ProgrmDAO;
import kr.go.mosf.pms.progrm.vo.ProgrmVO;
import kr.go.mosf.pms.progrmaccesauthor.dao.ProgrmAccesAuthorDAO;
import kr.go.mosf.pms.progrmaccesauthor.vo.ProgrmAccesAuthorVO;

import org.springframework.stereotype.Service;

@Service("progrmService")
public class ProgrmService extends BaseService{
	@Resource(name="progrmDAO")
	private ProgrmDAO progrmDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ProgrmVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Long create(ProgrmVO vo) throws Exception {
    	Long progrmSn = progrmDAO.create(vo);
        return progrmSn;
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ProgrmVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(ProgrmVO vo) throws Exception {
        return progrmDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ProgrmVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(ProgrmVO vo) throws Exception {
        return progrmDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ProgrmVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public ProgrmVO retrieve(ProgrmVO vo) throws Exception {
        return progrmDAO.retrieve(vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ProgrmVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<ProgrmVO> retrieveList(ProgrmVO vo) throws Exception {
        return progrmDAO.retrieveList(vo);
    }
}
