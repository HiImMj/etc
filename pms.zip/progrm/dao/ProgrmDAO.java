package kr.go.mosf.pms.progrm.dao;

import java.util.List;
import kr.go.mosf.pms.progrm.vo.ProgrmVO;
import org.springframework.stereotype.Repository;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("progrmDAO")
public class ProgrmDAO extends EgovAbstractDAO{
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ProgrmVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Long create(ProgrmVO vo) throws Exception {
        return (Long)insert("progrmDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ProgrmVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(ProgrmVO vo) throws Exception {
        return update("progrmDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ProgrmVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(ProgrmVO vo) throws Exception {
        return delete("progrmDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ProgrmVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public ProgrmVO retrieve(ProgrmVO vo) throws Exception {
        return (ProgrmVO) selectByPk("progrmDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ProgrmVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<ProgrmVO> retrieveList(ProgrmVO vo) throws Exception {
        return (List<ProgrmVO>)list("progrmDAO.retrieveList", vo);
    }	
}
