package kr.go.mosf.pms.inpthnf.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.inpthnf.service.InptHnfService;
import kr.go.mosf.pms.inpthnf.vo.InptHnfFormVO;
import kr.go.mosf.pms.inpthnf.vo.InptHnfVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class InptHnfController extends BaseController{
	@Resource(name = "inptHnfService")
	private InptHnfService inptHnfService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/inpthnf/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/inpthnf/retrieveList.do")
    public String retrieveList(InptHnfFormVO bsnsInfoFormVO, 
    		ModelMap model)
            throws Exception {
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsInfoFormVO.getSearchInptHnfVO().getBsnsSn());
        bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoVO);
        
        //투입인력정보
        List<InptHnfVO> list = inptHnfService.retrieveList(bsnsInfoFormVO.getSearchInptHnfVO());
        model.addAttribute("resultList", list);
        
        bsnsInfoFormVO.setInptHnfVO(null);
        
        retrieveCmmnCode(model);
        return "/inpthnf/edit";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.PARTCPTN_STTUS_CODE);
        model.addAttribute("partcptnSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpthnf/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/createView.do")
    public String createView(
    		InptHnfFormVO bsnsInfoFormVO, ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsInfoFormVO.getSearchInptHnfVO().getBsnsSn());
        bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptHnfVO> list = inptHnfService.retrieveList(bsnsInfoFormVO.getSearchInptHnfVO());
        model.addAttribute("resultList", list);
        
        InptHnfVO inptHnfVO = new InptHnfVO();
        inptHnfVO.setBsnsSn(bsnsInfoFormVO.getSearchInptHnfVO().getBsnsSn());
        bsnsInfoFormVO.setInptHnfVO(inptHnfVO);
        
        retrieveCmmnCode(model);
        return "/inpthnf/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnf/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 InptHnfFormVO inptHnfFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(inptHnfFormVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpthnf/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	inptHnfFormVO.getInptHnfVO().setCreatId(loginUserVO.getUserId());
    	
    	inptHnfService.create(inptHnfFormVO.getInptHnfVO());
    	
        status.setComplete();
        return "forward:/inpthnf/createView.do";
    }
   
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpthnf/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/updateView.do")
    public String updateView(
    		InptHnfFormVO bsnsInfoFormVO ,ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsInfoFormVO.getSearchInptHnfVO().getBsnsSn());
        bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptHnfVO> list = inptHnfService.retrieveList(bsnsInfoFormVO.getSearchInptHnfVO());
        model.addAttribute("resultList", list);
        retrieveCmmnCode(model);
        
        bsnsInfoFormVO.setInptHnfVO(inptHnfService.retrieve(bsnsInfoFormVO.getInptHnfVO()));
        
        return "/inpthnf/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnf/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/update.do")
    public String update(
    		HttpServletRequest request,
    		InptHnfFormVO inptHnfFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("inptHnfVO: "+inptHnfFormVO.getInptHnfVO());
    	
    	beanValidator.validate(inptHnfFormVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpthnf/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptHnfFormVO.getInptHnfVO().setUpdtId(loginUserVO.getUserId());
    	inptHnfService.update(inptHnfFormVO.getInptHnfVO());
        status.setComplete();
        return "forward:/inpthnf/createView.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnf/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/delete.do")
    public String delete(
    		InptHnfFormVO inptHnfFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptHnfFormVO.getInptHnfVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("inptHnfVO: "+inptHnfFormVO.getInptHnfVO());
    	inptHnfService.delete(inptHnfFormVO.getInptHnfVO());
        status.setComplete();
        return "forward:/inpthnf/createView.do";
    }

}
