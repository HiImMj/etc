package kr.go.mosf.pms.inpthnf.web;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.inpthnf.service.InptHnfService;
import kr.go.mosf.pms.inpthnf.vo.InptHnfFormVO;
import kr.go.mosf.pms.inpthnf.vo.InptHnfVO;
import kr.go.mosf.pms.recsroom.vo.RecsroomAtchmnflVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ScrtyCnfrmnController extends BaseController{
	@Resource(name = "inptHnfService")
	private InptHnfService inptHnfService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/inpthnf/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/inpthnf/retrieveScrtyCnfrmnList.do")
    public String retrieveList(InptHnfFormVO bsnsInfoFormVO, 
    		ModelMap model)
            throws Exception {
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsInfoFormVO.getSearchInptHnfVO().getBsnsSn());
        bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptHnfVO> list = inptHnfService.retrieveList(bsnsInfoFormVO.getSearchInptHnfVO());
        model.addAttribute("resultList", list);
        
        bsnsInfoFormVO.setInptHnfVO(null);
        
        return "/inpthnf/editScrtyCnfrmn";
    }
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpthnf/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/updateScrtyCnfrmnView.do")
    public String updateView(
    		InptHnfFormVO bsnsInfoFormVO ,ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsInfoFormVO.getSearchInptHnfVO().getBsnsSn());
        bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptHnfVO> list = inptHnfService.retrieveList(bsnsInfoFormVO.getSearchInptHnfVO());
        model.addAttribute("resultList", list);        
        
        bsnsInfoFormVO.setInptHnfVO(inptHnfService.retrieve(bsnsInfoFormVO.getInptHnfVO()));
        
        return "/inpthnf/editScrtyCnfrmn";
    }
    
    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnf/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/updateScrtyCnfrmn.do")
    public String update(
    		HttpServletRequest request,
    		InptHnfFormVO inptHnfFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("inptHnfVO: "+inptHnfFormVO.getInptHnfVO());
    	
    	beanValidator.validate(inptHnfFormVO.getInptHnfVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpthnf/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptHnfFormVO.getInptHnfVO().setUpdtId(loginUserVO.getUserId());
    	
    	//보안서약서 파일처리
    	MultipartFile inFile = inptHnfFormVO.getInptHnfVO().getFile();
    	if(inFile != null && !GenericValidator.isBlankOrNull(inFile.getOriginalFilename())){
    		inptHnfFormVO.getInptHnfVO().setScrtyCnfrmnOrginlFileNm(inFile.getOriginalFilename());
    		inptHnfFormVO.getInptHnfVO().setScrtyCnfrmnStreAllCours(RecsroomAtchmnflVO.FILE_PATH);
    	}
    	
    	
    	inptHnfService.updateScrtyCnfrmn(inptHnfFormVO.getInptHnfVO());
        status.setComplete();
        return "forward:/inpthnf/retrieveScrtyCnfrmnList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnf/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnf/deleteScrtyCnfrmn.do")
    public String delete(
    		HttpServletRequest request,
    		InptHnfFormVO inptHnfFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("inptHnfVO: "+inptHnfFormVO.getInptHnfVO());
    	
    	beanValidator.validate(inptHnfFormVO.getInptHnfVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpthnf/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptHnfFormVO.getInptHnfVO().setUpdtId(loginUserVO.getUserId());
    	
    	inptHnfService.deleteScrtyCnfrmn(inptHnfFormVO.getInptHnfVO());
        status.setComplete();
        return "forward:/inpthnf/retrieveScrtyCnfrmnList.do";
    }
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/inpthnf/scrtyCnfrmnFileDown.do")    
    public void fileDown(InptHnfVO inptHnfVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	InptHnfVO exsitInptHnfVO = inptHnfService.retrieve(inptHnfVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(exsitInptHnfVO != null){
    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitInptHnfVO.getScrtyCnfrmnStreAllCours());
    		int sourceFileSize = (int)sourceFile.length();
    		
    		File downFile = new File(MOSFPMSDefine.filePath + exsitInptHnfVO.getScrtyCnfrmnStreAllCours()+"decrypt");
    		if(sourceFileSize>0){
    			cryptoService.decrypt(sourceFile, MOSFPMSDefine.ENCRYPT_PASSWORD, downFile);
    		}
    		
    		String sourceFileName = exsitInptHnfVO.getScrtyCnfrmnOrginlFileNm();
    		
    		try{
    			downloadFile(request, response, downFile, sourceFileName);
    		}catch(Exception e){
    			logger.error(e.getMessage());
    			throw e;
    		}finally{
    			try{
        			FileUtils.forceDelete(downFile);
        		}catch(Exception e){
        			e.printStackTrace();
        		}
    		}
		}
	}
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/inpthnf/deleteScrtyCnfrmnfileAjax.do")    
    public String deleteScrtyCnfrmnfileAjax(InptHnfVO inptHnfVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	//파일에 대한 접근 권한 처리가 필요함.
		try{
    		inptHnfService.deleteScrtyCnfrmn(inptHnfVO);
    		model.addAttribute("returnMessage", "success");
		}catch(Exception e){
			model.addAttribute("returnMessage", "fail");
		}
    	
    	return "jsonView";
	}
}
