package kr.go.mosf.pms.inpthnf.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;

public class InptHnfVO extends BaseVO{
	public static final String SCRTY_CNFRMN_FILE_PATH = "inptHnf/scrtycnfrmn/";
	
	private int inptHnfSn;				/* 투입_인력_순번 */
    private int bsnsSn;					/* 사업_순번 */
    private String inpthnfNm;			/* 투입_인력_명 */
    private String cmgCardId;			/* 출입카드_ID */
    private String psitn;				/* 소속 */
    private String clsf;				/* 직급 */
    private String moblphon;			/* 휴대전화 */
    private String email;				/* 이메일 */
    private String partcptnSttusCode;	/* 참여_상태_코드 */
    private String partcptnSttusCodeNm;	/* 참여_상태_코드 */
    private Date partcptnBgnde;			/* 참여_시작일 */
    private Date partcptnEndde;			/* 참여_종료일 */
    
    private String partcptnBgndeDisplay;			/* 참여_시작일 */
    private String partcptnEnddeDisplay;			/* 참여_종료일 */
    
    private float partcptnRt;			/* 참여_율 */
    private int sortOrdr;				/* 정렬_순서 */
    
    //보안 서약서에 따른 추가
    private Date scrtyCnfrmnPresentnDe;
    private String scrtyCnfrmnPresentnDeDisplay;
    private String scrtyCnfrmnOrginlFileNm;
    private String scrtyCnfrmnStreAllCours;
    
    private MultipartFile file;
    
    public String getScrtyCnfrmnPresentnDeDisplay() {
    	if(scrtyCnfrmnPresentnDe != null){
    		scrtyCnfrmnPresentnDeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(scrtyCnfrmnPresentnDe);
		}
		return scrtyCnfrmnPresentnDeDisplay;
	}

	public void setScrtyCnfrmnPresentnDeDisplay(String scrtyCnfrmnPresentnDeDisplay) {
		this.scrtyCnfrmnPresentnDeDisplay = scrtyCnfrmnPresentnDeDisplay;
		try {
			scrtyCnfrmnPresentnDe = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(scrtyCnfrmnPresentnDeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getPartcptnBgndeDisplay() {
		if(partcptnBgnde != null){
			partcptnBgndeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(partcptnBgnde);
		}
		return partcptnBgndeDisplay;
	}

	public void setPartcptnBgndeDisplay(String partcptnBgndeDisplay) {
		this.partcptnBgndeDisplay = partcptnBgndeDisplay;
		try {
			partcptnBgnde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(partcptnBgndeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getPartcptnEnddeDisplay() {
		if(partcptnEndde != null){
			partcptnEnddeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(partcptnEndde);
		}
		return partcptnEnddeDisplay;
	}

	public void setPartcptnEnddeDisplay(String partcptnEnddeDisplay) {
		this.partcptnEnddeDisplay = partcptnEnddeDisplay;
		try {
			partcptnEndde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(partcptnEnddeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    public int getInptHnfSn() {
		return inptHnfSn;
	}
	public void setInptHnfSn(int inptHnfSn) {
		this.inptHnfSn = inptHnfSn;
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getCmgCardId() {
		return cmgCardId;
	}
	public void setCmgCardId(String cmgCardId) {
		this.cmgCardId = cmgCardId;
	}
	public String getPsitn() {
		return psitn;
	}
	public void setPsitn(String psitn) {
		this.psitn = psitn;
	}
	public String getClsf() {
		return clsf;
	}
	public void setClsf(String clsf) {
		this.clsf = clsf;
	}
	public String getMoblphon() {
		return moblphon;
	}
	public void setMoblphon(String moblphon) {
		this.moblphon = moblphon;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPartcptnSttusCode() {
		return partcptnSttusCode;
	}
	public void setPartcptnSttusCode(String partcptnSttusCode) {
		this.partcptnSttusCode = partcptnSttusCode;
	}
	public Date getPartcptnBgnde() {
		return partcptnBgnde;
	}
	public void setPartcptnBgnde(Date partcptnBgnde) {
		this.partcptnBgnde = partcptnBgnde;
	}
	public Date getPartcptnEndde() {
		return partcptnEndde;
	}
	public void setPartcptnEndde(Date partcptnEndde) {
		this.partcptnEndde = partcptnEndde;
	}
	public float getPartcptnRt() {
		return partcptnRt;
	}
	public void setPartcptnRt(float partcptnRt) {
		this.partcptnRt = partcptnRt;
	}
	public int getSortOrdr() {
		return sortOrdr;
	}
	public void setSortOrdr(int sortOrdr) {
		this.sortOrdr = sortOrdr;
	}
	public String getInpthnfNm() {
		return inpthnfNm;
	}
	public void setInpthnfNm(String inpthnfNm) {
		this.inpthnfNm = inpthnfNm;
	}
	public String getPartcptnSttusCodeNm() {
		return partcptnSttusCodeNm;
	}
	public void setPartcptnSttusCodeNm(String partcptnSttusCodeNm) {
		this.partcptnSttusCodeNm = partcptnSttusCodeNm;
	}

	public Date getScrtyCnfrmnPresentnDe() {
		return scrtyCnfrmnPresentnDe;
	}

	public void setScrtyCnfrmnPresentnDe(Date scrtyCnfrmnPresentnDe) {
		this.scrtyCnfrmnPresentnDe = scrtyCnfrmnPresentnDe;
	}

	public String getScrtyCnfrmnOrginlFileNm() {
		return scrtyCnfrmnOrginlFileNm;
	}

	public void setScrtyCnfrmnOrginlFileNm(String scrtyCnfrmnOrginlFileNm) {
		this.scrtyCnfrmnOrginlFileNm = scrtyCnfrmnOrginlFileNm;
	}

	public String getScrtyCnfrmnStreAllCours() {
		return scrtyCnfrmnStreAllCours;
	}

	public void setScrtyCnfrmnStreAllCours(String scrtyCnfrmnStreAllCours) {
		this.scrtyCnfrmnStreAllCours = scrtyCnfrmnStreAllCours;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
    
}
