package kr.go.mosf.pms.inpthnf.vo;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;

public class InptHnfFormVO extends BaseVO{
	private InptHnfVO searchInptHnfVO;
	private InptHnfVO inptHnfVO;
	private BsnsInfoVO bsnsInfoVO;
	
	public InptHnfFormVO(){
		searchInptHnfVO = new InptHnfVO();
		inptHnfVO = new InptHnfVO();
		bsnsInfoVO = new BsnsInfoVO();
	}

	public InptHnfVO getSearchInptHnfVO() {
		return searchInptHnfVO;
	}

	public void setSearchInptHnfVO(InptHnfVO searchInptHnfVO) {
		this.searchInptHnfVO = searchInptHnfVO;
	}

	public InptHnfVO getInptHnfVO() {
		return inptHnfVO;
	}

	public void setInptHnfVO(InptHnfVO inptHnfVO) {
		this.inptHnfVO = inptHnfVO;
	}

	public BsnsInfoVO getBsnsInfoVO() {
		return bsnsInfoVO;
	}

	public void setBsnsInfoVO(BsnsInfoVO bsnsInfoVO) {
		this.bsnsInfoVO = bsnsInfoVO;
	}
	
	
}
