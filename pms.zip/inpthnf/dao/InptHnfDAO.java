package kr.go.mosf.pms.inpthnf.dao;

import java.util.List;
import kr.go.mosf.pms.inpthnf.vo.InptHnfVO;
import org.springframework.stereotype.Repository;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("inptHnfDAO")
public class InptHnfDAO extends EgovAbstractDAO{
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 InptHnfVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Integer create(InptHnfVO vo) throws Exception {
        return (Integer)insert("inptHnfDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptHnfVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(InptHnfVO vo) throws Exception {
        return update("inptHnfDAO.update", vo);
    }
    
    /**
	 * 보안서약서 정보를 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptHnfVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateScrtyCnfrmn(InptHnfVO vo) throws Exception {
        return update("inptHnfDAO.updateScrtyCnfrmn", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptHnfVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(InptHnfVO vo) throws Exception {
        return delete("inptHnfDAO.delete", vo);
    }
    
    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptHnfVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteScrtyCnfrmn(InptHnfVO vo) throws Exception {
        return delete("inptHnfDAO.deleteScrtyCnfrmn", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public InptHnfVO retrieve(InptHnfVO vo) throws Exception {
        return (InptHnfVO) selectByPk("inptHnfDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<InptHnfVO> retrieveList(InptHnfVO vo) throws Exception {
        return (List<InptHnfVO>)list("inptHnfDAO.retrieveList", vo);
    }
}
