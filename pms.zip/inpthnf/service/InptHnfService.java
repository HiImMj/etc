package kr.go.mosf.pms.inpthnf.service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.inpthnf.dao.InptHnfDAO;
import kr.go.mosf.pms.inpthnf.vo.InptHnfVO;
import kr.go.mosf.pms.recsroom.vo.RecsroomAtchmnflVO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service("inptHnfService")
public class InptHnfService extends BaseService{
	@Resource(name="inptHnfDAO")
	private InptHnfDAO inptHnfDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 InptHnfVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(InptHnfVO vo) throws Exception {
    	return inptHnfDAO.create(vo);  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptHnfVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(InptHnfVO vo) throws Exception {    	
        return inptHnfDAO.update(vo);
    }
    
    /**
	 * 보안서약서 정보를 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptHnfVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateScrtyCnfrmn(InptHnfVO vo) throws Exception {    
    	int cnt = 0;
    	vo.setScrtyCnfrmnStreAllCours(InptHnfVO.SCRTY_CNFRMN_FILE_PATH+vo.getInptHnfSn()+"/"+System.currentTimeMillis());
    	
    	cnt = inptHnfDAO.updateScrtyCnfrmn(vo);
    	
    	//첨부파일 처리
		MultipartFile inFile = vo.getFile();
		if(inFile != null && !GenericValidator.isBlankOrNull(inFile.getOriginalFilename())){
			//기존 파일이 있었는지 확인하여 있으면 삭제
			InptHnfVO existInptHnfVO=inptHnfDAO.retrieve(vo);
			if(existInptHnfVO != null && 
					!GenericValidator.isBlankOrNull(existInptHnfVO.getScrtyCnfrmnStreAllCours())){
				File existFile = new File(MOSFPMSDefine.filePath + vo.getScrtyCnfrmnStreAllCours());
				try{
					FileUtils.forceDelete(existFile);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
			File filePath = new File(FilenameUtils.getFullPath(MOSFPMSDefine.filePath + vo.getScrtyCnfrmnStreAllCours()));
			if(!filePath.exists()){
				filePath.mkdirs();
			}
			
			File tempFile = new File(MOSFPMSDefine.filePath + vo.getScrtyCnfrmnStreAllCours()+"temp");
			File encFile = new File(MOSFPMSDefine.filePath + vo.getScrtyCnfrmnStreAllCours());
			IOUtils.write(inFile.getBytes(), new FileOutputStream(tempFile));
			
			//암호화 처리
			cryptoService.encrypt(tempFile, MOSFPMSDefine.ENCRYPT_PASSWORD, encFile);			
			try{
				FileUtils.forceDelete(tempFile);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
        return cnt;
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptHnfVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(InptHnfVO vo) throws Exception {
    	InptHnfVO exsitInptHnfVO = inptHnfDAO.retrieve(vo);
    	
    	if(exsitInptHnfVO != null){
    		try{
	    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitInptHnfVO.getScrtyCnfrmnStreAllCours());
	    		FileUtils.forceDelete(sourceFile);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
		}
    	inptHnfDAO.deleteScrtyCnfrmn(vo);
    	
    	return inptHnfDAO.delete(vo);
    }
    
    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptHnfVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteScrtyCnfrmn(InptHnfVO vo) throws Exception {
    	InptHnfVO exsitInptHnfVO = inptHnfDAO.retrieve(vo);
    	
    	if(exsitInptHnfVO != null){
    		try{
	    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitInptHnfVO.getScrtyCnfrmnStreAllCours());
	    		FileUtils.forceDelete(sourceFile);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
		}
    	
    	return inptHnfDAO.deleteScrtyCnfrmn(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public InptHnfVO retrieve(InptHnfVO vo) throws Exception {
    	return inptHnfDAO.retrieve(vo);
    }    
   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<InptHnfVO> retrieveList(InptHnfVO vo) throws Exception {
        return inptHnfDAO.retrieveList(vo);
    }
}
