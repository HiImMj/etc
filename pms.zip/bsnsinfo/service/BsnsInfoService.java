package kr.go.mosf.pms.bsnsinfo.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.bsnsinfo.dao.BsnsInfoDAO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;

import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cryptography.EgovPasswordEncoder;

@Service("bsnsInfoService")
public class BsnsInfoService extends BaseService{
	@Resource(name="bsnsInfoDAO")
	private BsnsInfoDAO bsnsInfoDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BsnsInfoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(BsnsInfoVO vo) throws Exception {
    	return bsnsInfoDAO.create(vo);  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BsnsInfoVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(BsnsInfoVO vo) throws Exception {    	
        return bsnsInfoDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BsnsInfoVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(BsnsInfoVO vo) throws Exception {
    	return bsnsInfoDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsInfoVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public BsnsInfoVO retrieve(BsnsInfoVO vo) throws Exception {
    	return bsnsInfoDAO.retrieve(vo);
    }    
   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsInfoVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<BsnsInfoVO> retrievePagingList(BsnsInfoVO vo) throws Exception {
        return bsnsInfoDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsInfoVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(BsnsInfoVO vo) {
        return bsnsInfoDAO.retrievePagingListCnt(vo);
    }
}
