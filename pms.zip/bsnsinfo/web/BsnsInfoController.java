package kr.go.mosf.pms.bsnsinfo.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoFormVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class BsnsInfoController extends BaseController{
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/bsnsinfo/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/bsnsinfo/retrievePagingList.do")
    public String retrievePagingList(BsnsInfoFormVO bsnsInfoFormVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	bsnsInfoFormVO.getSearchBsnsInfoVO().setPageUnit(propertiesService.getInt("pageUnit"));
    	bsnsInfoFormVO.getSearchBsnsInfoVO().setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(bsnsInfoFormVO.getSearchBsnsInfoVO().getPageIndex());
		paginationInfo.setRecordCountPerPage(bsnsInfoFormVO.getSearchBsnsInfoVO().getPageUnit());
		paginationInfo.setPageSize(bsnsInfoFormVO.getSearchBsnsInfoVO().getPageSize());
		
		bsnsInfoFormVO.getSearchBsnsInfoVO().setFirstIndex(paginationInfo.getFirstRecordIndex());
		bsnsInfoFormVO.getSearchBsnsInfoVO().setLastIndex(paginationInfo.getLastRecordIndex());
		bsnsInfoFormVO.getSearchBsnsInfoVO().setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		bsnsInfoFormVO.getSearchBsnsInfoVO().setDeleteYn("N");
		
		List<BsnsInfoVO> list = bsnsInfoService.retrievePagingList(bsnsInfoFormVO.getSearchBsnsInfoVO());
        model.addAttribute("resultList", list);
        
        retrieveCmmnCode(model);
        
        int totCnt = bsnsInfoService.retrievePagingListCnt(bsnsInfoFormVO.getSearchBsnsInfoVO());
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/bsnsinfo/list";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.BSNS_PROGR_SSTTUS_CODE);
        model.addAttribute("bsnsProgrsSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsinfo/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsinfo/createView.do")
    public String createView(
    		BsnsInfoFormVO bsnsInfoFormVO, ModelMap model)
            throws Exception {
    	//권한에 따른 처리 필요.
    	BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
    	bsnsInfoVO.setBsnsProgrsSttusCode(BsnsInfoVO.BSNS_PROGRS_STTUS_CODE_PLAN);
    	
    	bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoVO); 
    	retrieveCmmnCode(model);
        return "/bsnsinfo/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsinfo/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsinfo/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 BsnsInfoFormVO bsnsInfoFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(bsnsInfoFormVO.getBsnsInfoVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoFormVO.getBsnsInfoVO());
			return "/bsnsinfo/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	bsnsInfoFormVO.getBsnsInfoVO().setCreatId(loginUserVO.getUserId());
    	
    	bsnsInfoService.create(bsnsInfoFormVO.getBsnsInfoVO());
    	
        status.setComplete();
        return "forward:/bsnsinfo/retrievePagingList.do";
    }
    
    /**
	 * 글 조회화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsinfo/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsinfo/retrieveView.do")
    public String retrieveView(
    		BsnsInfoFormVO bsnsInfoFormVO ,ModelMap model)
            throws Exception {
    	bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoFormVO.getBsnsInfoVO()));
    	retrieveCmmnCode(model);
        return "/bsnsinfo/view";
    }
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsinfo/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsinfo/updateView.do")
    public String updateView(
    		BsnsInfoFormVO bsnsInfoFormVO ,ModelMap model)
            throws Exception {
    	bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoFormVO.getBsnsInfoVO()));
    	retrieveCmmnCode(model);
        return "/bsnsinfo/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsinfo/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsinfo/update.do")
    public String update(
    		HttpServletRequest request,
    		BsnsInfoFormVO bsnsInfoFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("bsnsInfoVO: "+bsnsInfoFormVO.getBsnsInfoVO());
    	
    	beanValidator.validate(bsnsInfoFormVO.getBsnsInfoVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		bsnsInfoFormVO.setBsnsInfoVO(bsnsInfoFormVO.getBsnsInfoVO());
			return "/bsnsinfo/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	bsnsInfoFormVO.getBsnsInfoVO().setUpdtId(loginUserVO.getUserId());
        bsnsInfoService.update(bsnsInfoFormVO.getBsnsInfoVO());
        status.setComplete();
        return "forward:/bsnsinfo/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param bsnsInfoFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsinfo/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsinfo/delete.do")
    public String delete(
    		BsnsInfoFormVO bsnsInfoFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	bsnsInfoFormVO.getBsnsInfoVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("userVO: "+bsnsInfoFormVO.getBsnsInfoVO());
        bsnsInfoService.delete(bsnsInfoFormVO.getBsnsInfoVO());
        status.setComplete();
        return "forward:/bsnsinfo/retrievePagingList.do";
    }
}
