package kr.go.mosf.pms.bsnsinfo.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class BsnsInfoFormVO extends BaseVO{
	private BsnsInfoVO searchBsnsInfoVO;
	private BsnsInfoVO bsnsInfoVO;
	
	public BsnsInfoFormVO(){
		searchBsnsInfoVO = new BsnsInfoVO();
		bsnsInfoVO = new BsnsInfoVO();
	}

	public BsnsInfoVO getSearchBsnsInfoVO() {
		return searchBsnsInfoVO;
	}

	public void setSearchBsnsInfoVO(BsnsInfoVO searchBsnsInfoVO) {
		this.searchBsnsInfoVO = searchBsnsInfoVO;
	}

	public BsnsInfoVO getBsnsInfoVO() {
		return bsnsInfoVO;
	}

	public void setBsnsInfoVO(BsnsInfoVO bsnsInfoVO) {
		this.bsnsInfoVO = bsnsInfoVO;
	}
	
	
}
