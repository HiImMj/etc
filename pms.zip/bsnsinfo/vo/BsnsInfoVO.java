package kr.go.mosf.pms.bsnsinfo.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;

public class BsnsInfoVO extends BaseVO{
	public static final String BSNS_PROGRS_STTUS_CODE_PLAN = "A001"; //기획
	public static final String BSNS_PROGRS_STTUS_CODE_REQUEST = "A002"; //승인요청
	public static final String BSNS_PROGRS_STTUS_CODE_CONFIRM = "A003"; //승인
	public static final String BSNS_PROGRS_STTUS_CODE_PERFORM = "A004"; //진행중
	public static final String BSNS_PROGRS_STTUS_CODE_END = "A005"; //완료
		
	private int bsnsSn;						/* 사업_순번 */
    private int bsnsYear;					/* 사업_년도 */
    private String bsnsNm;					/* 사업_명 */
    private Date bsnsBgnde;					/* 사업_시작일자 */
    private Date bsnsEndde;					/* 사업_종료일자 */
    
    private String bsnsBgndeDisplay;					/* 사업_시작일자 */
    private String bsnsEnddeDisplay;					/* 사업_종료일자 */
    
    private Date bsnsCntrctde;				/* 사업_계약일자 */
    private String bsnsCntrctdeDisplay;				/* 사업_계약일자 */
    
    private String bsnsProgrsSttusCode;		/* 사업진행_상태코드 */
    private String bsnsProgrsSttusCodeNm;		/* 사업진행_상태코드 */
    
    public String getBsnsCntrctdeDisplay() {
		if(bsnsCntrctde != null){
			bsnsCntrctdeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(bsnsCntrctde);
		}
		return bsnsCntrctdeDisplay;
	}

	public void setBsnsCntrctdeDisplay(String bsnsCntrctdeDisplay) {
		this.bsnsCntrctdeDisplay = bsnsCntrctdeDisplay;
		try {
			bsnsCntrctde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(bsnsCntrctdeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    public String getBsnsBgndeDisplay() {
		if(bsnsBgnde != null){
			bsnsBgndeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(bsnsBgnde);
		}
		return bsnsBgndeDisplay;
	}

	public void setBsnsBgndeDisplay(String bsnsBgndeDisplay) {
		this.bsnsBgndeDisplay = bsnsBgndeDisplay;
		try {
			bsnsBgnde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(bsnsBgndeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	 public String getBsnsEnddeDisplay() {
			if(bsnsBgnde != null){
				bsnsEnddeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(bsnsEndde);
			}
			return bsnsEnddeDisplay;
		}

		public void setBsnsEnddeDisplay(String bsnsEnddeDisplay) {
			this.bsnsEnddeDisplay = bsnsEnddeDisplay;
			try {
				bsnsEndde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(bsnsEnddeDisplay);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    
	
    public String getBSNS_PROGRS_STTUS_CODE_PLAN() {
		return BSNS_PROGRS_STTUS_CODE_PLAN;
	}
	public String getBSNS_PROGRS_STTUS_CODE_REQUEST() {
		return BSNS_PROGRS_STTUS_CODE_REQUEST;
	}
	public String getBSNS_PROGRS_STTUS_CODE_CONFIRM() {
		return BSNS_PROGRS_STTUS_CODE_CONFIRM;
	}
	public String getBSNS_PROGRS_STTUS_CODE_PERFORM() {
		return BSNS_PROGRS_STTUS_CODE_PERFORM;
	}
	public static String getBsnsProgrsSttusCodeEnd() {
		return BSNS_PROGRS_STTUS_CODE_END;
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public int getBsnsYear() {
		return bsnsYear;
	}
	public void setBsnsYear(int bsnsYear) {
		this.bsnsYear = bsnsYear;
	}
	public String getBsnsNm() {
		return bsnsNm;
	}
	public void setBsnsNm(String bsnsNm) {
		this.bsnsNm = bsnsNm;
	}
	public Date getBsnsBgnde() {
		return bsnsBgnde;
	}
	public void setBsnsBgnde(Date bsnsBgnde) {
		this.bsnsBgnde = bsnsBgnde;
	}
	public Date getBsnsEndde() {
		return bsnsEndde;
	}
	public void setBsnsEndde(Date bsnsEndde) {
		this.bsnsEndde = bsnsEndde;
	}
	public Date getBsnsCntrctde() {
		return bsnsCntrctde;
	}
	public void setBsnsCntrctde(Date bsnsCntrctde) {
		this.bsnsCntrctde = bsnsCntrctde;
	}
	public String getBsnsProgrsSttusCode() {
		return bsnsProgrsSttusCode;
	}
	public void setBsnsProgrsSttusCode(String bsnsProgrsSttusCode) {
		this.bsnsProgrsSttusCode = bsnsProgrsSttusCode;
	}

	public String getBsnsProgrsSttusCodeNm() {
		return bsnsProgrsSttusCodeNm;
	}

	public void setBsnsProgrsSttusCodeNm(String bsnsProgrsSttusCodeNm) {
		this.bsnsProgrsSttusCodeNm = bsnsProgrsSttusCodeNm;
	}
	
	
}
