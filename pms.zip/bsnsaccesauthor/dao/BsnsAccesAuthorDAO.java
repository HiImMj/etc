package kr.go.mosf.pms.bsnsaccesauthor.dao;

import java.util.List;

import kr.go.mosf.pms.bsnsaccesauthor.vo.BsnsAccesAuthorVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("bsnsAccesAuthorDAO")
public class BsnsAccesAuthorDAO extends EgovAbstractDAO {
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BsnsAccesAuthorVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String create(BsnsAccesAuthorVO vo) throws Exception {
        return (String)insert("bsnsAccesAuthorDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BsnsAccesAuthorVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(BsnsAccesAuthorVO vo) throws Exception {
        return update("bsnsAccesAuthorDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BsnsAccesAuthorVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(BsnsAccesAuthorVO vo) throws Exception {
        return delete("bsnsAccesAuthorDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsAccesAuthorVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public BsnsAccesAuthorVO retrieve(BsnsAccesAuthorVO vo) throws Exception {
        return (BsnsAccesAuthorVO) selectByPk("bsnsAccesAuthorDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BsnsAccesAuthorVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<BsnsAccesAuthorVO> retrieveList(BsnsAccesAuthorVO vo) throws Exception {
        return (List<BsnsAccesAuthorVO>)list("bsnsAccesAuthorDAO.retrieveList", vo);
    }
}
