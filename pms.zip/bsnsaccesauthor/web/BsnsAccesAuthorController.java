package kr.go.mosf.pms.bsnsaccesauthor.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsaccesauthor.service.BsnsAccesAuthorService;
import kr.go.mosf.pms.bsnsaccesauthor.vo.BsnsAccesAuthorFormVO;
import kr.go.mosf.pms.bsnsaccesauthor.vo.BsnsAccesAuthorVO;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;


@Controller
public class BsnsAccesAuthorController  extends BaseController{
	@Resource(name = "bsnsAccesAuthorService")
	private BsnsAccesAuthorService bsnsAccesAuthorService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param bsnsAccesAuthorFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/bsnsaccesauthor/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/bsnsaccesauthor/retrieveList.do")
    public String retrieveList(BsnsAccesAuthorFormVO bsnsAccesAuthorFormVO, 
    		ModelMap model)
            throws Exception {
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO().getBsnsSn());
        bsnsAccesAuthorFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<BsnsAccesAuthorVO> list = bsnsAccesAuthorService.retrieveList(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO());
        model.addAttribute("resultList", list);
        
        bsnsAccesAuthorFormVO.setBsnsAccesAuthorVO(null);
        
        retrieveCmmnCode(model);
        return "/bsnsaccesauthor/edit";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();        
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.BSNS_ACCES_AUTHOR_STTUS_CODE);
        model.addAttribute("bsnsAccesAuthorSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param bsnsAccesAuthorFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsaccesauthor/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsaccesauthor/createView.do")
    public String createView(
    		BsnsAccesAuthorFormVO bsnsAccesAuthorFormVO, ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO().getBsnsSn());
        bsnsAccesAuthorFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<BsnsAccesAuthorVO> list = bsnsAccesAuthorService.retrieveList(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO());
        model.addAttribute("resultList", list);
        
        BsnsAccesAuthorVO bsnsAccesAuthorVO = new BsnsAccesAuthorVO();
        bsnsAccesAuthorVO.setBsnsSn(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO().getBsnsSn());
        bsnsAccesAuthorFormVO.setBsnsAccesAuthorVO(bsnsAccesAuthorVO);
        
        retrieveCmmnCode(model);
        return "/bsnsaccesauthor/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param bsnsAccesAuthorFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsaccesauthor/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsaccesauthor/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 BsnsAccesAuthorFormVO bsnsAccesAuthorFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/bsnsaccesauthor/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO().setCreatId(loginUserVO.getUserId());
    	
    	bsnsAccesAuthorService.create(bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO());
    	
        status.setComplete();
        return "forward:/bsnsaccesauthor/createView.do";
    }
   
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param bsnsAccesAuthorFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/bsnsaccesauthor/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsaccesauthor/updateView.do")
    public String updateView(
    		BsnsAccesAuthorFormVO bsnsAccesAuthorFormVO ,ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO().getBsnsSn());
        bsnsAccesAuthorFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<BsnsAccesAuthorVO> list = bsnsAccesAuthorService.retrieveList(bsnsAccesAuthorFormVO.getSearchBsnsAccesAuthorVO());
        model.addAttribute("resultList", list);
        retrieveCmmnCode(model);
        
        bsnsAccesAuthorFormVO.setBsnsAccesAuthorVO(bsnsAccesAuthorService.retrieve(bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO()));
        
        return "/bsnsaccesauthor/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param bsnsAccesAuthorFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsaccesauthor/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsaccesauthor/update.do")
    public String update(
    		HttpServletRequest request,
    		BsnsAccesAuthorFormVO bsnsAccesAuthorFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("bsnsAccesAuthorVO: "+bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO());
    	
    	beanValidator.validate(bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/bsnsaccesauthor/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO().setUpdtId(loginUserVO.getUserId());
    	bsnsAccesAuthorService.update(bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO());
        status.setComplete();
        return "forward:/bsnsaccesauthor/createView.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param bsnsAccesAuthorFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/bsnsaccesauthor/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/bsnsaccesauthor/delete.do")
    public String delete(
    		BsnsAccesAuthorFormVO bsnsAccesAuthorFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("bsnsAccesAuthorVO: "+bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO());
    	bsnsAccesAuthorService.delete(bsnsAccesAuthorFormVO.getBsnsAccesAuthorVO());
        status.setComplete();
        return "forward:/bsnsaccesauthor/createView.do";
    }

}