package kr.go.mosf.pms.bsnsaccesauthor.vo;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;

public class BsnsAccesAuthorFormVO extends BaseVO{
	private BsnsAccesAuthorVO searchBsnsAccesAuthorVO;
	private BsnsAccesAuthorVO bsnsAccesAuthorVO;
	private BsnsInfoVO bsnsInfoVO;
	
	public BsnsAccesAuthorFormVO(){
		searchBsnsAccesAuthorVO = new BsnsAccesAuthorVO();
		bsnsAccesAuthorVO = new BsnsAccesAuthorVO();
		bsnsInfoVO = new BsnsInfoVO();
	}

	public BsnsAccesAuthorVO getSearchBsnsAccesAuthorVO() {
		return searchBsnsAccesAuthorVO;
	}

	public void setSearchBsnsAccesAuthorVO(BsnsAccesAuthorVO searchBsnsAccesAuthorVO) {
		this.searchBsnsAccesAuthorVO = searchBsnsAccesAuthorVO;
	}

	public BsnsAccesAuthorVO getBsnsAccesAuthorVO() {
		return bsnsAccesAuthorVO;
	}

	public void setBsnsAccesAuthorVO(BsnsAccesAuthorVO bsnsAccesAuthorVO) {
		this.bsnsAccesAuthorVO = bsnsAccesAuthorVO;
	}

	public BsnsInfoVO getBsnsInfoVO() {
		return bsnsInfoVO;
	}

	public void setBsnsInfoVO(BsnsInfoVO bsnsInfoVO) {
		this.bsnsInfoVO = bsnsInfoVO;
	}
	
	
}
