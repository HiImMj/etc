package kr.go.mosf.pms.bsnsaccesauthor.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class BsnsAccesAuthorVO extends BaseVO{
	public static final String BSNS_ACCES_AUTHOR_STTUS_CODE_CONFIRM="A001";
	public static final String BSNS_ACCES_AUTHOR_STTUS_CODE_STOP="A002";
	
	private int bsnsSn;	
	private String userId;							
	private String userNm;
	private String userTyCode; 
    private String userTyCodeNm;
	private String bsnsAccesAuthorSttusCode;		
	private String bsnsAccesAuthorSttusCodeNm;		
	
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}	
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getUserTyCode() {
		return userTyCode;
	}
	public void setUserTyCode(String userTyCode) {
		this.userTyCode = userTyCode;
	}
	public String getUserTyCodeNm() {
		return userTyCodeNm;
	}
	public void setUserTyCodeNm(String userTyCodeNm) {
		this.userTyCodeNm = userTyCodeNm;
	}
	public String getBsnsAccesAuthorSttusCode() {
		return bsnsAccesAuthorSttusCode;
	}
	public void setBsnsAccesAuthorSttusCode(String bsnsAccesAuthorSttusCode) {
		this.bsnsAccesAuthorSttusCode = bsnsAccesAuthorSttusCode;
	}
	
	public String getBsnsAccesAuthorSttusCodeNm() {
		return bsnsAccesAuthorSttusCodeNm;
	}
	public void setBsnsAccesAuthorSttusCodeNm(String bsnsAccesAuthorSttusCodeNm) {
		this.bsnsAccesAuthorSttusCodeNm = bsnsAccesAuthorSttusCodeNm;
	}	
	
	
}
