package kr.go.mosf.pms.base.service;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.cryptography.EgovCryptoService;
import egovframework.rte.fdl.cryptography.EgovDigestService;

public class BaseService extends AbstractServiceImpl{
	protected Logger logger = Logger.getLogger(this.getClass().getName());
	
	@Resource(name = "digestService")
	protected EgovDigestService digestService; //보안을 위해서 추가된 서비스
	
	@Resource(name = "ARIACryptoService")
	protected EgovCryptoService cryptoService;
	
}
