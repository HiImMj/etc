package kr.go.mosf.pms.base.web;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.view.AbstractView;

public class AjaxResponseXMLView extends AbstractView {

	private static final Logger logger = Logger.getLogger(AjaxResponseXMLView.class);
	
	@Override
	protected void renderMergedOutputModel(Map map,
			HttpServletRequest httpservletrequest,
			HttpServletResponse httpservletresponse) throws Exception {
		// TODO Auto-generated method stub

		ArrayList result = (ArrayList) map.get("result");
		
		String xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n";

		StringBuffer xmlSb = new StringBuffer();
		xmlSb.append(xmlHeader);
		
		xmlSb.append("<DATA>");
		xmlSb.append("<fileCnt>");
		xmlSb.append(map.get("fileCnt"));
		xmlSb.append("</fileCnt>");
		xmlSb.append("<results>");		
		for(int i=0;i<result.size();i++) {
			xmlSb.append("<result>" + result.get(i) + "</result>");
		}		
		xmlSb.append("</results>");
		xmlSb.append("</DATA>");
		
		logger.debug(xmlSb.toString());
		
		httpservletresponse.setContentType("application/xml");
		httpservletresponse.setCharacterEncoding("utf-8");
		httpservletresponse.setHeader("Cache-Control", "no-cache");
		httpservletresponse
				.setContentLength(xmlSb.toString().getBytes("utf-8").length);
		httpservletresponse.getWriter().print(xmlSb.toString());

	}

}