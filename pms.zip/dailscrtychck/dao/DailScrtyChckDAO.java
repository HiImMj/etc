package kr.go.mosf.pms.dailscrtychck.dao;

import java.util.List;

import kr.go.mosf.pms.dailscrtychck.vo.DailScrtyChckVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("dailScrtyChckDAO")
public class DailScrtyChckDAO  extends EgovAbstractDAO {
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 DailScrtyChckVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public void create(DailScrtyChckVO vo) throws Exception {
        insert("dailScrtyChckDAO.create", vo);
    }   

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 DailScrtyChckVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteList(DailScrtyChckVO vo) throws Exception {
        return delete("dailScrtyChckDAO.deleteList", vo);
    }    
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<DailScrtyChckVO> retrieveEditList(DailScrtyChckVO vo) throws Exception {
        return (List<DailScrtyChckVO>)list("dailScrtyChckDAO.retrieveEditList", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<DailScrtyChckVO> retrieveList(DailScrtyChckVO vo) throws Exception {
        return (List<DailScrtyChckVO>)list("dailScrtyChckDAO.retrieveList", vo);
    }
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<DailScrtyChckVO> retrievePagingList(DailScrtyChckVO vo) throws Exception {
        return (List<DailScrtyChckVO>)list("dailScrtyChckDAO.retrievePagingList", vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(DailScrtyChckVO vo) {
        return (Integer)getSqlMapClientTemplate().queryForObject("dailScrtyChckDAO.retrievePagingListCnt", vo);
    }
}