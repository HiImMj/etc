package kr.go.mosf.pms.dailscrtychck.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;

public class DailScrtyChckVO extends BsnsInfoVO{
	private int bsnsSn;						/* 사업_순번 */
    private Date scrtyChckDe;
    private String scrtyChckDeDisplay;
    private String scrtyChckIemCode;
    private String scrtyChckIemCodeNm;
    
    private String[] scrtyChckIemCodes;
    
    private String searchDateString; //2013-11
    
    private String startDateString;
    private String endDateString;    
    
    private int scrtyCheckCnt;
    
    private int weekNo;
    private String week;
    
	public String[] getScrtyChckIemCodes() {
		return scrtyChckIemCodes;
	}
	public void setScrtyChckIemCodes(String[] scrtyChckIemCodes) {
		this.scrtyChckIemCodes = scrtyChckIemCodes;
	}
	public String getSearchDateString() {
		return searchDateString;
	}
	public void setSearchDateString(String searchDateString) {
		this.searchDateString = searchDateString;
	}
	public String getStartDateString() {
		return startDateString;
	}
	public void setStartDateString(String startDateString) {
		this.startDateString = startDateString;
	}
	public String getEndDateString() {
		return endDateString;
	}
	public void setEndDateString(String endDateString) {
		this.endDateString = endDateString;
	}
	public String getScrtyChckDeDisplay() {
		if(scrtyChckDe != null){
			scrtyChckDeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(scrtyChckDe);
		}
		return scrtyChckDeDisplay;
	}
	public void setScrtyChckDeDisplay(String scrtyChckDeDisplay) {
		this.scrtyChckDeDisplay = scrtyChckDeDisplay;
		try {
			scrtyChckDe = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(scrtyChckDeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public Date getScrtyChckDe() {
		return scrtyChckDe;
	}
	public void setScrtyChckDe(Date scrtyChckDe) {
		this.scrtyChckDe = scrtyChckDe;
	}
	public String getScrtyChckIemCode() {
		return scrtyChckIemCode;
	}
	public void setScrtyChckIemCode(String scrtyChckIemCode) {
		this.scrtyChckIemCode = scrtyChckIemCode;
	}
	public String getScrtyChckIemCodeNm() {
		return scrtyChckIemCodeNm;
	}
	public void setScrtyChckIemCodeNm(String scrtyChckIemCodeNm) {
		this.scrtyChckIemCodeNm = scrtyChckIemCodeNm;
	}
	public int getScrtyCheckCnt() {
		return scrtyCheckCnt;
	}
	public void setScrtyCheckCnt(int scrtyCheckCnt) {
		this.scrtyCheckCnt = scrtyCheckCnt;
	}
	public int getWeekNo() {
		return weekNo;
	}
	public void setWeekNo(int weekNo) {
		this.weekNo = weekNo;
	}
	public String getWeek() {
		return week;
	}
	public void setWeek(String week) {
		this.week = week;
	}
    
    
}
