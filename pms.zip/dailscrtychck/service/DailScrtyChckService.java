package kr.go.mosf.pms.dailscrtychck.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.dailscrtychck.dao.DailScrtyChckDAO;
import kr.go.mosf.pms.dailscrtychck.vo.DailScrtyChckVO;

import org.springframework.stereotype.Service;

@Service("dailScrtyChckService")
public class DailScrtyChckService extends BaseService{
	@Resource(name="dailScrtyChckDAO")
	private DailScrtyChckDAO dailScrtyChckDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 DailScrtyChckVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public void createList(DailScrtyChckVO dailScrtyChckVO) throws Exception {
    	if(dailScrtyChckVO.getScrtyChckIemCodes()!=null && dailScrtyChckVO.getScrtyChckIemCodes().length>0){
    		dailScrtyChckDAO.deleteList(dailScrtyChckVO);
    		
    		for(String scrtyChckIemCode:dailScrtyChckVO.getScrtyChckIemCodes()){
    			dailScrtyChckVO.setScrtyChckIemCode(scrtyChckIemCode);
    			dailScrtyChckDAO.create(dailScrtyChckVO);
        	}
    	}
    	
    }
    
    /**
	 * 글 조회 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<DailScrtyChckVO> retrieveEditList(DailScrtyChckVO vo) throws Exception {
        return dailScrtyChckDAO.retrieveEditList(vo);
    }  
       
    /**
	 * 월별 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<DailScrtyChckVO> retrieveList(DailScrtyChckVO vo) throws Exception {
        return dailScrtyChckDAO.retrieveList(vo);
    }
	
	/**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<DailScrtyChckVO> retrievePagingList(DailScrtyChckVO vo) throws Exception {
        return dailScrtyChckDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 DailScrtyChckVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(DailScrtyChckVO vo) {
        return dailScrtyChckDAO.retrievePagingListCnt(vo);
    }

   
}