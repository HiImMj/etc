package kr.go.mosf.pms.dailscrtychck.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoFormVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.dailscrtychck.service.DailScrtyChckService;
import kr.go.mosf.pms.dailscrtychck.vo.DailScrtyChckVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class DailScrtyChckController extends BaseController{
	@Resource(name = "dailScrtyChckService")
	private DailScrtyChckService dailScrtyChckService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/bsnsinfo/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/dailscrtychck/retrievePagingList.do")
    public String retrievePagingList(@ModelAttribute("searchVO") DailScrtyChckVO searchVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		searchVO.setDeleteYn("N");
		
		List<DailScrtyChckVO> list = dailScrtyChckService.retrievePagingList(searchVO);
        model.addAttribute("resultList", list);
        
        int totCnt = dailScrtyChckService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/dailscrtychck/list";
    }
    
	
	/**
	 * 글 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 DailScrtyChckVO
	 * @param model
	 * @return "/dailscrtychck/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/dailscrtychck/retrieveList.do")
    public String retrieveList(@ModelAttribute("searchVO") DailScrtyChckVO searchVO, 
    		@ModelAttribute("bsnsSn") DailScrtyChckVO dailScrtyChckVO,
    		ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(dailScrtyChckVO.getBsnsSn());
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        
        //처음 클릭시 오늘 날짜 표시
		if(GenericValidator.isBlankOrNull(dailScrtyChckVO.getScrtyChckDeDisplay())){
			dailScrtyChckVO.setScrtyChckDe(new Date());
		}
		
		Date date = dailScrtyChckVO.getScrtyChckDe();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		
		int startDay = 1;
		int endDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		String startDateString = new SimpleDateFormat(MOSFPMSDefine.YEAR_MONTH_FORMAT).format(date)+"0"+startDay;
		String endDateString = new SimpleDateFormat(MOSFPMSDefine.YEAR_MONTH_FORMAT).format(date)+endDay;
		
		dailScrtyChckVO.setStartDateString(startDateString);
		dailScrtyChckVO.setEndDateString(endDateString);
    	
        List<DailScrtyChckVO> resultList = dailScrtyChckService.retrieveList(dailScrtyChckVO);
        
        //월 리스트 처리 필요.
        List<DailScrtyChckVO> dayList = new ArrayList<DailScrtyChckVO>();
        
        String[] weeks = {"일", "월", "화", "수", "목", "금", "토"};
        for(int i=startDay;i<endDay+1;i++){
        	String dateStr = "";
			if(i<10){
				dateStr = new SimpleDateFormat(MOSFPMSDefine.YEAR_MONTH_FORMAT).format(date)+"0"+i;
			}else{
				dateStr = new SimpleDateFormat(MOSFPMSDefine.YEAR_MONTH_FORMAT).format(date)+i;
			}
			Date inDate = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(dateStr);
			
			
			Calendar inCalendar = Calendar.getInstance();
			inCalendar.setTime(inDate);
			
			int weekNo = inCalendar.get(Calendar.DAY_OF_WEEK);
			String week = weeks[inCalendar.get(Calendar.DAY_OF_WEEK)-1];
			
			boolean isFind = false;
			for(DailScrtyChckVO listDailScrtyChckVO:resultList){
				if(dateStr.equals(listDailScrtyChckVO.getScrtyChckDeDisplay())){
					listDailScrtyChckVO.setWeekNo(weekNo);
					listDailScrtyChckVO.setWeek(week);
					dayList.add(listDailScrtyChckVO);
					isFind = true;
					break;
				}
			}
			if(!isFind){
				DailScrtyChckVO inDailScrtyChckVO = new DailScrtyChckVO();
				inDailScrtyChckVO.setBsnsSn(bsnsInfoVO.getBsnsSn());
				inDailScrtyChckVO.setScrtyChckDeDisplay(dateStr);
				inDailScrtyChckVO.setWeekNo(weekNo);
				inDailScrtyChckVO.setWeek(week);
				dayList.add(inDailScrtyChckVO);
			}
        }
        
        model.addAttribute("monthList", makeMonthList());        
        model.addAttribute("dayList", dayList);
        
        return "/dailscrtychck/view";
    } 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/dailscrtychck/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/dailscrtychck/createView.do")
    public String createView(
            @ModelAttribute("searchVO") DailScrtyChckVO searchVO, Model model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
    	
        List<DailScrtyChckVO> editList = dailScrtyChckService.retrieveEditList(searchVO);
        model.addAttribute("editList", editList);
        
        return "/dailscrtychck/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param dailScrtyChckVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/dailscrtychck/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/dailscrtychck/create.do")
    public String create(    		
         	  HttpServletRequest request,    		
    		DailScrtyChckVO dailScrtyChckVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(dailScrtyChckVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("dailScrtyChckVO", dailScrtyChckVO);
			return "/dailscrtychck/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	dailScrtyChckVO.setCreatId(loginUserVO.getUserId());    	
    	dailScrtyChckService.createList(dailScrtyChckVO);
    	
        status.setComplete();
        return "forward:/dailscrtychck/createView.do";
    }
}