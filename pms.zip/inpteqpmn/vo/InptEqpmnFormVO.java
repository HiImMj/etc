package kr.go.mosf.pms.inpteqpmn.vo;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;

public class InptEqpmnFormVO extends BaseVO{
	private InptEqpmnVO searchInptEqpmnVO;
	private InptEqpmnVO inptEqpmnVO;
	private BsnsInfoVO bsnsInfoVO;
	
	public InptEqpmnFormVO(){
		searchInptEqpmnVO = new InptEqpmnVO();
		inptEqpmnVO = new InptEqpmnVO();
		bsnsInfoVO = new BsnsInfoVO();
	}

	public InptEqpmnVO getSearchInptEqpmnVO() {
		return searchInptEqpmnVO;
	}

	public void setSearchInptEqpmnVO(InptEqpmnVO searchInptEqpmnVO) {
		this.searchInptEqpmnVO = searchInptEqpmnVO;
	}

	public InptEqpmnVO getInptEqpmnVO() {
		return inptEqpmnVO;
	}

	public void setInptEqpmnVO(InptEqpmnVO inptEqpmnVO) {
		this.inptEqpmnVO = inptEqpmnVO;
	}

	public BsnsInfoVO getBsnsInfoVO() {
		return bsnsInfoVO;
	}

	public void setBsnsInfoVO(BsnsInfoVO bsnsInfoVO) {
		this.bsnsInfoVO = bsnsInfoVO;
	}
	
	
}
