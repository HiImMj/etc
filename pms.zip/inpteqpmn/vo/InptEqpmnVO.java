package kr.go.mosf.pms.inpteqpmn.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;

public class InptEqpmnVO  extends BaseVO{
	private int inptEqpmnSn;
    private int bsnsSn;
    private String inptEqpmnTyCode;
    private String inptEqpmnTyCodeNm;
    private String inptEqpmnNm;
    private String inptEqpmnUsePurps;
    private Date inptEqpmnTkinde;
    private Date inptEqpmnTkoutde;
    private String inptEqpmnProgrsSttusCode;
    private String inptEqpmnProgrsSttusCodeNm;
    
    private String inptEqpmnTkindeDisplay;
    private String inptEqpmnTkoutdeDisplay;    
	
	public String getInptEqpmnTkindeDisplay() {
		if(inptEqpmnTkinde != null){
			inptEqpmnTkindeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(inptEqpmnTkinde);
		}
		return inptEqpmnTkindeDisplay;
	}
	public void setInptEqpmnTkindeDisplay(String inptEqpmnTkindeDisplay) {
		this.inptEqpmnTkindeDisplay = inptEqpmnTkindeDisplay;
		try {
			inptEqpmnTkinde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(inptEqpmnTkindeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getInptEqpmnTkoutdeDisplay() {
		if(inptEqpmnTkoutde != null){
			inptEqpmnTkoutdeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(inptEqpmnTkoutde);
		}
		return inptEqpmnTkoutdeDisplay;
	}
	public void setInptEqpmnTkoutdeDisplay(String inptEqpmnTkoutdeDisplay) {
		this.inptEqpmnTkoutdeDisplay = inptEqpmnTkoutdeDisplay;
		try {
			inptEqpmnTkoutde = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(inptEqpmnTkoutdeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getInptEqpmnTyCodeNm() {
		return inptEqpmnTyCodeNm;
	}
	public void setInptEqpmnTyCodeNm(String inptEqpmnTyCodeNm) {
		this.inptEqpmnTyCodeNm = inptEqpmnTyCodeNm;
	}
	public int getInptEqpmnSn() {
		return inptEqpmnSn;
	}
	public void setInptEqpmnSn(int inptEqpmnSn) {
		this.inptEqpmnSn = inptEqpmnSn;
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getInptEqpmnTyCode() {
		return inptEqpmnTyCode;
	}
	public void setInptEqpmnTyCode(String inptEqpmnTyCode) {
		this.inptEqpmnTyCode = inptEqpmnTyCode;
	}
	public String getInptEqpmnNm() {
		return inptEqpmnNm;
	}
	public void setInptEqpmnNm(String inptEqpmnNm) {
		this.inptEqpmnNm = inptEqpmnNm;
	}
	public String getInptEqpmnUsePurps() {
		return inptEqpmnUsePurps;
	}
	public void setInptEqpmnUsePurps(String inptEqpmnUsePurps) {
		this.inptEqpmnUsePurps = inptEqpmnUsePurps;
	}
	public Date getInptEqpmnTkinde() {
		return inptEqpmnTkinde;
	}
	public void setInptEqpmnTkinde(Date inptEqpmnTkinde) {
		this.inptEqpmnTkinde = inptEqpmnTkinde;
	}
	public Date getInptEqpmnTkoutde() {
		return inptEqpmnTkoutde;
	}
	public void setInptEqpmnTkoutde(Date inptEqpmnTkoutde) {
		this.inptEqpmnTkoutde = inptEqpmnTkoutde;
	}
	public String getInptEqpmnProgrsSttusCode() {
		return inptEqpmnProgrsSttusCode;
	}
	public void setInptEqpmnProgrsSttusCode(String inptEqpmnProgrsSttusCode) {
		this.inptEqpmnProgrsSttusCode = inptEqpmnProgrsSttusCode;
	}
	public String getInptEqpmnProgrsSttusCodeNm() {
		return inptEqpmnProgrsSttusCodeNm;
	}
	public void setInptEqpmnProgrsSttusCodeNm(String inptEqpmnProgrsSttusCodeNm) {
		this.inptEqpmnProgrsSttusCodeNm = inptEqpmnProgrsSttusCodeNm;
	}
    
    
    
}
