package kr.go.mosf.pms.inpteqpmn.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.inpteqpmn.service.InptEqpmnService;
import kr.go.mosf.pms.inpteqpmn.vo.InptEqpmnFormVO;
import kr.go.mosf.pms.inpteqpmn.vo.InptEqpmnVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class InptEqpmnController extends BaseController{
	@Resource(name = "inptEqpmnService")
	private InptEqpmnService inptEqpmnService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param inptEqpmnFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/inpteqpmn/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/inpteqpmn/retrieveList.do")
    public String retrieveList(InptEqpmnFormVO inptEqpmnFormVO, 
    		ModelMap model)
            throws Exception {
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(inptEqpmnFormVO.getSearchInptEqpmnVO().getBsnsSn());
        inptEqpmnFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptEqpmnVO> list = inptEqpmnService.retrieveList(inptEqpmnFormVO.getSearchInptEqpmnVO());
        model.addAttribute("resultList", list);
        
        inptEqpmnFormVO.setInptEqpmnVO(null);
        
        retrieveCmmnCode(model);
        return "/inpteqpmn/edit";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.INPT_EQPMN_TY_CODE);
        model.addAttribute("inptEqpmnTyCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
        
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.INPT_EQPMN_PROGRS_STTUS_CODE);
        model.addAttribute("inptEqpmnProgrsSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param inptEqpmnFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpteqpmn/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpteqpmn/createView.do")
    public String createView(
    		InptEqpmnFormVO inptEqpmnFormVO, ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(inptEqpmnFormVO.getSearchInptEqpmnVO().getBsnsSn());
        inptEqpmnFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptEqpmnVO> list = inptEqpmnService.retrieveList(inptEqpmnFormVO.getSearchInptEqpmnVO());
        model.addAttribute("resultList", list);
        
        InptEqpmnVO inptHnfVO = new InptEqpmnVO();
        inptHnfVO.setBsnsSn(inptEqpmnFormVO.getSearchInptEqpmnVO().getBsnsSn());
        inptEqpmnFormVO.setInptEqpmnVO(inptHnfVO);
        
        retrieveCmmnCode(model);
        return "/inpteqpmn/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param inptEqpmnFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpteqpmn/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpteqpmn/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 InptEqpmnFormVO inptEqpmnFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(inptEqpmnFormVO.getInptEqpmnVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpteqpmn/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	inptEqpmnFormVO.getInptEqpmnVO().setCreatId(loginUserVO.getUserId());
    	
    	inptEqpmnService.create(inptEqpmnFormVO.getInptEqpmnVO());
    	
        status.setComplete();
        return "forward:/inpteqpmn/createView.do";
    }
   
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param inptEqpmnFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpteqpmn/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpteqpmn/updateView.do")
    public String updateView(
    		InptEqpmnFormVO inptEqpmnFormVO ,ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(inptEqpmnFormVO.getSearchInptEqpmnVO().getBsnsSn());
        inptEqpmnFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력정보
        List<InptEqpmnVO> list = inptEqpmnService.retrieveList(inptEqpmnFormVO.getSearchInptEqpmnVO());
        model.addAttribute("resultList", list);
        retrieveCmmnCode(model);
        
        inptEqpmnFormVO.setInptEqpmnVO(inptEqpmnService.retrieve(inptEqpmnFormVO.getInptEqpmnVO()));
        
        return "/inpteqpmn/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param inptEqpmnFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpteqpmn/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpteqpmn/update.do")
    public String update(
    		HttpServletRequest request,
    		InptEqpmnFormVO inptEqpmnFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("inptHnfVO: "+inptEqpmnFormVO.getInptEqpmnVO());
    	
    	beanValidator.validate(inptEqpmnFormVO.getInptEqpmnVO(), bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpteqpmn/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptEqpmnFormVO.getInptEqpmnVO().setUpdtId(loginUserVO.getUserId());
    	inptEqpmnService.update(inptEqpmnFormVO.getInptEqpmnVO());
        status.setComplete();
        return "forward:/inpteqpmn/createView.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param inptEqpmnFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpteqpmn/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpteqpmn/delete.do")
    public String delete(
    		InptEqpmnFormVO inptEqpmnFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptEqpmnFormVO.getInptEqpmnVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("inptHnfVO: "+inptEqpmnFormVO.getInptEqpmnVO());
    	inptEqpmnService.delete(inptEqpmnFormVO.getInptEqpmnVO());
        status.setComplete();
        return "forward:/inpteqpmn/createView.do";
    }

}