package kr.go.mosf.pms.inpteqpmn.dao;

import java.util.List;

import kr.go.mosf.pms.inpteqpmn.vo.InptEqpmnVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("inptEqpmnDAO")
public class InptEqpmnDAO extends EgovAbstractDAO{
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 InptEqpmnVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Integer create(InptEqpmnVO vo) throws Exception {
        return (Integer)insert("inptEqpmnDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptEqpmnVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(InptEqpmnVO vo) throws Exception {
        return update("inptEqpmnDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptEqpmnVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(InptEqpmnVO vo) throws Exception {
        return delete("inptEqpmnDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptEqpmnVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public InptEqpmnVO retrieve(InptEqpmnVO vo) throws Exception {
        return (InptEqpmnVO) selectByPk("inptEqpmnDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptEqpmnVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<InptEqpmnVO> retrieveList(InptEqpmnVO vo) throws Exception {
        return (List<InptEqpmnVO>)list("inptEqpmnDAO.retrieveList", vo);
    }
}