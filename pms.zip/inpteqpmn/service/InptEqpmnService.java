package kr.go.mosf.pms.inpteqpmn.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.inpteqpmn.dao.InptEqpmnDAO;
import kr.go.mosf.pms.inpteqpmn.vo.InptEqpmnVO;

import org.springframework.stereotype.Service;

@Service("inptEqpmnService")
public class InptEqpmnService extends BaseService{
	@Resource(name="inptEqpmnDAO")
	private InptEqpmnDAO inptEqpmnDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 InptEqpmnVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(InptEqpmnVO vo) throws Exception {
    	return inptEqpmnDAO.create(vo);  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptEqpmnVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(InptEqpmnVO vo) throws Exception {    	
        return inptEqpmnDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptEqpmnVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(InptEqpmnVO vo) throws Exception {
    	return inptEqpmnDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptEqpmnVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public InptEqpmnVO retrieve(InptEqpmnVO vo) throws Exception {
    	return inptEqpmnDAO.retrieve(vo);
    }    
   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptEqpmnVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<InptEqpmnVO> retrieveList(InptEqpmnVO vo) throws Exception {
        return inptEqpmnDAO.retrieveList(vo);
    }

}
