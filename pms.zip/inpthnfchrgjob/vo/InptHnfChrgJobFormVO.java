package kr.go.mosf.pms.inpthnfchrgjob.vo;

import kr.go.mosf.pms.base.vo.BaseVO;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;

public class InptHnfChrgJobFormVO extends BaseVO{
	private InptHnfChrgJobVO searchInptHnfChrgJobVO;
	private InptHnfChrgJobVO inptHnfChrgJobVO;
	private BsnsInfoVO bsnsInfoVO;
	
	public InptHnfChrgJobFormVO(){
		searchInptHnfChrgJobVO = new InptHnfChrgJobVO();
		inptHnfChrgJobVO = new InptHnfChrgJobVO();
		bsnsInfoVO = new BsnsInfoVO();
	}

	public InptHnfChrgJobVO getSearchInptHnfChrgJobVO() {
		return searchInptHnfChrgJobVO;
	}

	public void setSearchInptHnfChrgJobVO(InptHnfChrgJobVO searchInptHnfChrgJobVO) {
		this.searchInptHnfChrgJobVO = searchInptHnfChrgJobVO;
	}

	public InptHnfChrgJobVO getInptHnfChrgJobVO() {
		return inptHnfChrgJobVO;
	}

	public void setInptHnfChrgJobVO(InptHnfChrgJobVO inptHnfChrgJobVO) {
		this.inptHnfChrgJobVO = inptHnfChrgJobVO;
	}

	public BsnsInfoVO getBsnsInfoVO() {
		return bsnsInfoVO;
	}

	public void setBsnsInfoVO(BsnsInfoVO bsnsInfoVO) {
		this.bsnsInfoVO = bsnsInfoVO;
	}
	
	
}
