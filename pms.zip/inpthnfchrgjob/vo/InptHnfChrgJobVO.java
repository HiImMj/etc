package kr.go.mosf.pms.inpthnfchrgjob.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.inpthnf.vo.InptHnfVO;

public class InptHnfChrgJobVO extends InptHnfVO{
	
	private int  sn;
    private String  chrgJobNm;
    private String  chrgJobCn;
    private Date  processBeginDe;
    private Date  processComptDe;
    private String  processProgrsSttusCode;
    private String  processProgrsSttusCodeNm;
    
    private String  processBeginDeDisplay;
    private String  processComptDeDisplay;
    
	public String getProcessBeginDeDisplay() {
		if(processBeginDe != null){
			processBeginDeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(processBeginDe);
		}
		return processBeginDeDisplay;
	}
	public void setProcessBeginDeDisplay(String processBeginDeDisplay) {
		this.processBeginDeDisplay = processBeginDeDisplay;
		try {
			processBeginDe = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(processBeginDeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getProcessComptDeDisplay() {
		if(processComptDe != null){
			processComptDeDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).format(processComptDe);
		}
		return processComptDeDisplay;
	}
	public void setProcessComptDeDisplay(String processComptDeDisplay) {
		this.processComptDeDisplay = processComptDeDisplay;
		try {
			processComptDe = new SimpleDateFormat(MOSFPMSDefine.DATE_FORMAT).parse(processComptDeDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getChrgJobNm() {
		return chrgJobNm;
	}
	public void setChrgJobNm(String chrgJobNm) {
		this.chrgJobNm = chrgJobNm;
	}
	public String getChrgJobCn() {
		return chrgJobCn;
	}
	public void setChrgJobCn(String chrgJobCn) {
		this.chrgJobCn = chrgJobCn;
	}
	public Date getProcessBeginDe() {
		return processBeginDe;
	}
	public void setProcessBeginDe(Date processBeginDe) {
		this.processBeginDe = processBeginDe;
	}
	public Date getProcessComptDe() {
		return processComptDe;
	}
	public void setProcessComptDe(Date processComptDe) {
		this.processComptDe = processComptDe;
	}
	public String getProcessProgrsSttusCode() {
		return processProgrsSttusCode;
	}
	public void setProcessProgrsSttusCode(String processProgrsSttusCode) {
		this.processProgrsSttusCode = processProgrsSttusCode;
	}
	public String getProcessProgrsSttusCodeNm() {
		return processProgrsSttusCodeNm;
	}
	public void setProcessProgrsSttusCodeNm(String processProgrsSttusCodeNm) {
		this.processProgrsSttusCodeNm = processProgrsSttusCodeNm;
	}
    
    
}
