package kr.go.mosf.pms.inpthnfchrgjob.dao;

import java.util.List;

import kr.go.mosf.pms.inpthnfchrgjob.vo.InptHnfChrgJobVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("inptHnfChrgJobDAO")
public class InptHnfChrgJobDAO extends EgovAbstractDAO{
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 InptHnfChrgJobVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public Integer create(InptHnfChrgJobVO vo) throws Exception {
        return (Integer)insert("inptHnfChrgJobDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptHnfChrgJobVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(InptHnfChrgJobVO vo) throws Exception {
        return update("inptHnfChrgJobDAO.update", vo);
    }       

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptHnfChrgJobVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(InptHnfChrgJobVO vo) throws Exception {
        return delete("inptHnfChrgJobDAO.delete", vo);
    }    
   

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfChrgJobVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public InptHnfChrgJobVO retrieve(InptHnfChrgJobVO vo) throws Exception {
        return (InptHnfChrgJobVO) selectByPk("inptHnfChrgJobDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfChrgJobVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<InptHnfChrgJobVO> retrieveList(InptHnfChrgJobVO vo) throws Exception {
        return (List<InptHnfChrgJobVO>)list("inptHnfChrgJobDAO.retrieveList", vo);
    }
}