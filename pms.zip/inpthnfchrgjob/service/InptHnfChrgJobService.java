package kr.go.mosf.pms.inpthnfchrgjob.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.inpthnfchrgjob.dao.InptHnfChrgJobDAO;
import kr.go.mosf.pms.inpthnfchrgjob.vo.InptHnfChrgJobVO;

import org.springframework.stereotype.Service;

@Service("inptHnfChrgJobService")
public class InptHnfChrgJobService extends BaseService{
	@Resource(name="inptHnfChrgJobDAO")
	private InptHnfChrgJobDAO inptHnfChrgJobDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 InptHnfChrgJobVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(InptHnfChrgJobVO vo) throws Exception {
    	return inptHnfChrgJobDAO.create(vo);  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 InptHnfChrgJobVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(InptHnfChrgJobVO vo) throws Exception {    	
        return inptHnfChrgJobDAO.update(vo);
    }
    

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 InptHnfChrgJobVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(InptHnfChrgJobVO vo) throws Exception {
    	return inptHnfChrgJobDAO.delete(vo);
    }
    

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfChrgJobVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public InptHnfChrgJobVO retrieve(InptHnfChrgJobVO vo) throws Exception {
    	return inptHnfChrgJobDAO.retrieve(vo);
    }    
   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 InptHnfChrgJobVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<InptHnfChrgJobVO> retrieveList(InptHnfChrgJobVO vo) throws Exception {
        return inptHnfChrgJobDAO.retrieveList(vo);
    }
}