package kr.go.mosf.pms.inpthnfchrgjob.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.inpthnf.service.InptHnfService;
import kr.go.mosf.pms.inpthnf.vo.InptHnfVO;
import kr.go.mosf.pms.inpthnfchrgjob.service.InptHnfChrgJobService;
import kr.go.mosf.pms.inpthnfchrgjob.vo.InptHnfChrgJobFormVO;
import kr.go.mosf.pms.inpthnfchrgjob.vo.InptHnfChrgJobVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class InptHnfChrgJobController extends BaseController{
	@Resource(name = "inptHnfChrgJobService")
	private InptHnfChrgJobService inptHnfChrgJobService;
	
	@Resource(name = "inptHnfService")
	private InptHnfService inptHnfService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param inptHnfChrgJobFormVO.getSearchBsnsInfoVO() - 조회할 정보가 담긴 BsnsInfoVO
	 * @param model
	 * @return "/inpthnfchrgjob/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/inpthnfchrgjob/retrieveList.do")
    public String retrieveList(InptHnfChrgJobFormVO inptHnfChrgJobFormVO, 
    		ModelMap model)
            throws Exception {
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO().getBsnsSn());
        inptHnfChrgJobFormVO.setBsnsInfoVO(bsnsInfoVO);
        
        //투입인력담당업무
        List<InptHnfChrgJobVO> list = inptHnfChrgJobService.retrieveList(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO());
        model.addAttribute("resultList", list);
        
        inptHnfChrgJobFormVO.setInptHnfChrgJobVO(null);
        
        retrieveCmmnCode(model);
        return "/inpthnfchrgjob/edit";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.PROCESS_PROGRS_STTUS_CODE);
        model.addAttribute("processProgrsSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	} 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param inptHnfChrgJobFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpthnfchrgjob/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnfchrgjob/createView.do")
    public String createView(
    		InptHnfChrgJobFormVO inptHnfChrgJobFormVO, ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO().getBsnsSn());
        inptHnfChrgJobFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력담당업무
        List<InptHnfChrgJobVO> list = inptHnfChrgJobService.retrieveList(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO());
        model.addAttribute("resultList", list);
        
        retrieveInptHnfVOList(inptHnfChrgJobFormVO, model);
        
        InptHnfChrgJobVO inptHnfChrgJobVO = new InptHnfChrgJobVO();
        inptHnfChrgJobVO.setBsnsSn(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO().getBsnsSn());
        inptHnfChrgJobFormVO.setInptHnfChrgJobVO(inptHnfChrgJobVO);
        
        retrieveCmmnCode(model);
        return "/inpthnfchrgjob/edit";
    }

	private void retrieveInptHnfVOList(InptHnfChrgJobFormVO inptHnfChrgJobFormVO, ModelMap model) throws Exception {
		//투입인력정보
        InptHnfVO inptHnfVO = new InptHnfVO();
        inptHnfVO.setBsnsSn(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO().getBsnsSn());
        List<InptHnfVO> inptHnfVOList = inptHnfService.retrieveList(inptHnfVO);
        model.addAttribute("inptHnfVOList", inptHnfVOList);
	}
    
    /**
	 * 글을 등록한다.
	 * @param userVO - 등록할 정보가 담긴 VO
	 * @param inptHnfChrgJobFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnfchrgjob/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnfchrgjob/create.do")
    public String create(    		
         	  HttpServletRequest request,
         	 InptHnfChrgJobFormVO inptHnfChrgJobFormVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(inptHnfChrgJobFormVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpthnfchrgjob/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	inptHnfChrgJobFormVO.getInptHnfChrgJobVO().setCreatId(loginUserVO.getUserId());
    	
    	inptHnfChrgJobService.create(inptHnfChrgJobFormVO.getInptHnfChrgJobVO());
    	
        status.setComplete();
        return "forward:/inpthnfchrgjob/createView.do";
    }
   
    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param inptHnfChrgJobFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/inpthnfchrgjob/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnfchrgjob/updateView.do")
    public String updateView(
    		InptHnfChrgJobFormVO inptHnfChrgJobFormVO ,ModelMap model)
            throws Exception {
    	 //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO().getBsnsSn());
        inptHnfChrgJobFormVO.setBsnsInfoVO(bsnsInfoService.retrieve(bsnsInfoVO));
        
        //투입인력담당업무
        List<InptHnfChrgJobVO> list = inptHnfChrgJobService.retrieveList(inptHnfChrgJobFormVO.getSearchInptHnfChrgJobVO());
        model.addAttribute("resultList", list);
        retrieveInptHnfVOList(inptHnfChrgJobFormVO, model);
        retrieveCmmnCode(model);
        
        inptHnfChrgJobFormVO.setInptHnfChrgJobVO(inptHnfChrgJobService.retrieve(inptHnfChrgJobFormVO.getInptHnfChrgJobVO()));
        
        return "/inpthnfchrgjob/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param userVO - 수정할 정보가 담긴 VO
	 * @param inptHnfChrgJobFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnfchrgjob/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnfchrgjob/update.do")
    public String update(
    		HttpServletRequest request,
    		InptHnfChrgJobFormVO inptHnfChrgJobFormVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("inptHnfChrgJobVO: "+inptHnfChrgJobFormVO.getInptHnfChrgJobVO());
    	
    	beanValidator.validate(inptHnfChrgJobFormVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {    		
			return "/inpthnfchrgjob/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptHnfChrgJobFormVO.getInptHnfChrgJobVO().setUpdtId(loginUserVO.getUserId());
    	inptHnfChrgJobService.update(inptHnfChrgJobFormVO.getInptHnfChrgJobVO());
        status.setComplete();
        return "forward:/inpthnfchrgjob/createView.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param userVO - 삭제할 정보가 담긴 VO
	 * @param inptHnfChrgJobFormVO.getSearchBsnsInfoVO() - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/inpthnfchrgjob/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/inpthnfchrgjob/delete.do")
    public String delete(
    		InptHnfChrgJobFormVO inptHnfChrgJobFormVO,
            HttpServletRequest request,
            SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	inptHnfChrgJobFormVO.getInptHnfChrgJobVO().setCreatId(loginUserVO.getUserId());
    	
    	logger.info("inptHnfChrgJobVO: "+inptHnfChrgJobFormVO.getInptHnfChrgJobVO());
    	inptHnfChrgJobService.delete(inptHnfChrgJobFormVO.getInptHnfChrgJobVO());
        status.setComplete();
        return "forward:/inpthnfchrgjob/createView.do";
    }

}