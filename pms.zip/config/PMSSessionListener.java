package kr.go.mosf.pms.config;

import java.util.Date;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import kr.go.mosf.pms.loginhist.service.LoginHistService;
import kr.go.mosf.pms.loginhist.vo.LoginHistVO;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.XmlWebApplicationContext;

public class PMSSessionListener implements HttpSessionListener {
	protected Logger logger = Logger.getLogger(this.getClass().getName());
	
	private XmlWebApplicationContext xmlWebApplicationContext;
	private LoginHistService loginHistService;
		
	@Override
	public void sessionCreated(HttpSessionEvent httpSessionEvent) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
		// TODO Auto-generated method stub
		HttpSession session = httpSessionEvent.getSession();
		
		xmlWebApplicationContext = (XmlWebApplicationContext) session.getServletContext().getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
		loginHistService = (LoginHistService)xmlWebApplicationContext.getBean("loginHistService");
		
		LoginHistVO loginHistVO = (LoginHistVO)session.getAttribute(LoginHistVO.LOGIN_HIST_VO);
    	loginHistVO.setLogoutDt(new Date());
    	loginHistVO.setLogoutSttusCode(LoginHistVO.LOGOUT_STTUS_CODE_TIMEOUT);
    	try {
			loginHistService.update(loginHistVO);
			logger.debug("TIME OUT: "+loginHistVO);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
