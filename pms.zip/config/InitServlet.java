package kr.go.mosf.pms.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class InitServlet extends javax.servlet.http.HttpServlet {
	protected Logger logger = Logger.getLogger(this.getClass());
	
	public void init() throws ServletException {
		super.init();
		MOSFPMSDefine.init();
	}
	
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    // TODO Auto-generated method stub
	    super.doGet(req, resp);
	    MOSFPMSDefine.init();
    }
	
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    // TODO Auto-generated method stub
	    this.doGet(req, resp);
    }
	
	
}
