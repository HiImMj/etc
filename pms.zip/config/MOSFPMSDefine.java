package kr.go.mosf.pms.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class MOSFPMSDefine {
	protected static Logger logger = Logger.getLogger(MOSFPMSDefine.class.getName());
	
	public static final String ROOT_PATH_WINDOWS = "C:/mosf/pms/";
	public static final String ROOT_PATH_UNIX = "/mosf/pms/";
	
	public static final String SERVICE_MODE_RUN = "run";
	public static final String SERVICE_MODE_DEV = "dev";

	public static String rootPath = ROOT_PATH_UNIX;	
	public static String filePath = rootPath + "file/";

	public static String serviceMode = SERVICE_MODE_DEV;

	public final static String SYSTEM_CONFIG_FILE = "config/systemconfig.properties";
	
	public static final String ENCRYPT_PASSWORD = "mosfpmsegovframe";
	public static final String ENCRYPT_ALGORITHM = "SHA-256";
	public static final String DATE_FORMAT = "yyyy.MM.dd";
	public static final String DATE_TIME_FORMAT = "yyyy.MM.dd HH:mm:ss";
	public static final String YEAR_MONTH_FORMAT = "yyyy.MM.";
	
	public static final String ERROR_MESSAGE = "ERROR_MESSAGE";

	public static void init() {
		String os = System.getProperty("os.name");

		if (os.toUpperCase().indexOf("WINDOW") > -1) {
			rootPath = ROOT_PATH_WINDOWS;			
		} else {
			rootPath = ROOT_PATH_UNIX;			
		}
		filePath = rootPath + "file/";

		//시스템 모드 로딩 
		Properties properties = new Properties();

		InputStream is = null;
		try {
			is = new FileInputStream(new File(MOSFPMSDefine.rootPath + SYSTEM_CONFIG_FILE));
			properties.load(is);
			serviceMode = properties.getProperty("system.level");

		} catch (Exception e) {
			logger.error(e.getClass().getName() + ": " + e.getMessage());
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
