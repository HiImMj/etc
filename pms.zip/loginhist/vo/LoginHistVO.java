package kr.go.mosf.pms.loginhist.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.user.vo.UserVO;

public class LoginHistVO extends UserVO{
	public static final String LOGIN_HIST_VO = "LOGIN_HIST_VO";
	
	public static final String LOGOUT_STTUS_CODE_UNKNOWN = "B001"; //알수없음.
	public static final String LOGOUT_STTUS_CODE_SUCCESS = "B002"; //정상
	public static final String LOGOUT_STTUS_CODE_TIMEOUT = "B003"; //타임아웃
	
	private Date loginDt;
	private Date logoutDt;
	private String logoutSttusCode;
	private String logoutSttusCodeNm;
	
	private String loginDtDisplay;
	private String logoutDtDisplay;
	
	public String getLoginDtDisplay() {
		if(loginDt != null){
			loginDtDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_TIME_FORMAT).format(loginDt);
		}
		return loginDtDisplay;
	}
	public void setLoginDtDisplay(String loginDtDisplay) {
		this.loginDtDisplay = loginDtDisplay;
		try {
			loginDt = new SimpleDateFormat(MOSFPMSDefine.DATE_TIME_FORMAT).parse(loginDtDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getLogoutDtDisplay() {
		if(logoutDt != null){
			logoutDtDisplay = new SimpleDateFormat(MOSFPMSDefine.DATE_TIME_FORMAT).format(logoutDt);
		}
		return logoutDtDisplay;
	}
	public void setLogoutDtDisplay(String logoutDtDisplay) {
		this.logoutDtDisplay = logoutDtDisplay;
		try {
			logoutDt = new SimpleDateFormat(MOSFPMSDefine.DATE_TIME_FORMAT).parse(logoutDtDisplay);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Date getLoginDt() {
		return loginDt;
	}
	public void setLoginDt(Date loginDt) {
		this.loginDt = loginDt;
	}
	public Date getLogoutDt() {
		return logoutDt;
	}
	public void setLogoutDt(Date logoutDt) {
		this.logoutDt = logoutDt;
	}
	public String getLogoutSttusCode() {
		return logoutSttusCode;
	}
	public void setLogoutSttusCode(String logoutSttusCode) {
		this.logoutSttusCode = logoutSttusCode;
	}
	public String getLogoutSttusCodeNm() {
		return logoutSttusCodeNm;
	}
	public void setLogoutSttusCodeNm(String logoutSttusCodeNm) {
		this.logoutSttusCodeNm = logoutSttusCodeNm;
	}
}
