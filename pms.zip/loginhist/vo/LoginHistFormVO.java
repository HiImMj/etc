package kr.go.mosf.pms.loginhist.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

public class LoginHistFormVO extends BaseVO{
	private LoginHistVO searchLoginHistVO;
	private LoginHistVO loginHistVO;
	
	public LoginHistFormVO(){
		searchLoginHistVO = new LoginHistVO();
		loginHistVO = new LoginHistVO();
	}

	public LoginHistVO getSearchLoginHistVO() {
		return searchLoginHistVO;
	}

	public void setSearchLoginHistVO(LoginHistVO searchLoginHistVO) {
		this.searchLoginHistVO = searchLoginHistVO;
	}

	public LoginHistVO getLoginHistVO() {
		return loginHistVO;
	}

	public void setLoginHistVO(LoginHistVO loginHistVO) {
		this.loginHistVO = loginHistVO;
	}
	
	
}
