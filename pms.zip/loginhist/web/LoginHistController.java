package kr.go.mosf.pms.loginhist.web;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.cmmncode.service.CmmnCodeService;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.loginhist.service.LoginHistService;
import kr.go.mosf.pms.loginhist.vo.LoginHistFormVO;
import kr.go.mosf.pms.loginhist.vo.LoginHistVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class LoginHistController extends BaseController{
	@Resource(name = "loginHistService")
	private LoginHistService loginHistService;
	
	@Resource(name = "cmmnCodeService")
	private CmmnCodeService cmmnCodeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param loginHistFormVO.getSearchLoginHistVO() - 조회할 정보가 담긴 LoginHistVO
	 * @param model
	 * @return "/loginhist/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/loginhist/retrievePagingList.do")
    public String retrievePagingList(LoginHistFormVO loginHistFormVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	loginHistFormVO.getSearchLoginHistVO().setPageUnit(propertiesService.getInt("pageUnit"));
    	loginHistFormVO.getSearchLoginHistVO().setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(loginHistFormVO.getSearchLoginHistVO().getPageIndex());
		paginationInfo.setRecordCountPerPage(loginHistFormVO.getSearchLoginHistVO().getPageUnit());
		paginationInfo.setPageSize(loginHistFormVO.getSearchLoginHistVO().getPageSize());
		
		loginHistFormVO.getSearchLoginHistVO().setFirstIndex(paginationInfo.getFirstRecordIndex());
		loginHistFormVO.getSearchLoginHistVO().setLastIndex(paginationInfo.getLastRecordIndex());
		loginHistFormVO.getSearchLoginHistVO().setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		loginHistFormVO.getSearchLoginHistVO().setDeleteYn("N");
		
		List<LoginHistVO> list = loginHistService.retrievePagingList(loginHistFormVO.getSearchLoginHistVO());
        model.addAttribute("resultList", list);
        
        retrieveCmmnCode(model);
        
        int totCnt = loginHistService.retrievePagingListCnt(loginHistFormVO.getSearchLoginHistVO());
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/loginhist/list";
    }

	private void retrieveCmmnCode(ModelMap model) throws Exception {
		CmmnCodeVO cmmnCodeVO = new CmmnCodeVO();
        cmmnCodeVO.setCmmnCodeTy(CmmnCodeVO.LOGOUT_STTUS_CODE);
        model.addAttribute("logoutSttusCodeVOList", cmmnCodeService.retrieveList(cmmnCodeVO));
	}  
}