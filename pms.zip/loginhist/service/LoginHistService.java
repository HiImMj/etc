package kr.go.mosf.pms.loginhist.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.loginhist.dao.LoginHistDAO;
import kr.go.mosf.pms.loginhist.vo.LoginHistVO;

import org.springframework.stereotype.Service;

@Service("loginHistService")
public class LoginHistService  extends BaseService{
	@Resource(name="loginHistDAO")
	private LoginHistDAO loginHistDAO;
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 LoginHistVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public void create(LoginHistVO vo) throws Exception {
    	loginHistDAO.create(vo);  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 LoginHistVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(LoginHistVO vo) throws Exception {
        return loginHistDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 LoginHistVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(LoginHistVO vo) throws Exception {
    	return loginHistDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 LoginHistVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public LoginHistVO retrieve(LoginHistVO vo) throws Exception {
    	return loginHistDAO.retrieve(vo);
    }   

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 LoginHistVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<LoginHistVO> retrievePagingList(LoginHistVO vo) throws Exception {
        return loginHistDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 LoginHistVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(LoginHistVO vo) {
        return loginHistDAO.retrievePagingListCnt(vo);
    }
}