package kr.go.mosf.pms.scrtyedcdta.service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.scrtyedcdta.dao.ScrtyEdcDtaAtchmnflDAO;
import kr.go.mosf.pms.scrtyedcdta.dao.ScrtyEdcDtaDAO;
import kr.go.mosf.pms.scrtyedcdta.vo.ScrtyEdcDtaAtchmnflVO;
import kr.go.mosf.pms.scrtyedcdta.vo.ScrtyEdcDtaVO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service("scrtyEdcDtaService")
public class ScrtyEdcDtaService extends BaseService{
	@Resource(name="scrtyEdcDtaDAO")
	private ScrtyEdcDtaDAO scrtyEdcDtaDAO;
	
	@Resource(name="scrtyEdcDtaAtchmnflDAO")
	private ScrtyEdcDtaAtchmnflDAO scrtyEdcDtaAtchmnflDAO;
	
	
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(ScrtyEdcDtaVO vo) throws Exception {
    	int scrtyEdcDtaSn = scrtyEdcDtaDAO.create(vo);
    	for(ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO:vo.getScrtyEdcDtaAtchmnflVOList()){
    		scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaSn(scrtyEdcDtaSn);
    		scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaStreAllCours(ScrtyEdcDtaAtchmnflVO.FILE_PATH+scrtyEdcDtaSn+"/"+System.currentTimeMillis());
    		scrtyEdcDtaAtchmnflDAO.create(scrtyEdcDtaAtchmnflVO);
    		
    		logger.debug("scrtyEdcDtaAtchmnflVO: "+scrtyEdcDtaAtchmnflVO);
    		//첨부파일 처리
    		MultipartFile file = scrtyEdcDtaAtchmnflVO.getFile();
    		
    		File filePath = new File(FilenameUtils.getFullPath(MOSFPMSDefine.filePath + scrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours()));
    		if(!filePath.exists()){
    			filePath.mkdirs();
    		}
    		
    		File tempFile = new File(MOSFPMSDefine.filePath + scrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours()+"temp");
    		File encFile = new File(MOSFPMSDefine.filePath + scrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours());
    		IOUtils.write(file.getBytes(), new FileOutputStream(tempFile));
    		
    		//암호화 처리
    		cryptoService.encrypt(tempFile, MOSFPMSDefine.ENCRYPT_PASSWORD, encFile);
    		try{
    			FileUtils.forceDelete(tempFile);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}    	
        return scrtyEdcDtaSn;
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ScrtyEdcDtaVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(ScrtyEdcDtaVO vo) throws Exception {
        int cnt = 0;
        cnt = scrtyEdcDtaDAO.update(vo);
        for(ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO:vo.getScrtyEdcDtaAtchmnflVOList()){
    		scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaSn(vo.getScrtyEdcDtaSn());
    		scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaStreAllCours(ScrtyEdcDtaAtchmnflVO.FILE_PATH+vo.getScrtyEdcDtaSn()+"/"+System.currentTimeMillis());
    		scrtyEdcDtaAtchmnflDAO.create(scrtyEdcDtaAtchmnflVO);
    		
    		logger.debug("scrtyEdcDtaAtchmnflVO: "+scrtyEdcDtaAtchmnflVO);
    		//첨부파일 처리
    		MultipartFile file = scrtyEdcDtaAtchmnflVO.getFile();
    		
    		File filePath = new File(FilenameUtils.getFullPath(MOSFPMSDefine.filePath + scrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours()));
    		if(!filePath.exists()){
    			filePath.mkdirs();
    		}
    		
    		File tempFile = new File(MOSFPMSDefine.filePath + scrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours()+"temp");
    		File encFile = new File(MOSFPMSDefine.filePath + scrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours());
    		IOUtils.write(file.getBytes(), new FileOutputStream(tempFile));
    		
    		//암호화 처리
    		cryptoService.encrypt(tempFile, MOSFPMSDefine.ENCRYPT_PASSWORD, encFile);
    		try{
    			FileUtils.forceDelete(tempFile);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}    	
        return cnt;
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ScrtyEdcDtaVO
	 * @return void형 
	 * @exception Exception
	 */
    public void delete(ScrtyEdcDtaVO vo) throws Exception {
    	int cnt = 0;
        cnt = scrtyEdcDtaDAO.delete(vo);
        
        //파일 삭제 프로세스 추가 필요.
//        ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO = new ScrtyEdcDtaAtchmnflVO();
//        scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaSn(vo.getScrtyEdcDtaSn());
//        scrtyEdcDtaAtchmnflDAO.deleteList(scrtyEdcDtaAtchmnflVO);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public ScrtyEdcDtaVO retrieve(ScrtyEdcDtaVO vo) throws Exception {
    	ScrtyEdcDtaVO recsroomVO = scrtyEdcDtaDAO.retrieve(vo);
    	if(recsroomVO != null){
    		ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO = new ScrtyEdcDtaAtchmnflVO();
            scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaSn(recsroomVO.getScrtyEdcDtaSn());
            recsroomVO.setScrtyEdcDtaAtchmnflVOList(scrtyEdcDtaAtchmnflDAO.retrieveList(scrtyEdcDtaAtchmnflVO));
    	}
        return recsroomVO;
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<ScrtyEdcDtaVO> retrievePagingList(ScrtyEdcDtaVO vo) throws Exception {
        return scrtyEdcDtaDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(ScrtyEdcDtaVO vo) {
        return scrtyEdcDtaDAO.retrievePagingListCnt(vo);
    }
    
    public ScrtyEdcDtaAtchmnflVO retrieveScrtyEdcDtaAtchmnflVO(ScrtyEdcDtaAtchmnflVO vo) throws Exception{
    	return scrtyEdcDtaAtchmnflDAO.retrieve(vo);
    }
    
    public int deleteScrtyEdcDtaAtchmnflVO(ScrtyEdcDtaAtchmnflVO vo) throws Exception{
    	return scrtyEdcDtaAtchmnflDAO.delete(vo);
    }
	
}