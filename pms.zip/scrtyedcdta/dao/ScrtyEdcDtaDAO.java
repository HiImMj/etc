package kr.go.mosf.pms.scrtyedcdta.dao;

import java.util.List;

import kr.go.mosf.pms.scrtyedcdta.vo.ScrtyEdcDtaVO;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("scrtyEdcDtaDAO")
public class ScrtyEdcDtaDAO extends EgovAbstractDAO {
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int create(ScrtyEdcDtaVO vo) throws Exception {
        return (Integer)insert("scrtyEdcDtaDAO.create", vo);
    }

    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ScrtyEdcDtaVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(ScrtyEdcDtaVO vo) throws Exception {
        return update("scrtyEdcDtaDAO.update", vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ScrtyEdcDtaVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(ScrtyEdcDtaVO vo) throws Exception {
        return delete("scrtyEdcDtaDAO.delete", vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public ScrtyEdcDtaVO retrieve(ScrtyEdcDtaVO vo) throws Exception {
        return (ScrtyEdcDtaVO) selectByPk("scrtyEdcDtaDAO.retrieve", vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<ScrtyEdcDtaVO> retrievePagingList(ScrtyEdcDtaVO vo) throws Exception {
        return (List<ScrtyEdcDtaVO>)list("scrtyEdcDtaDAO.retrievePagingList", vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(ScrtyEdcDtaVO vo) {
        return (Integer)getSqlMapClientTemplate().queryForObject("scrtyEdcDtaDAO.retrievePagingListCnt", vo);
    }
	
}