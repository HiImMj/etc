package kr.go.mosf.pms.scrtyedcdta.vo;

import java.util.ArrayList;
import java.util.List;

import kr.go.mosf.pms.base.vo.BaseVO;

import org.springframework.web.multipart.MultipartFile;

public class ScrtyEdcDtaVO extends BaseVO{
	private int scrtyEdcDtaSn;
    private int bsnsSn;
    private String scrtyEdcSj;
    private String scrtyEdcCn;
    private int rdcnt;
    
    private List<ScrtyEdcDtaAtchmnflVO> scrtyEdcDtaAtchmnflVOList = new ArrayList<ScrtyEdcDtaAtchmnflVO>();
    
    private List<MultipartFile> files = new ArrayList<MultipartFile>();
    
	public int getScrtyEdcDtaSn() {
		return scrtyEdcDtaSn;
	}
	public void setScrtyEdcDtaSn(int scrtyEdcDtaSn) {
		this.scrtyEdcDtaSn = scrtyEdcDtaSn;
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getScrtyEdcSj() {
		return scrtyEdcSj;
	}
	public void setScrtyEdcSj(String scrtyEdcSj) {
		this.scrtyEdcSj = scrtyEdcSj;
	}
	public String getScrtyEdcCn() {
		return scrtyEdcCn;
	}
	public void setScrtyEdcCn(String scrtyEdcCn) {
		this.scrtyEdcCn = scrtyEdcCn;
	}
	public int getRdcnt() {
		return rdcnt;
	}
	public void setRdcnt(int rdcnt) {
		this.rdcnt = rdcnt;
	}
	public List<ScrtyEdcDtaAtchmnflVO> getScrtyEdcDtaAtchmnflVOList() {
		return scrtyEdcDtaAtchmnflVOList;
	}
	public void setScrtyEdcDtaAtchmnflVOList(List<ScrtyEdcDtaAtchmnflVO> scrtyEdcDtaAtchmnflVOList) {
		this.scrtyEdcDtaAtchmnflVOList = scrtyEdcDtaAtchmnflVOList;
	}
	public List<MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}
    
    
}
