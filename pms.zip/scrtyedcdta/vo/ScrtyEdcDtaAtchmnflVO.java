package kr.go.mosf.pms.scrtyedcdta.vo;

import kr.go.mosf.pms.base.vo.BaseVO;

import org.springframework.web.multipart.MultipartFile;

public class ScrtyEdcDtaAtchmnflVO extends BaseVO{
	public static final String FILE_PATH = "scrtyedcdta/";
	
	private int scrtyEdcDtaSn;
	private int sn;
	private String scrtyEdcDtaOrginlFileNm;
    private String scrtyEdcDtaStreAllCours;
    
    private MultipartFile file;

	public int getScrtyEdcDtaSn() {
		return scrtyEdcDtaSn;
	}

	public void setScrtyEdcDtaSn(int scrtyEdcDtaSn) {
		this.scrtyEdcDtaSn = scrtyEdcDtaSn;
	}

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public String getScrtyEdcDtaOrginlFileNm() {
		return scrtyEdcDtaOrginlFileNm;
	}

	public void setScrtyEdcDtaOrginlFileNm(String scrtyEdcDtaOrginlFileNm) {
		this.scrtyEdcDtaOrginlFileNm = scrtyEdcDtaOrginlFileNm;
	}

	public String getScrtyEdcDtaStreAllCours() {
		return scrtyEdcDtaStreAllCours;
	}

	public void setScrtyEdcDtaStreAllCours(String scrtyEdcDtaStreAllCours) {
		this.scrtyEdcDtaStreAllCours = scrtyEdcDtaStreAllCours;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
    
    
}
