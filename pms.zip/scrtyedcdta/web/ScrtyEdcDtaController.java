package kr.go.mosf.pms.scrtyedcdta.web;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.bsnsinfo.service.BsnsInfoService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.scrtyedcdta.service.ScrtyEdcDtaService;
import kr.go.mosf.pms.scrtyedcdta.vo.ScrtyEdcDtaAtchmnflVO;
import kr.go.mosf.pms.scrtyedcdta.vo.ScrtyEdcDtaVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class ScrtyEdcDtaController  extends BaseController{
	@Resource(name = "scrtyEdcDtaService")
	private ScrtyEdcDtaService scrtyEdcDtaService;
	
	@Resource(name = "bsnsInfoService")
	private BsnsInfoService bsnsInfoService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 ScrtyEdcDtaVO
	 * @param model
	 * @return "/scrtyedcdta/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/scrtyedcdta/retrievePagingList.do")
    public String retrievePagingList(ScrtyEdcDtaVO scrtyEdcDtaVO,@ModelAttribute("searchVO") ScrtyEdcDtaVO searchVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		searchVO.setDeleteYn("N");
        List<ScrtyEdcDtaVO> sampleList = scrtyEdcDtaService.retrievePagingList(searchVO);
        model.addAttribute("resultList", sampleList);
        
        int totCnt = scrtyEdcDtaService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());        
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        
        return "/scrtyedcdta/list";
    } 
    
    
//    /**
//	 * 글을 조회한다.
//	 * @param scrtyEdcDtaVO - 조회할 정보가 담긴 VO
//	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
//	 * @param status
//	 * @return @ModelAttribute("scrtyEdcDtaVO") - 조회한 정보
//	 * @exception Exception
//	 */
//    @RequestMapping("/scrtyedcdta/retrieve.do")
//    public @ModelAttribute("scrtyEdcDtaVO")
//    ScrtyEdcDtaVO retrieve(
//            ScrtyEdcDtaVO scrtyEdcDtaVO,
//            @ModelAttribute("searchVO") ScrtyEdcDtaVO searchScrtyEdcDtaVO) throws Exception {
//        return scrtyEdcDtaService.retrieve(scrtyEdcDtaVO);
//    }
		
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/scrtyedcdta/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/scrtyedcdta/createView.do")
    public String createView(
            @ModelAttribute("searchVO") ScrtyEdcDtaVO searchVO, Model model)
            throws Exception {
        model.addAttribute("scrtyEdcDtaVO", new ScrtyEdcDtaVO());
        
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());        
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        
        return "/scrtyedcdta/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param scrtyEdcDtaVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/scrtyedcdta/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/scrtyedcdta/create.do")
    public String create(
    		ScrtyEdcDtaVO scrtyEdcDtaVO,
         	  HttpServletRequest request,
    		@ModelAttribute("searchVO") ScrtyEdcDtaVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(scrtyEdcDtaVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("scrtyEdcDtaVO", scrtyEdcDtaVO);
			return "/scrtyedcdta/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	scrtyEdcDtaVO.setCreatId(loginUserVO.getUserId());
    	
    	//첨부파일 데이터 준비
    	createAtchmnflList(scrtyEdcDtaVO);
    	
        scrtyEdcDtaService.create(scrtyEdcDtaVO);
        status.setComplete();
        
        if(searchVO.getDecorator().equals(searchVO.DECORATOR_POPUP)){
        	return "forward:/scrtyedcdta/retrievePagingList.do?decorator="+searchVO.getDecorator();
        }else{
        	return "forward:/scrtyedcdta/retrievePagingList.do";
        }
        
    }


	private void createAtchmnflList(ScrtyEdcDtaVO scrtyEdcDtaVO) {
		//둘 이상일때
    	List<MultipartFile> files = scrtyEdcDtaVO.getFiles();  
    	for(MultipartFile inFile:files){
	    	if(inFile != null && !GenericValidator.isBlankOrNull(inFile.getOriginalFilename())){
	    		ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO = new ScrtyEdcDtaAtchmnflVO();
	    		scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaOrginlFileNm(inFile.getOriginalFilename());
	    		scrtyEdcDtaAtchmnflVO.setScrtyEdcDtaStreAllCours(ScrtyEdcDtaAtchmnflVO.FILE_PATH);
	    		scrtyEdcDtaAtchmnflVO.setFile(inFile);
	    		scrtyEdcDtaVO.getScrtyEdcDtaAtchmnflVOList().add(scrtyEdcDtaAtchmnflVO);
	    	}
    	}
	}
    
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/scrtyedcdta/fileDown.do")    
    public void fileDown(ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
    	ScrtyEdcDtaAtchmnflVO exsitScrtyEdcDtaAtchmnflVO = scrtyEdcDtaService.retrieveScrtyEdcDtaAtchmnflVO(scrtyEdcDtaAtchmnflVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(exsitScrtyEdcDtaAtchmnflVO != null){
    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitScrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours());
    		int sourceFileSize = (int)sourceFile.length();
    		
    		File downFile = new File(MOSFPMSDefine.filePath + exsitScrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours()+"decrypt");
    		if(sourceFileSize>0){
    			cryptoService.decrypt(sourceFile, MOSFPMSDefine.ENCRYPT_PASSWORD, downFile);
    		}
    		
    		String sourceFileName = exsitScrtyEdcDtaAtchmnflVO.getScrtyEdcDtaOrginlFileNm();
    		
    		try{
    			downloadFile(request, response, downFile, sourceFileName);
    		}catch(Exception e){
    			logger.error(e.getMessage());
    			throw e;
    		}finally{    			
    			FileUtils.forceDelete(downFile);
    		}
    		
    		
		}
	}

    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/scrtyedcdta/deletefileAjax.do")    
    public String deletefileAjax(ScrtyEdcDtaAtchmnflVO scrtyEdcDtaAtchmnflVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	ScrtyEdcDtaAtchmnflVO exsitScrtyEdcDtaAtchmnflVO = scrtyEdcDtaService.retrieveScrtyEdcDtaAtchmnflVO(scrtyEdcDtaAtchmnflVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(exsitScrtyEdcDtaAtchmnflVO != null){
    		try{
	    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitScrtyEdcDtaAtchmnflVO.getScrtyEdcDtaStreAllCours());
	    		FileUtils.forceDelete(sourceFile);
	    		scrtyEdcDtaService.deleteScrtyEdcDtaAtchmnflVO(exsitScrtyEdcDtaAtchmnflVO);
	    		model.addAttribute("returnMessage", "success");
    		}catch(Exception e){
    			model.addAttribute("returnMessage", "fail");
    		}
    		
		}
    	
    	return "jsonView";
	}
	


    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/scrtyedcdta/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/scrtyedcdta/updateView.do")
    public String updateView(
            @ModelAttribute("searchVO") ScrtyEdcDtaVO searchVO,
            @ModelAttribute("scrtyEdcDtaSn") ScrtyEdcDtaVO scrtyEdcDtaVO ,Model model)
            throws Exception {
        model.addAttribute(scrtyEdcDtaService.retrieve(scrtyEdcDtaVO));
        
        //사업기본정보
        BsnsInfoVO bsnsInfoVO = new BsnsInfoVO();
        bsnsInfoVO.setBsnsSn(searchVO.getBsnsSn());        
        model.addAttribute("bsnsInfoVO", bsnsInfoService.retrieve(bsnsInfoVO));
        
        return "/scrtyedcdta/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param scrtyEdcDtaVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/scrtyedcdta/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/scrtyedcdta/update.do")
    public String update(
    		ScrtyEdcDtaVO scrtyEdcDtaVO, 
            HttpServletRequest request,
            @ModelAttribute("searchVO") ScrtyEdcDtaVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("scrtyEdcDtaVO: "+scrtyEdcDtaVO);
    	
    	beanValidator.validate(scrtyEdcDtaVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("scrtyEdcDtaVO", scrtyEdcDtaVO);
			return "/scrtyedcdta/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	scrtyEdcDtaVO.setUpdtId(loginUserVO.getUserId());
    	
    	//첨부파일 데이터 준비
    	createAtchmnflList(scrtyEdcDtaVO);
    	
        scrtyEdcDtaService.update(scrtyEdcDtaVO);
        status.setComplete();
        return "forward:/scrtyedcdta/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param scrtyEdcDtaVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/scrtyedcdta/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/scrtyedcdta/delete.do")
    public String delete(
            ScrtyEdcDtaVO scrtyEdcDtaVO,
            HttpServletRequest request,
            @ModelAttribute("searchVO") ScrtyEdcDtaVO searchVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	scrtyEdcDtaVO.setCreatId(loginUserVO.getUserId());
    	
    	logger.info("scrtyEdcDtaVO: "+scrtyEdcDtaVO);
        scrtyEdcDtaService.delete(scrtyEdcDtaVO);
        status.setComplete();
        return "forward:/scrtyedcdta/retrievePagingList.do";
    }
}