package kr.go.mosf.pms.output.dao;

import java.util.List;

import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeTypeVO;
import kr.go.mosf.pms.cmmncode.vo.CmmnCodeVO;
import kr.go.mosf.pms.output.vo.OutputStepVO;

import org.springframework.stereotype.Repository;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("outputStepDAO")
public class OutputStepDAO extends EgovAbstractDAO{
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 OutputStepVO
	 * @return 등록 결과
	 * @exception Exception
	 */
//    public void create(OutputStepVO vo) throws Exception {
//        insert("outputStepDAO.create", vo);
//    }

    public Integer create(OutputStepVO vo) throws Exception {
        return (Integer)insert("outputStepDAO.create", vo);
    }
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 OutputStepVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(OutputStepVO vo) throws Exception {
        return update("outputStepDAO.update", vo);
    }


    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public OutputStepVO retrieve(OutputStepVO vo) throws Exception {
        return (OutputStepVO) selectByPk("outputStepDAO.retrieve", vo);
    }

    /**
   	 * 글 페이징 목록을 조회한다.
   	 * @param vo - 조회할 정보가 담긴 CmmnCodeTypeVO
   	 * @return 글 목록
   	 * @exception Exception
   	 */
       @SuppressWarnings("unchecked")
   	public List<OutputStepVO> retrieveList(OutputStepVO vo) throws Exception {
           return (List<OutputStepVO>)list("outputStepDAO.retrieveList", vo);
       }
    
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 글 목록
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<OutputStepVO> retrievePagingList(OutputStepVO vo) throws Exception {
        return (List<OutputStepVO>)list("outputStepDAO.retrievePagingList", vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(OutputStepVO vo) {
        return (Integer)getSqlMapClientTemplate().queryForObject("outputStepDAO.retrievePagingListCnt", vo);
    }
	
}

