package kr.go.mosf.pms.output.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.output.dao.OutputTypeDAO;
import kr.go.mosf.pms.output.vo.OutputTypeVO;

@Service("outputTypeService")
public class OutputTypeService extends BaseService{
	@Resource(name="outputTypeDAO")
	private OutputTypeDAO outputTypeDAO;
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 OutputTypeVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public boolean create(OutputTypeVO vo) throws Exception {
    	boolean isSuccss = false;
    	OutputTypeVO existOutputTypeVO = outputTypeDAO.retrieve(vo);
    	if(existOutputTypeVO == null){
    		outputTypeDAO.create(vo);
    		isSuccss = true;
    	}
    	return isSuccss;  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 OutputTypeVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(OutputTypeVO vo) throws Exception {
        return outputTypeDAO.update(vo);
    }

    /**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 OutputTypeVO
	 * @return void형 
	 * @exception Exception
	 */
    public int delete(OutputTypeVO vo) throws Exception {
    	return outputTypeDAO.delete(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputTypeVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public OutputTypeVO retrieve(OutputTypeVO vo) throws Exception {
    	return outputTypeDAO.retrieve(vo);
    }
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputTypeVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<OutputTypeVO> retrieveList(OutputTypeVO vo) throws Exception {
        return outputTypeDAO.retrieveList(vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputTypeVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<OutputTypeVO> retrievePagingList(OutputTypeVO vo) throws Exception {
        return outputTypeDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputTypeVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(OutputTypeVO vo) {
        return outputTypeDAO.retrievePagingListCnt(vo);
    }
}
