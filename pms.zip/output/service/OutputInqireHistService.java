package kr.go.mosf.pms.output.service;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.output.dao.OutputInqireHistDAO;
import kr.go.mosf.pms.output.vo.OutputInqireHistVO;

@Service("OutputInqireHistService")
public class OutputInqireHistService extends BaseService{
	@Resource(name="outputInqireHistDAO")
	private OutputInqireHistDAO outputInqireHistDAO;
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 OutputInqireHistVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public boolean create(OutputInqireHistVO vo) throws Exception {
    	boolean isSuccss = false;
    	OutputInqireHistVO existOutputInqireHistVO = outputInqireHistDAO.retrieve(vo);
    	if(existOutputInqireHistVO == null){
    		outputInqireHistDAO.create(vo);
    		isSuccss = true;
    	}
    	return isSuccss;  	
    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 OutputInqireHistVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(OutputInqireHistVO vo) throws Exception {
        return outputInqireHistDAO.update(vo);
    }

    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputInqireHistVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public OutputInqireHistVO retrieve(OutputInqireHistVO vo) throws Exception {
    	return outputInqireHistDAO.retrieve(vo);
    }
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputInqireHistVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<OutputInqireHistVO> retrieveList(OutputInqireHistVO vo) throws Exception {
        return outputInqireHistDAO.retrieveList(vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputInqireHistVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<OutputInqireHistVO> retrievePagingList(OutputInqireHistVO vo) throws Exception {
        return outputInqireHistDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputInqireHistVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(OutputInqireHistVO vo) {
        return outputInqireHistDAO.retrievePagingListCnt(vo);
    }
}
