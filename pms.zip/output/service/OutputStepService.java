package kr.go.mosf.pms.output.service;

import java.util.List;

import javax.annotation.Resource;

import kr.go.mosf.pms.base.service.BaseService;
import kr.go.mosf.pms.bsnsinfo.vo.BsnsInfoVO;
import kr.go.mosf.pms.output.dao.OutputStepDAO;
import kr.go.mosf.pms.output.vo.OutputStepVO;

import org.springframework.stereotype.Service;

@Service("outputStepService")
public class OutputStepService extends BaseService{
	@Resource(name="outputStepDAO")
	private OutputStepDAO outputStepDAO;
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 OutputStepVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public boolean create(OutputStepVO vo) throws Exception {
    	boolean isSuccss = false;
    	OutputStepVO existOutputStepVO = outputStepDAO.retrieve(vo);
    	if(existOutputStepVO == null){
    		outputStepDAO.create(vo);
    		isSuccss = true;
    	}
    	return isSuccss;  	
    }
//    public int create(OutputStepVO vo) throws Exception {
//    	return outputStepDAO.create(vo);  	
//    }
  
    /**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 OutputStepVO
	 * @return void형
	 * @exception Exception
	 */
    public int update(OutputStepVO vo) throws Exception {
        return outputStepDAO.update(vo);
    }


    /**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 조회한 글
	 * @exception Exception
	 */
    public OutputStepVO retrieve(OutputStepVO vo) throws Exception {
    	return outputStepDAO.retrieve(vo);
    }
    
    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<OutputStepVO> retrieveList(OutputStepVO vo) throws Exception {
        return outputStepDAO.retrieveList(vo);
    }

    /**
	 * 글 페이징 목록을 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<OutputStepVO> retrievePagingList(OutputStepVO vo) throws Exception {
        return outputStepDAO.retrievePagingList(vo);
    }

    /**
	 * 글 총 갯수를 조회한다.
	 * @param vo - 조회할 정보가 담긴 OutputStepVO
	 * @return 글 총 갯수
	 * @exception
	 */
    public int retrievePagingListCnt(OutputStepVO vo) {
        return outputStepDAO.retrievePagingListCnt(vo);
    }
}

