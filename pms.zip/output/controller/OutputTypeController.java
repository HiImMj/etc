package kr.go.mosf.pms.output.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.output.service.OutputTypeService;
import kr.go.mosf.pms.output.vo.OutputTypeVO;
import kr.go.mosf.pms.user.vo.UserVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class OutputTypeController extends BaseController{
	@Resource(name = "outputTypeService")
	private OutputTypeService outputTypeService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 OutputTypeVO
	 * @param model
	 * @return "/outputType/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/outputType/retrievePagingList.do")
    public String retrievePagingList(@ModelAttribute("searchVO") OutputTypeVO searchVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		searchVO.setDeleteYn("N");
        List<OutputTypeVO> sampleList = outputTypeService.retrievePagingList(searchVO);
        model.addAttribute("resultList", sampleList);
        
        int totCnt = outputTypeService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/outputtype/list";
    } 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/outputType/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/outputType/createView.do")
    public String createView(
            @ModelAttribute("searchVO") OutputTypeVO searchVO, Model model)
            throws Exception {
        model.addAttribute("outputTypeVO", new OutputTypeVO());
        return "/outputtype/edit";
    }
    
    /**
	 * 글을 등록한다.
	 * @param outputTypeVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/outputType/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/outputType/create.do")
    public String create(
    		OutputTypeVO outputTypeVO,
         	  HttpServletRequest request,
    		@ModelAttribute("searchVO") OutputTypeVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status) 
    throws Exception {
    	
    	// Server-Side Validation
    	beanValidator.validate(outputTypeVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("outputTypeVO", outputTypeVO);
			return "/outputtype/edit";
    	}
    	
    	//session에서 로그인 정보를 가져온다.
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	outputTypeVO.setCreatId(loginUserVO.getUserId());
    	
    	if(!outputTypeService.create(outputTypeVO)){
    		model.addAttribute(MOSFPMSDefine.ERROR_MESSAGE, "이미 등록된 코드유형 입니다.");
    		return "/outputtype/edit";
    	}
        status.setComplete();
        return "forwardoutputTypepe/retrievePagingList.do";
    }
    
    /**
     * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/outputType/retrieveAjax.do")    
    public String retrieveAjax(OutputTypeVO outputTypeVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
    	OutputTypeVO existOutputTypeVO = outputTypeService.retrieve(outputTypeVO);
    	
    	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
    	if(existOutputTypeVO == null){
	    	model.addAttribute("returnMessage", "success");
		}else{
			model.addAttribute("returnMessage", "fail");
		}
    	
    	return "jsonView";
	}
	


    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/outputType/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/outputType/updateView.do")
    public String updateView(
            @ModelAttribute("searchVO") OutputTypeVO searchVO,
            @ModelAttribute("cmmnCodeTy") OutputTypeVO outputTypeVO ,Model model)
            throws Exception {
        model.addAttribute(outputTypeService.retrieve(outputTypeVO));
        return "/outputtype/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param outputTypeVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/outputType/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/outputType/update.do")
    public String update(
    		OutputTypeVO outputTypeVO, 
            HttpServletRequest request,
            @ModelAttribute("searchVO") OutputTypeVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("outputTypeVO: "+outputTypeVO);
    	
    	beanValidator.validate(outputTypeVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("outputTypeVO", outputTypeVO);
			return "/outputtype/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	outputTypeVO.setUpdtId(loginUserVO.getUserId());
        outputTypeService.update(outputTypeVO);
        status.setComplete();
        return "forward:/outputType/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param outputTypeVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/outputType/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/outputType/delete.do")
    public String delete(
            OutputTypeVO outputTypeVO,
            HttpServletRequest request,
            @ModelAttribute("searchVO") OutputTypeVO searchVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	outputTypeVO.setCreatId(loginUserVO.getUserId());
    	
    	logger.info("outputTypeVO: "+outputTypeVO);
        outputTypeService.delete(outputTypeVO);
        status.setComplete();
        return "forward:/outputType/retrievePagingList.do";
    }
}
