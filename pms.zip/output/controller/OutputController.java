package kr.go.mosf.pms.output.controller;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

import kr.go.mosf.pms.base.web.BaseController;
import kr.go.mosf.pms.config.MOSFPMSDefine;
import kr.go.mosf.pms.output.service.OutputService;
import kr.go.mosf.pms.output.vo.OutputVO;
import kr.go.mosf.pms.user.vo.UserVO;
@Controller
public class OutputController extends BaseController{
	@Resource(name = "outputService")
	private OutputService outputService;
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 OutputVO
	 * @param model
	 * @return "/output/egovSampleList"
	 * @exception Exception
	 */
    @RequestMapping(value="/output/retrievePagingList.do")
    public String retrievePagingList(@ModelAttribute("searchVO") OutputVO searchVO, 
    		ModelMap model)
            throws Exception {
    	
    	/** EgovPropertyService.sample */
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing setting */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());
		
		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		searchVO.setDeleteYn("N");
        List<OutputVO> sampleList = outputService.retrievePagingList(searchVO);
        model.addAttribute("resultList", sampleList);
        
        int totCnt = outputService.retrievePagingListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
        
        return "/output/list";
    } 
 
    /**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/output/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/output/createView.do")
    public String createView(
            @ModelAttribute("searchVO") OutputVO searchVO, Model model)
            throws Exception {
        model.addAttribute("outputVO", new OutputVO());
        return "/output/edit";
    }
    
    /**
  	 * 글을 등록한다.
  	 * @param outputVO - 등록할 정보가 담긴 VO
  	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
  	 * @param status
  	 * @return "forward:/output/retrievePagingList.do"
  	 * @exception Exception
  	 */
      @RequestMapping("/output/create.do")
      public String create(
    		  OutputVO outputVO,
           	  HttpServletRequest request,
      		@ModelAttribute("searchVO") OutputVO searchVO,
              BindingResult bindingResult, Model model, SessionStatus status) 
      throws Exception {
      	
      	// Server-Side Validation
      	beanValidator.validate(outputVO, bindingResult);
      	
      	if (bindingResult.hasErrors()) {
      		model.addAttribute("outputVO", outputVO);
  			return "/output/edit";
      	}
      	
      	//session에서 로그인 정보를 가져온다.
      	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
      	outputVO.setCreatId(loginUserVO.getUserId());
      	
      	
      	//파일 하나일때
      	MultipartFile file = outputVO.getFile();    	
      	if(file != null && !GenericValidator.isBlankOrNull(file.getOriginalFilename())){
      		OutputVO outputAtchmnflVO = new OutputVO();
      		outputVO.setOutputOrginlFileNm(file.getOriginalFilename());
      		outputVO.setOutputStreAllCours("output/");
      		outputVO.setFile(file);
      		outputVO.getOutputVOList().add(outputVO);
      	}
      	
          outputService.create(outputVO);
          status.setComplete();
          return "forward:/output/retrievePagingList.do";
      }
      
      
      /**
       * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
       * 
       * @param commandMap
       * @param response
       * @throws Exception
       */
      @RequestMapping(value = "/output/fileDown.do")    
      public void fileDown(OutputVO outputVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
      	OutputVO exsitOutputVO = outputService.retrieveOutputVO(outputVO);
      	
      	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
      	if(exsitOutputVO != null){
      		File sourceFile = new File(MOSFPMSDefine.filePath + exsitOutputVO.getOutputStreAllCours());
      		int sourceFileSize = (int)sourceFile.length();
      		
      		File downFile = new File(MOSFPMSDefine.filePath + exsitOutputVO.getOutputStreAllCours()+"decrypt");
      		if(sourceFileSize>0){
      			cryptoService.decrypt(sourceFile, MOSFPMSDefine.ENCRYPT_PASSWORD, downFile);
      		}
      		
      		String sourceFileName = exsitOutputVO.getOutputOrginlFileNm();
      		
      		try{
      			downloadFile(request, response, downFile, sourceFileName);
      		}catch(Exception e){
      			logger.error(e.getMessage());
      			throw e;
      		}finally{
      			downFile.deleteOnExit();
      		}
      		
      		
  		}
  	}

      /**
       * 첨부파일로 등록된 파일에 대하여 다운로드를 제공한다.
       * 
       * @param commandMap
       * @param response
       * @throws Exception
       */
      @RequestMapping(value = "/output/deletefileAjax.do")    
      public String deletefileAjax(OutputVO outputVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
      	OutputVO exsitOutputVO = outputService.retrieveOutputVO(outputVO);
      	
      	//자료실은 특별히 다운로드 제약이 없으므로 파일에 대한 접근 권한은 체크 하지 않는다.
      	if(exsitOutputVO != null){
      		try{
  	    		File sourceFile = new File(MOSFPMSDefine.filePath + exsitOutputVO.getOutputStreAllCours());
  	    		FileUtils.forceDelete(sourceFile);
  	    		outputService.deleteOutputVO(exsitOutputVO);
  	    		model.addAttribute("returnMessage", "success");
      		}catch(Exception e){
      			model.addAttribute("returnMessage", "fail");
      		}
      		
  		}
      	
      	return "jsonView";
  	}
  	



    
    /**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "/output/egovSampleRegister"
	 * @exception Exception
	 */
    @RequestMapping("/output/updateView.do")
    public String updateView(
            @ModelAttribute("searchVO") OutputVO searchVO,
            @ModelAttribute("outputTy") OutputVO outputVO ,Model model)
            throws Exception {
        model.addAttribute(outputService.retrieve(outputVO));
        return "/output/edit";
    }

    /**
	 * 글을 수정한다.
	 * @param outputVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/output/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/output/update.do")
    public String update(
    		OutputVO outputVO, 
            HttpServletRequest request,
            @ModelAttribute("searchVO") OutputVO searchVO,
            BindingResult bindingResult, Model model, SessionStatus status)
            throws Exception {
    	
    	logger.debug("outputVO: "+outputVO);
    	
    	beanValidator.validate(outputVO, bindingResult);
    	
    	if (bindingResult.hasErrors()) {
    		model.addAttribute("outputVO", outputVO);
			return "/output/edit";
    	}
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	outputVO.setUpdtId(loginUserVO.getUserId());
        outputService.update(outputVO);
        status.setComplete();
        return "forward:/output/retrievePagingList.do";
    }
    
    /**
	 * 글을 삭제한다.
	 * @param outputVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/output/retrievePagingList.do"
	 * @exception Exception
	 */
    @RequestMapping("/output/delete.do")
    public String delete(
            OutputVO outputVO,
            HttpServletRequest request,
            @ModelAttribute("searchVO") OutputVO searchVO, SessionStatus status)
            throws Exception {
    	
    	UserVO loginUserVO =  (UserVO)request.getSession().getAttribute(UserVO.LOGIN_USER_VO);
    	
    	outputVO.setCreatId(loginUserVO.getUserId());
    	
    	logger.info("outputVO: "+outputVO);
        outputService.delete(outputVO);
        status.setComplete();
        return "forward:/output/retrievePagingList.do";
    }
}

