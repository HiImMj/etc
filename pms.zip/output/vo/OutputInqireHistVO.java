package kr.go.mosf.pms.output.vo;

import java.util.Date;

import kr.go.mosf.pms.base.vo.BaseVO;

public class OutputInqireHistVO extends BaseVO{
	private int outputInqireHistSn;				/* 산출물_조회_이력_순번 */
	private int bsnsSn;							/* 사업_순번 */
    private String outputStep;					/* 산출물_단계 */
    private String outputTy;					/* 산출물_유형 */
    private String userId;						/* 사용자_ID */
    private Date accesDt;						/* 접근_일시 */

    public int getOutputInqireHistSn() {
		return outputInqireHistSn;
	}
	public void setOutputInqireHistSn(int outputInqireHistSn) {
		this.outputInqireHistSn = outputInqireHistSn;
	}
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getOutputStep() {
		return outputStep;
	}
	public void setOutputStep(String outputStep) {
		this.outputStep = outputStep;
	}
	public String getOutputTy() {
		return outputTy;
	}
	public void setOutputTy(String outputTy) {
		this.outputTy = outputTy;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getAccesDt() {
		return accesDt;
	}
	public void setAccesDt(Date accesDt) {
		this.accesDt = accesDt;
	}
}
