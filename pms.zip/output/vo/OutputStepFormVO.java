package kr.go.mosf.pms.output.vo;


public class OutputStepFormVO {
	private OutputStepVO searchOutputStepVO;
	private OutputStepVO outputStepVO;
	
	public OutputStepFormVO(){
		searchOutputStepVO = new OutputStepVO();
		outputStepVO = new OutputStepVO();
	}

	public OutputStepVO getSearchOutputStepVO() {
		return searchOutputStepVO;
	}

	public void setSearchOutputStepVO(OutputStepVO searchOutputStepVO) {
		this.searchOutputStepVO = searchOutputStepVO;
	}

	public OutputStepVO getOutputStepVO() {
		return outputStepVO;
	}

	public void setOutputStepVO(OutputStepVO outputStepVO) {
		this.outputStepVO = outputStepVO;
	}
}
