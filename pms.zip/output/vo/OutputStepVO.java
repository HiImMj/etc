package kr.go.mosf.pms.output.vo;

import java.util.Date;

import kr.go.mosf.pms.base.vo.BaseVO;

public class OutputStepVO extends BaseVO{
	private int bsnsSn;						/* 사업_순번 */
    private String outputStep;				/* 산출물_단계 */
    private String outputStepNm;			/* 산출물_단계명 */
    private int sortOrdr;					/* 정렬_순서 */
	
	public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getOutputStep() {
		return outputStep;
	}
	public void setOutputStep(String outputStep) {
		this.outputStep = outputStep;
	}
	public String getOutputStepNm() {
		return outputStepNm;
	}
	public void setOutputStepNm(String outputStepNm) {
		this.outputStepNm = outputStepNm;
	}
	public int getSortOrdr() {
		return sortOrdr;
	}
	public void setSortOrdr(int sortOrdr) {
		this.sortOrdr = sortOrdr;
	}


  }
