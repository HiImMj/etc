package kr.go.mosf.pms.output.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import kr.go.mosf.pms.base.vo.BaseVO;

public class OutputVO extends BaseVO{
	private int bsnsSn;						/* 사업_순번 */
    private String outputStep;				/* 산출물_단계 */
    private String outputTy;				/* 산출물_유형 */
    private String outputNm;				/* 산출물_명 */
    private String outputDc;				/* 산출물_설명 */
    private String outputOrginlFileNm;		/* 산출물_원본_파일_명 */
    private String outputStreAllCours;		/* 산출물_저장_전체_경로 */
    
    private List<OutputVO> outputVOList = new ArrayList<OutputVO>();

    private MultipartFile file;
    private List<MultipartFile> files = new ArrayList<MultipartFile>();
    
    
    public int getBsnsSn() {
		return bsnsSn;
	}
	public void setBsnsSn(int bsnsSn) {
		this.bsnsSn = bsnsSn;
	}
	public String getOutputStep() {
		return outputStep;
	}
	public void setOutputStep(String outputStep) {
		this.outputStep = outputStep;
	}
	public String getOutputTy() {
		return outputTy;
	}
	public void setOutputTy(String outputTy) {
		this.outputTy = outputTy;
	}
	public String getOutputNm() {
		return outputNm;
	}
	public void setOutputNm(String outputNm) {
		this.outputNm = outputNm;
	}
	public String getOutputDc() {
		return outputDc;
	}
	public void setOutputDc(String outputDc) {
		this.outputDc = outputDc;
	}
	public String getOutputOrginlFileNm() {
		return outputOrginlFileNm;
	}
	public void setOutputOrginlFileNm(String outputOrginlFileNm) {
		this.outputOrginlFileNm = outputOrginlFileNm;
	}
	public String getOutputStreAllCours() {
		return outputStreAllCours;
	}
	public void setOutputStreAllCours(String outputStreAllCours) {
		this.outputStreAllCours = outputStreAllCours;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public List<MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}
	public List<OutputVO> getOutputVOList() {
		return outputVOList;
	}
	public void setOutputVOList(List<OutputVO> outputVOList) {
		this.outputVOList = outputVOList;
	}
}
